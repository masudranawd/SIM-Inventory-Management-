-- phpMyAdmin SQL Dump
-- version 4.8.5
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Aug 05, 2020 at 08:51 PM
-- Server version: 10.1.38-MariaDB
-- PHP Version: 7.3.2

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `pos_vipsim`
--

-- --------------------------------------------------------

--
-- Table structure for table `tb_activity`
--

CREATE TABLE `tb_activity` (
  `activity_id` int(11) NOT NULL,
  `activity_details` text NOT NULL,
  `status` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tb_activity`
--

INSERT INTO `tb_activity` (`activity_id`, `activity_details`, `status`, `created_at`) VALUES
(370, '<div class=\"alert alert-warning\">Success :) Update Generic By &mdash; Faizur Rahman <span style=\"font-size:12px;\">(USER3)</span> </div>', 0, '2020-07-27 13:53:39'),
(371, '<div class=\"alert alert-success\">Success :) ON Generic By &mdash; Faizur Rahman <span style=\"font-size:12px;\">(USER3)</span> </div>', 0, '2020-07-27 13:56:50'),
(372, '<div class=\"alert alert-success\">Success :) OFF Generic By &mdash; Faizur Rahman <span style=\"font-size:12px;\">(USER3)</span> </div>', 0, '2020-07-27 13:56:58'),
(373, '<div class=\"alert alert-success\">Success :) ON Generic By &mdash; Faizur Rahman <span style=\"font-size:12px;\">(USER3)</span> </div>', 0, '2020-07-27 14:12:46'),
(374, '<div class=\"alert alert-success\">Success :) ON Generic By &mdash; Faizur Rahman <span style=\"font-size:12px;\">(USER3)</span> </div>', 0, '2020-07-27 14:12:48'),
(375, '<div class=\"alert alert-success\">Success :) 1 SIM Add By &mdash; Faizur Rahman <span style=\"font-size:12px;\">(USER3)</span> </div>', 0, '2020-07-27 16:08:10'),
(376, '<div class=\"alert alert-success\">Success :) 1 SIM Add By &mdash; Faizur Rahman <span style=\"font-size:12px;\">(USER3)</span> </div>', 0, '2020-07-27 16:50:32'),
(377, '<div class=\"alert alert-warning\">Success :) Update SIM  By &mdash; Faizur Rahman <span style=\"font-size:12px;\">(USER3)</span> </div>', 0, '2020-07-27 17:05:25'),
(378, '<div class=\"alert alert-warning\">Success :) Update SIM  By &mdash; Faizur Rahman <span style=\"font-size:12px;\">(USER3)</span> </div>', 0, '2020-07-27 17:57:04'),
(379, '<div class=\"alert alert-success\">Success :) 1 SIM Add By &mdash; Faizur Rahman <span style=\"font-size:12px;\">(USER3)</span> </div>', 0, '2020-07-27 17:57:36'),
(380, '<div class=\"alert alert-success\"> Success :)1 SIM  Name as # Bl Added By &mdash; Faizur Rahman <span style=\"font-size:12px;\">(USER3)</span> </div>', 0, '2020-07-27 18:04:25'),
(381, '<div class=\"alert alert-success\">Success :) ON SIM  By &mdash; Faizur Rahman <span style=\"font-size:12px;\">(USER3)</span> </div>', 0, '2020-07-27 18:04:32'),
(382, '<div class=\"alert alert-success\">Success :) 1 SIM Add By &mdash; Faizur Rahman <span style=\"font-size:12px;\">(USER3)</span> </div>', 0, '2020-07-27 18:04:57'),
(383, '<div class=\"alert alert-success\">Success :) 1 SIM Add By &mdash; Faizur Rahman <span style=\"font-size:12px;\">(USER3)</span> </div>', 0, '2020-07-27 18:05:54'),
(384, '<div class=\"alert alert-success\">Success :) 1 SIM Add By &mdash; Faizur Rahman <span style=\"font-size:12px;\">(USER3)</span> </div>', 0, '2020-07-27 18:08:52'),
(385, '<div class=\"alert alert-warning\">Success :) Update Product By &mdash; Faizur Rahman <span style=\"font-size:12px;\">(USER3)</span> </div>', 0, '2020-07-27 18:47:13'),
(386, '<div class=\"alert alert-warning\">Success :) Update Product By &mdash; Faizur Rahman <span style=\"font-size:12px;\">(USER3)</span> </div>', 0, '2020-07-27 18:48:02'),
(387, '<div class=\"alert alert-warning\">Success :) Update Product By &mdash; Faizur Rahman <span style=\"font-size:12px;\">(USER3)</span> </div>', 0, '2020-07-27 18:48:24'),
(388, '<div class=\"alert alert-warning\">Success :) Update Product By &mdash; Faizur Rahman <span style=\"font-size:12px;\">(USER3)</span> </div>', 0, '2020-07-27 18:48:51'),
(389, '<div class=\"alert alert-warning\">Success :) Update Product By &mdash; Faizur Rahman <span style=\"font-size:12px;\">(USER3)</span> </div>', 0, '2020-07-27 18:52:48'),
(390, '<div class=\"alert alert-warning\">Success :) Update Product By &mdash; Faizur Rahman <span style=\"font-size:12px;\">(USER3)</span> </div>', 0, '2020-07-27 18:53:00'),
(391, '<div class=\"alert alert-warning\">Success :) Update Product By &mdash; Faizur Rahman <span style=\"font-size:12px;\">(USER3)</span> </div>', 0, '2020-07-27 18:53:20'),
(392, '<div class=\"alert alert-warning\">Success :) Update Product By &mdash; Faizur Rahman <span style=\"font-size:12px;\">(USER3)</span> </div>', 0, '2020-07-27 18:54:14'),
(393, '<div class=\"alert alert-warning\">Success :) Update Product By &mdash; Faizur Rahman <span style=\"font-size:12px;\">(USER3)</span> </div>', 0, '2020-07-27 18:54:20'),
(394, '<div class=\"alert alert-warning\">Success :) Update Product By &mdash; Faizur Rahman <span style=\"font-size:12px;\">(USER3)</span> </div>', 0, '2020-07-27 18:56:05'),
(395, '<div class=\"alert alert-warning\">Success :) Update Product By &mdash; Faizur Rahman <span style=\"font-size:12px;\">(USER3)</span> </div>', 0, '2020-07-27 18:56:11'),
(396, '<div class=\"alert alert-warning\">Success :) Update Product By &mdash; Faizur Rahman <span style=\"font-size:12px;\">(USER3)</span> </div>', 0, '2020-07-27 18:56:24'),
(397, '<div class=\"alert alert-danger\">Removed :) 1 Product removed By &mdash; Faizur Rahman <span style=\"font-size:12px;\">(USER3)</span> </div>', 0, '2020-07-27 18:58:04'),
(398, '<div class=\"alert alert-success\">Success :) 1 SIM Add By &mdash; Faizur Rahman <span style=\"font-size:12px;\">(USER3)</span> </div>', 0, '2020-07-28 16:21:25'),
(399, '<div class=\"alert alert-danger\">Removed :) 1 Product removed By &mdash; Faizur Rahman <span style=\"font-size:12px;\">(USER3)</span> </div>', 0, '2020-07-28 16:22:57'),
(400, '<div class=\"alert alert-danger\">Removed :) 1 Product removed By &mdash; Faizur Rahman <span style=\"font-size:12px;\">(USER3)</span> </div>', 0, '2020-07-28 16:22:59'),
(401, '<div class=\"alert alert-danger\">Removed :) 1 Product removed By &mdash; Faizur Rahman <span style=\"font-size:12px;\">(USER3)</span> </div>', 0, '2020-07-28 16:23:01'),
(402, '<div class=\"alert alert-danger\">Removed :) 1 Product removed By &mdash; Faizur Rahman <span style=\"font-size:12px;\">(USER3)</span> </div>', 0, '2020-07-28 16:23:02'),
(403, '<div class=\"alert alert-danger\">Removed :) 1 Product removed By &mdash; Faizur Rahman <span style=\"font-size:12px;\">(USER3)</span> </div>', 0, '2020-07-28 16:23:03'),
(404, '<div class=\"alert alert-danger\">Removed :) 1 Product removed By &mdash; Faizur Rahman <span style=\"font-size:12px;\">(USER3)</span> </div>', 0, '2020-07-28 16:23:07'),
(405, '<div class=\"alert alert-success\">Success :) 1 SIM Add By &mdash; Faizur Rahman <span style=\"font-size:12px;\">(USER3)</span> </div>', 0, '2020-07-28 16:23:38'),
(406, '<div class=\"alert alert-success\">Success :) 1 SIM Add By &mdash; Faizur Rahman <span style=\"font-size:12px;\">(USER3)</span> </div>', 0, '2020-07-28 16:24:09'),
(407, '<div class=\"alert alert-success\">Success :) 1 SIM Add By &mdash; Faizur Rahman <span style=\"font-size:12px;\">(USER3)</span> </div>', 0, '2020-07-28 16:25:40'),
(408, '<div class=\"alert alert-success\">Success :) 1 SIM Add By &mdash; Faizur Rahman <span style=\"font-size:12px;\">(USER3)</span> </div>', 0, '2020-07-28 16:26:14'),
(409, '<div class=\"alert alert-success\">Success :) 1 SIM Add By &mdash; Faizur Rahman <span style=\"font-size:12px;\">(USER3)</span> </div>', 0, '2020-07-28 16:26:46'),
(410, '<div class=\"alert alert-warning\">Success :) Update Product By &mdash; Faizur Rahman <span style=\"font-size:12px;\">(USER3)</span> </div>', 0, '2020-07-28 16:36:28'),
(411, '<div class=\"alert alert-warning\">Success :) Update Product By &mdash; Faizur Rahman <span style=\"font-size:12px;\">(USER3)</span> </div>', 0, '2020-07-28 16:38:52'),
(412, '<div class=\"alert alert-warning\">Success :) Update Product By &mdash; Faizur Rahman <span style=\"font-size:12px;\">(USER3)</span> </div>', 0, '2020-07-28 16:38:59'),
(413, '<div class=\"alert alert-warning\">Success :) Update Product By &mdash; Faizur Rahman <span style=\"font-size:12px;\">(USER3)</span> </div>', 0, '2020-07-28 16:39:04'),
(414, '<div class=\"alert alert-warning\">Success :) Update Product By &mdash; Faizur Rahman <span style=\"font-size:12px;\">(USER3)</span> </div>', 0, '2020-07-28 16:39:29'),
(415, '<div class=\"alert alert-warning\">Success :) Update Product By &mdash; Faizur Rahman <span style=\"font-size:12px;\">(USER3)</span> </div>', 0, '2020-07-28 16:39:41'),
(416, '<div class=\"alert alert-warning\">Success :) Update Product By &mdash; Faizur Rahman <span style=\"font-size:12px;\">(USER3)</span> </div>', 0, '2020-07-28 16:40:10'),
(417, '<div class=\"alert alert-warning\">Success :) Update Product By &mdash; Faizur Rahman <span style=\"font-size:12px;\">(USER3)</span> </div>', 0, '2020-07-28 16:40:18'),
(418, '<div class=\"alert alert-danger\">Removed :) 1 Product removed By &mdash; Faizur Rahman <span style=\"font-size:12px;\">(USER3)</span> </div>', 0, '2020-07-28 16:41:37'),
(419, '<div class=\"alert alert-danger\">Removed :) 1 Product removed By &mdash; Faizur Rahman <span style=\"font-size:12px;\">(USER3)</span> </div>', 0, '2020-07-28 16:41:44'),
(420, '<div class=\"alert alert-success\">Success :) 1 SIM Add By &mdash; Faizur Rahman <span style=\"font-size:12px;\">(USER3)</span> </div>', 0, '2020-07-28 16:43:18'),
(421, '<div class=\"alert alert-warning\">Success :) Update Product By &mdash; Faizur Rahman <span style=\"font-size:12px;\">(USER3)</span> </div>', 0, '2020-07-28 16:44:10'),
(422, '<div class=\"alert alert-success\">Success :) 1 SIM Add By &mdash; Faizur Rahman <span style=\"font-size:12px;\">(USER3)</span> </div>', 0, '2020-07-28 17:06:48'),
(423, '<div class=\"alert alert-danger\">Removed :) 1 Product removed By &mdash; Faizur Rahman <span style=\"font-size:12px;\">(USER3)</span> </div>', 0, '2020-07-28 17:15:10'),
(424, '<div class=\"alert alert-danger\">Removed :) 1 Product removed By &mdash; Faizur Rahman <span style=\"font-size:12px;\">(USER3)</span> </div>', 0, '2020-07-28 17:15:13'),
(425, '<div class=\"alert alert-success\">Success :) 1 SIM Add By &mdash; Faizur Rahman <span style=\"font-size:12px;\">(USER3)</span> </div>', 0, '2020-07-28 17:15:39'),
(426, '<div class=\"alert alert-success\">Success :) 1 SIM Add By &mdash; Faizur Rahman <span style=\"font-size:12px;\">(USER3)</span> </div>', 0, '2020-07-28 17:15:56'),
(427, '<div class=\"alert alert-warning\">Success :) Update Product By &mdash; Faizur Rahman <span style=\"font-size:12px;\">(USER3)</span> </div>', 0, '2020-07-28 17:16:11'),
(428, '<div class=\"alert alert-success\">Success :) Sold Product By &mdash; Faizur Rahman <span style=\"font-size:12px;\">(USER3)</span> </div>', 0, '2020-07-28 19:17:20'),
(429, '<div class=\"alert alert-success\">Success :) SIM Sale By &mdash; Faizur Rahman <span style=\"font-size:12px;\">(USER3)</span> </div>', 0, '2020-07-28 19:24:26'),
(430, '<div class=\"alert alert-success\">Success :) SIM Sale By &mdash; Faizur Rahman <span style=\"font-size:12px;\">(USER3)</span> </div>', 0, '2020-07-28 19:27:38'),
(431, '<div class=\"alert alert-success\">Success :) SIM Sale By &mdash; Faizur Rahman <span style=\"font-size:12px;\">(USER3)</span> </div>', 0, '2020-07-28 19:32:49'),
(432, '<div class=\"alert alert-success\">Success :) SIM Sale By &mdash; Faizur Rahman <span style=\"font-size:12px;\">(USER3)</span> </div>', 0, '2020-07-28 19:33:20'),
(433, '<div class=\"alert alert-success\">Success :) SIM Sale By &mdash; Faizur Rahman <span style=\"font-size:12px;\">(USER3)</span> </div>', 0, '2020-07-28 19:33:27'),
(434, '<div class=\"alert alert-success\">Success :) SIM Sale By &mdash; Faizur Rahman <span style=\"font-size:12px;\">(USER3)</span> </div>', 0, '2020-07-28 19:39:17'),
(435, '<div class=\"alert alert-success\">Success :) SIM Sale By &mdash; Faizur Rahman <span style=\"font-size:12px;\">(USER3)</span> </div>', 0, '2020-07-28 19:39:34'),
(436, '<div class=\"alert alert-success\">Success :) Logo Updated By &mdash; Faizur Rahman <span style=\"font-size:12px;\">(USER3)</span> </div>', 0, '2020-07-29 08:35:58'),
(437, '<div class=\"alert alert-warning\">Success :) Update User By &mdash; Faizur Rahman <span style=\"font-size:12px;\">(USER3)</span> </div>', 0, '2020-07-29 08:36:37'),
(438, '<div class=\"alert alert-success\">Success :) SIM Sale By &mdash; Islam Hossain <span style=\"font-size:12px;\">(ADMIN)</span> </div>', 0, '2020-07-29 17:57:50'),
(439, '<div class=\"alert alert-success\">Success :) SIM Sale By &mdash; Islam Hossain <span style=\"font-size:12px;\">(ADMIN)</span> </div>', 0, '2020-07-29 17:58:00'),
(440, '<div class=\"alert alert-success\">Success :) SIM Sale By &mdash; Islam Hossain <span style=\"font-size:12px;\">(ADMIN)</span> </div>', 0, '2020-07-29 17:58:16'),
(441, '<div class=\"alert alert-success\">Success :) SIM Sale By &mdash; Islam Hossain <span style=\"font-size:12px;\">(ADMIN)</span> </div>', 0, '2020-07-29 17:58:31'),
(442, '<div class=\"alert alert-success\">Success :) 1 SIM Add By &mdash; Islam Hossain <span style=\"font-size:12px;\">(ADMIN)</span> </div>', 0, '2020-07-29 18:00:42'),
(443, '<div class=\"alert alert-success\">Success :) SIM Sale By &mdash; Islam Hossain <span style=\"font-size:12px;\">(ADMIN)</span> </div>', 0, '2020-07-29 18:01:02'),
(444, '<div class=\"alert alert-success\">Success :) 1 SIM Add By &mdash; Islam Hossain <span style=\"font-size:12px;\">(ADMIN)</span> </div>', 0, '2020-07-30 16:06:09'),
(445, '<div class=\"alert alert-success\"> Success :) Site Info Updated By &mdash; Islam Hossain <span style=\"font-size:12px;\">(ADMIN)</span> </div>', 0, '2020-07-30 16:17:02'),
(446, '<div class=\"alert alert-warning\">Success :) Update User By &mdash; Islam Hossain <span style=\"font-size:12px;\">(ADMIN)</span> </div>', 0, '2020-07-30 16:20:47'),
(447, '<div class=\"alert alert-warning\">Success :) Update User By &mdash; Islam Hossain <span style=\"font-size:12px;\">(ADMIN)</span> </div>', 0, '2020-07-30 16:21:05'),
(448, '<div class=\"alert alert-warning\">Success :) Update User By &mdash; Islam Hossain <span style=\"font-size:12px;\">(ADMIN)</span> </div>', 0, '2020-07-30 16:21:29'),
(449, '<div class=\"alert alert-warning\">Success :) Update User By &mdash; Islam Hossain <span style=\"font-size:12px;\">(ADMIN)</span> </div>', 0, '2020-07-30 16:25:27'),
(450, '<div class=\"alert alert-success\">Success :) 1 SIM Add By &mdash; Masud  Rana <span style=\"font-size:12px;\">(USER3)</span> </div>', 0, '2020-07-30 16:45:28'),
(451, '<div class=\"alert alert-warning\">Success :) Update Product By &mdash; Masud  Rana <span style=\"font-size:12px;\">(USER3)</span> </div>', 0, '2020-07-30 16:46:15'),
(452, '<div class=\"alert alert-danger\">Removed :) 1 Product removed By &mdash; Masud  Rana <span style=\"font-size:12px;\">(USER3)</span> </div>', 0, '2020-07-30 16:48:32'),
(453, '<div class=\"alert alert-success\">Success :) SIM Sale By &mdash; Masud  Rana <span style=\"font-size:12px;\">(USER3)</span> </div>', 0, '2020-07-30 16:50:27'),
(454, '<div class=\"alert alert-success\">Success :) 1 SIM Add By &mdash; Masud  Rana <span style=\"font-size:12px;\">(ADMIN)</span> </div>', 0, '2020-08-05 18:07:19'),
(455, '<div class=\"alert alert-success\">Success :) SIM Sale By &mdash; Masud  Rana <span style=\"font-size:12px;\">(ADMIN)</span> </div>', 0, '2020-08-05 18:24:15'),
(456, '<div class=\"alert alert-success\">Success :) Logo Updated By &mdash; Masud  Rana <span style=\"font-size:12px;\">(ADMIN)</span> </div>', 0, '2020-08-05 18:47:01'),
(457, '<div class=\"alert alert-warning\">Success :) Invoice Header Updated By &mdash; Masud  Rana <span style=\"font-size:12px;\">(ADMIN)</span> </div>', 0, '2020-08-05 18:47:42');

-- --------------------------------------------------------

--
-- Table structure for table `tb_options`
--

CREATE TABLE `tb_options` (
  `options_id` int(11) NOT NULL,
  `company_title` varchar(255) NOT NULL,
  `company_logo` varchar(255) NOT NULL,
  `company_slogan` text NOT NULL,
  `company_mobile` varchar(255) NOT NULL,
  `company_address` text NOT NULL,
  `invoice_header` varchar(255) NOT NULL,
  `invoice_seal` varchar(255) NOT NULL,
  `invoice_paid_seal` varchar(255) NOT NULL,
  `site_status` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tb_options`
--

INSERT INTO `tb_options` (`options_id`, `company_title`, `company_logo`, `company_slogan`, `company_mobile`, `company_address`, `invoice_header`, `invoice_seal`, `invoice_paid_seal`, `site_status`) VALUES
(1, 'Vip_sim', 'Logo_1596653221Untitled.png', 'Clean Business Calculation !', '+880 1710 001337', '127/A, Katashur, Mohammadpur, Dhaka-1207', 'Inv_header_1596653262Untitled.png', 'Inv_seal_1575008981bg.png', 'Inv_Paid_1575008886Inv_Paid_1574837624output-onlinepngtools.png', 1);

-- --------------------------------------------------------

--
-- Table structure for table `tb_sale`
--

CREATE TABLE `tb_sale` (
  `sale_id` int(11) NOT NULL,
  `sim_name` varchar(255) NOT NULL,
  `sim_id` varchar(255) NOT NULL,
  `sim_number` varchar(255) NOT NULL,
  `category` varchar(255) NOT NULL,
  `sim_condition` varchar(255) NOT NULL,
  `buy_date` varchar(255) NOT NULL,
  `have_name` varchar(255) NOT NULL,
  `buy_price` varchar(255) NOT NULL,
  `seller_name` varchar(255) NOT NULL,
  `sale_date` varchar(255) NOT NULL,
  `sale_price` varchar(255) NOT NULL,
  `status` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `created_by` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `tb_sim`
--

CREATE TABLE `tb_sim` (
  `sim_id` int(11) NOT NULL,
  `sim_name` varchar(255) NOT NULL,
  `sim_number` varchar(255) NOT NULL,
  `category` varchar(255) NOT NULL,
  `sim_condition` varchar(255) NOT NULL,
  `buy_date` varchar(255) NOT NULL,
  `have_name` varchar(255) NOT NULL,
  `buy_price` varchar(255) NOT NULL,
  `status` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `created_by` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `tb_stock`
--

CREATE TABLE `tb_stock` (
  `stock_id` int(11) NOT NULL,
  `product_id` varchar(255) NOT NULL,
  `stock_amount` varchar(255) NOT NULL,
  `stock_by` varchar(255) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `status` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `tb_user`
--

CREATE TABLE `tb_user` (
  `id` int(11) NOT NULL,
  `user_id` varchar(255) NOT NULL,
  `firstname` varchar(255) NOT NULL,
  `lastname` varchar(255) NOT NULL,
  `image` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `phone` varchar(255) NOT NULL,
  `types` varchar(255) NOT NULL,
  `address` text NOT NULL,
  `status` int(11) NOT NULL,
  `permission` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `created_by` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tb_user`
--

INSERT INTO `tb_user` (`id`, `user_id`, `firstname`, `lastname`, `image`, `email`, `password`, `phone`, `types`, `address`, `status`, `permission`, `created_at`, `created_by`) VALUES
(17, 'ADMIN', 'Masud ', 'Rana', 'Masud Rana_1596126327_qq.jpg', 'masudrana@gmail.com', '73acd9a5972130b75066c82595a1fae3', '+880 1914 441334', 'admin', 'Dhaka\r\n', 1, 1, '2020-08-05 17:48:49', ''),
(18, 'USER1', 'Fatema', 'Jannat', 'FatemaJannat_1575008722_25.jpg', 'fatemajannat.cse@gmail.com', '9f693771ca12c43759045cdf4295e9f5', '+990 9898 989898', 'Salesman', 'Dhaka, Bangladesh - 1209', 0, 1, '2020-08-03 17:18:01', ''),
(19, 'USER2', 'Masud', 'Rana', 'Masud101Rana101_1574083365_user.png', 'mail@mail.com', '009ab43667ea90b50b741d89cbf76f1b', '+990 9898 989898', 'Manager', 'Dhaka, Bangladesh - 1209', 0, 0, '2019-11-28 08:54:13', ''),
(20, 'USER3', 'Masud ', 'Rana', 'FaizurRahman_1575008179_21.JPG', '', 'c5b111077f75f96c354597ce99437fa8', '', 'Salesman', '', 1, 1, '2020-08-05 16:49:16', '');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tb_activity`
--
ALTER TABLE `tb_activity`
  ADD PRIMARY KEY (`activity_id`);

--
-- Indexes for table `tb_options`
--
ALTER TABLE `tb_options`
  ADD PRIMARY KEY (`options_id`);

--
-- Indexes for table `tb_sale`
--
ALTER TABLE `tb_sale`
  ADD PRIMARY KEY (`sale_id`);

--
-- Indexes for table `tb_sim`
--
ALTER TABLE `tb_sim`
  ADD PRIMARY KEY (`sim_id`);

--
-- Indexes for table `tb_stock`
--
ALTER TABLE `tb_stock`
  ADD PRIMARY KEY (`stock_id`);

--
-- Indexes for table `tb_user`
--
ALTER TABLE `tb_user`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `tb_activity`
--
ALTER TABLE `tb_activity`
  MODIFY `activity_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=458;

--
-- AUTO_INCREMENT for table `tb_options`
--
ALTER TABLE `tb_options`
  MODIFY `options_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `tb_sale`
--
ALTER TABLE `tb_sale`
  MODIFY `sale_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `tb_sim`
--
ALTER TABLE `tb_sim`
  MODIFY `sim_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `tb_stock`
--
ALTER TABLE `tb_stock`
  MODIFY `stock_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `tb_user`
--
ALTER TABLE `tb_user`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
