			    <!--/.span3-->
			<div class="span9">
				<div class="content">
								<!------>
								<?php echo $this->session->flashdata('msg'); ?>
								<!------>
					<div class="module">
						<div class="module-head">
							<h3> sim Update </h3>
						</div>
						<?php 
							if($pData->types == 'Owner' or $pData->types == 'admin'){
						?><div class="module-body">

								<form action="<?php echo base_url('index.php/AppsFunctions/SimUpdateMethod/'); ?>" method="post" class="form-horizontal row-fluid">
									<input type="hidden" name="sim_id" value="<?php echo $simData->sim_id; ?>">
								
										<div class="control-group">
											<label class="control-label" for="sim_name"> SIM Name</label>
											<div class="controls">
												<select name="sim_name" class="span8">
												<?php 
													if($simData->sim_name=='gp'){
												?>
													<option value="gp" selected>Grameenphone</option>
													<option value="bl">Banglalink</option>
													<option value="robi">Robi</option>
													<option value="airtel">Airtel </option>
													<option value="teletalk">Teletalk</option>
												<?php		
													}elseif ($simData->sim_name=='bl') {
												?>
													<option value="gp">Grameenphone</option>
													<option value="bl" selected>Banglalink</option>
													<option value="robi">Robi</option>
													<option value="airtel">Airtel</option>
													<option value="teletalk">Teletalk</option>
												<?php		
													}elseif ($simData->sim_name=='robi') {
												?>
													<option value="gp">Grameenphone</option>
													<option value="bl">Banglalink</option>
													<option value="robi" selected>Robi</option>
													<option value="airtel">Airtel </option>
													<option value="teletalk">Teletalk</option>
												<?php		
													}elseif ($simData->sim_name=='airtel') {
												?>
													<option value="gp">Grameenphone </option>
													<option value="bl">Banglalink</option>
													<option value="robi">Robi</option>
													<option value="airtel" selected>Airtel </option>
													<option value="teletalk">Teletalk</option>
												<?php		
													}elseif ($simData->sim_name=='teletalk') {
												?>
													<option value="gp">Grameenphone </option>
													<option value="bl">Banglalink</option>
													<option value="robi">Robi</option>
													<option value="airtel">Airtel </option>
													<option value="teletalk" selected>Teletalk</option>
												<?php 		
													}
												?>
												</select>
											</div>
										</div>

										<div class="control-group">
											<label class="control-label" for="sim_number">SIM Number</label>
											<div class="controls">
												<input name="sim_number" type="number" id="sim_number" value="<?php echo $simData->sim_number;?>" class="span8" >
											</div>
										</div>
										<div class="control-group">
											<label class="control-label" for="category">Category</label>
											<div class="controls">
												<select name="category" class="span8">
												 <?php 
												if($simData->category=='prepaid'){ 
												?> 
												<option value="prepaid" selected>Prepaid</option>
												<option value="postpaid">Postpaid</option>
												<option value="skitto" >Skitto</option>
												<option value="pollio" >Polli</option>
												<?php
													}elseif ($simData->category=='postpaid') {
												?>
												<option value="prepaid" >Prepaid</option>
												<option value="postpaid" selected>Postpaid</option>
												<option value="skitto" >Skitto</option>
												<option value="pollio" >Polli</option>
												<?php
													}elseif ($simData->category=='skitto') {
												?>
												<option value="prepaid" >Prepaid</option>
												<option value="postpaid" >Postpaid</option>
												<option value="skitto" selected>Skitto</option>
												<option value="pollio" >Polli</option>
												<?php
													}elseif ($simData->category=='pollio') {
												?>
												<option value="prepaid" >Prepaid</option>
												<option value="postpaid" >Postpaid</option>
												<option value="skitto" >Skitto</option>
												<option value="pollio" selected>Polli</option>
												<?php
													}
												?>
												</select>
											</div>
										</div>

										<div class="control-group">
											<label class="control-label" for="sim_condition">Condition</label>
											<div class="controls">
												<select name="sim_condition" class="span8">
													<?php 
														if($simData->sim_condition=='new'){
													?>
													<option value="new" selected >New</option>
													<option value="use">Use</option>
													<option value="intact">Intact</option>
													<?php
														}elseif ($simData->sim_condition=='use') {
													?>
													<option value="new">New</option>
													<option value="use" selected>Use</option>
													<option value="intact">Intact</option>
													<?php
														}elseif ($simData->sim_condition=='intact') {
													?>
													<option value="new">New</option>
													<option value="use">Use</option>
													<option value="intact" selected>Intact</option>
													<?php
														}
													?>
												</select>
											</div>
										</div>

										<div class="control-group">
											<label class="control-label" for="buy_date">Buy Date</label>
											<div class="controls">
												<input name="buy_date" type="date" id="buy_date" value="<?php echo $simData->buy_date;?>" class="span8" >
											</div>
										</div>
										<div class="control-group">
											<label class="control-label" for="have_name">Have Name</label>
											<div class="controls">
												<input name="have_name" type="text" id="have_name" value="<?php echo $simData->have_name;?>"class="span8" required="">
											</div>
										</div>
										<div class="control-group">
											<label class="control-label" for="buy_price">Buy price</label>
											<div class="controls">
												<input name="buy_price" type="text" id="buy_price" value="<?php echo $simData->buy_price;?>"class="span8" required="">
											</div>
										</div>
										
										<div class="control-group">
											<div class="controls">
												<button type="submit" class="btn btn-warning">Edit</button>
											</div>
										</div>
									</form>
						</div>
						<?php
						}elseif($pData->types == 'Salesman' or $pData->types == 'Manager'){
						?><div class="module-body">

								<form action="<?php echo base_url('index.php/AppsFunctions/SimUpdateMethod/'); ?>" method="post" class="form-horizontal row-fluid">
									<input type="hidden" name="sim_id" value="<?php echo $simData->sim_id; ?>">
									<input type="hidden" name="sim_name" value="<?php echo $simData->sim_name; ?>">
									<input name="sim_number" type="hidden"  value="<?php echo $simData->sim_number;?>" >
									<input name="category" type="hidden"  value="<?php echo $simData->category;?>" >
									<input name="sim_condition" type="hidden"  value="<?php echo $simData->sim_condition;?>" >
									<input name="buy_date" type="hidden"  value="<?php echo $simData->buy_date;?>" >
									<input name="buy_price" type="hidden"  value="<?php echo $simData->buy_price;?>" >

										<div class="control-group">
											<label class="control-label" for="have_name">Have Name<small>(change)</small></label>
											<div class="controls">
												<input name="have_name" type="text" id="have_name" value="<?php echo $simData->have_name;?>"class="span8" required="">
											</div>
										</div>
										
										<div class="control-group">
											<div class="controls">
												<button type="submit" class="btn btn-warning">Edit</button>
											</div>
										</div>
									</form>
						</div>
					<?php }?>
						

					</div>

				</div><!--/.content-->
			</div><!--/.span9-->
		</div>
	</div><!--/.container-->
</div><!--/.wrapper-->
