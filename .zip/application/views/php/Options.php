                    <div class="span9">
                        <div class="content">

                            <div class="btn-controls">
                                <div class="btn-box-row row-fluid">
                                    <?php echo form_open_multipart('AppsFunctions/logoupdate/'); ?>
                                        <div href="#" class="btn-box big span4" style="max-height: 98px; min-height: 98px; ">
                                            <img src="<?php echo base_url(); ?>/images/<?php echo $optionsData->company_logo; ?>" alt="company_logo" style="width:90%; height: 80px;margin-top:-17px;" class="img"/>
                                        </div>

                                        <div href="#" class="btn-box big span8" style=" min-height:98px; ">

                                            <input type="hidden" name="options_id" value="<?php echo $optionsData->options_id;?>">
                                            <input type="hidden" name="old_logo" value="<?php echo $optionsData->company_logo;?>">

                                            <input type="file" name="company_logo" class="form-control">
                                            <button type="submit" class="btn btn-primary">Change Logo</button>
                                        </div>
                                    </form>
                                </div>
                                <div class="btn-box-row row-fluid">
                                     <?php echo form_open_multipart('AppsFunctions/ChangeInvoiceHeader/'); ?>
                                        <div href="#" class="btn-box big span4" style="max-height: 98px; min-height: 98px; ">
                                            <img src="<?php echo base_url(); ?>/images/<?php echo $optionsData->invoice_header; ?>" alt="invoice_header" style="width:90%; height: 80px;margin-top:-17px;"  class="img"/>
                                        </div>
                                        <div href="#" class="btn-box big span8" style=" min-height:98px; ">

                                            <input type="hidden" name="options_id" value="<?php echo $optionsData->options_id;?>">
                                            <input type="hidden" name="old_invoice_header" value="<?php echo $optionsData->invoice_header;?>">

                                            <input type="file" name="invoice_header" class="form-control">
                                            <button type="submit" class="btn btn-primary">Change Invoice Header</button>
                                        </div>
                                    </form>
                                </div>
                                <div class="btn-box-row row-fluid">
                                   <?php echo form_open_multipart('AppsFunctions/ChangeInvoiceSeal/'); ?>
                                        <div href="#" class="btn-box big span4" style="max-height: 98px; min-height: 98px; ">
                                            <img src="<?php echo base_url(); ?>/images/<?php echo $optionsData->invoice_seal; ?>" alt="invoice_seal"  style="width:90%; height: 80px;margin-top:-17px;" />
                                        </div>
                                        <div href="#" class="btn-box big span8" style=" min-height:98px; ">

                                            <input type="hidden" name="options_id" value="<?php echo $optionsData->options_id;?>">
                                            <input type="hidden" name="old_invoice_seal" value="<?php echo $optionsData->invoice_seal;?>">

                                            <input type="file" name="invoice_seal" class="form-control">
                                            <button type="submit" class="btn btn-primary">Change Invoice Seal</button>
                                        </div>
                                    </form>
                                </div>
                                <div class="btn-box-row row-fluid">
                                   <?php echo form_open_multipart('AppsFunctions/ChangeInvoicePaidSeal/'); ?>

                                        <div href="#" class="btn-box big span4" style="max-height: 120px; min-height: 120px; ">
                                            <img src="<?php echo base_url(); ?>/images/<?php echo $optionsData->invoice_paid_seal; ?>" alt="invoice_paid_seal" style="width:90%; height: 80px;margin-top:-17px;" />
                                        </div>
                                        <div href="#" class="btn-box big span8" style="max-height: 120px; min-height:120px; ">

                                            <input type="hidden" name="options_id" value="<?php echo $optionsData->options_id;?>">
                                            <input type="hidden" name="old_invoice_paid_seal" value="<?php echo $optionsData->invoice_paid_seal;?>">

                                            <input type="file" name="invoice_paid_seal" class="form-control">
                                            <button type="submit" class="btn btn-primary">Change Invoice Paid Seal</button>
                                        </div>
                                    </form>
                                </div>



                                <div class="btn-box-row row-fluid">
                                    <div href="#" class="btn-box big span8">

                                     <form action="<?php echo base_url('index.php/AppsFunctions/OptionsUpdateMethod/');?>" method="post" class="form-horizontal row-fluid">

                                        <input type="hidden" name="options_id" value="<?php echo $optionsData->options_id;?>">

                                        <div class="control-group">
                                            <label class="control-label" for="company_title"> Title</label>
                                            <div class="controls">
                                                <input name="company_title" type="text" id="company_title" class="span10" value="<?php echo $optionsData->company_title; ?>">
                                            </div>
                                        </div>
                                        <div class="control-group">
                                            <label class="control-label" for="company_slogan">Slogan</label>
                                            <div class="controls">
                                                <textarea name="company_slogan" class="span10" id="company_slogan"><?php echo $optionsData->company_slogan; ?></textarea>
                                            </div>
                                        </div>
                                        <div class="control-group">
                                            <label class="control-label" for="company_mobile"> Phone</label>
                                            <div class="controls">
                                                <input name="company_mobile" type="text" id="company_mobile" class="span10" value="<?php echo $optionsData->company_mobile; ?>">
                                            </div>
                                        </div>
                                        <div class="control-group">
                                            <label class="control-label" for="company_address">Address</label>
                                            <div class="controls">
                                                <textarea name="company_address" rows="3" class="span10" id="company_address"><?php echo $optionsData->company_address; ?></textarea>
                                            </div>
                                        </div>
                                        <div class="control-group">
                                            <div class="controls" style="text-align: right; margin-right: 32px;">
                                                <button type="submit" class="btn  btn-primary">Update Company Info</button>
                                            </div>
                                        </div>
                                    </form>
                                    <hr/>
<div class="btn-group btn-group-justified" role="group" aria-label="...">

                    
<?php 
    if($optionsData->site_status==0){
?>
  <div class="btn-group" role="group">

    <a href="<?php echo base_url('index.php/AppsFunctions/OptionsStatusActiveMethod/'); ?><?php echo $optionsData->options_id; ?>" type="button" class="btn btn-primary btn-lg">ON</a>
  </div>
  <div class="btn-group" role="group">
    <a type="button" class="btn btn-default btn-lg">OFF</a>
  </div>
<?php 
    }else{
?>
  <div class="btn-group" role="group">
    <a href="" type="button" class="btn btn-default btn-lg">ON</a>
  </div>

  <div class="btn-group" role="group">
    <a href="<?php echo base_url('index.php/AppsFunctions/OptionsStatusInActiveMethod/'); ?><?php echo $optionsData->options_id; ?>" type="button" class="btn btn-primary btn-lg">OFF</a>
  </div>

<?php  
    }
?>
</div>
<!------------->
                                    </div>

 

                                    <div href="#" class="btn-box big span4">
                                    <ul class="widget widget-usage unstyled">
                                        <li>
                                            <p style="text-align: left; ">
                                                <strong>Windows 8</strong> 
                                                <span class="pull-right small muted">78%</span>
                                            </p>
                                            <div class="progress tight">
                                                <div class="bar" style="width: 78%;">
                                                </div>
                                            </div>
                                        </li>
                                        <li>
                                            <p style="text-align: left; ">
                                                <strong>Mac</strong> <span class="pull-right small muted">56%</span>
                                            </p>
                                            <div class="progress tight">
                                                <div class="bar bar-success" style="width: 56%;">
                                                </div>
                                            </div>
                                        </li>
                                        <li>
                                            <p style="text-align: left; ">
                                                <strong>Linux</strong> <span class="pull-right small muted">44%</span>
                                            </p>
                                            <div class="progress tight">
                                                <div class="bar bar-warning" style="width: 44%;">
                                                </div>
                                            </div>
                                        </li>
                                        <li>
                                            <p style="text-align: left; ">
                                                <strong>Linux</strong> <span class="pull-right small muted">44%</span>
                                            </p>
                                            <div class="progress tight">
                                                <div class="bar bar-warning" style="width: 44%;">
                                                </div>
                                            </div>
                                        </li>
                                        <li>
                                            <p style="text-align: left; ">
                                                <strong>Linux</strong> <span class="pull-right small muted">44%</span>
                                            </p>
                                            <div class="progress tight">
                                                <div class="bar bar-warning" style="width: 44%;">
                                                </div>
                                            </div>
                                        </li>
                                        <li>
                                            <p style="text-align: left; ">
                                                <strong>iPhone</strong> <span class="pull-right small muted">67%</span>
                                            </p>
                                            <div class="progress tight">
                                                <div class="bar bar-danger" style="width: 67%;">
                                                </div>
                                            </div>
                                        </li>
                                    </ul>
                                    </div>

                                </div>

                                <div class="btn-box-row row-fluid">


                                </div>
                            </div>

                        </div>
                        <!--/.content-->
                    </div>
                    <!--/.span9-->
                </div>
            </div>
            <!--/.container-->
        </div>
        <!--/.wrapper-->
