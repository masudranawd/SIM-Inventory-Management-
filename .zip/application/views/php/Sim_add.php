﻿                    <!--/.span3-->
				<div class="span9">
					<div class="content">
									<!------>
									<?php echo $this->session->flashdata('msg'); ?>
									<!------>
						<div class="module">
							<div class="module-head">
								<h3> SIM Add </h3>
							</div>
							<div class="module-body">

									<form action="<?php echo base_url('index.php/AppsFunctions/SimAddMethod/'); ?>" method="post" class="form-horizontal row-fluid">
										<div class="control-group">
											<label class="control-label" for="sim_name"> SIM Name</label>
											<div class="controls">
												<select name="sim_name" class="span8" required="">
													<option value="">Select Sim Name !</option>
													<option value="gp">Grameenphone</option>
													<option value="bl">Banglalink</option>
													<option value="robi">Robi</option>
													<option value="airtel">Airtel</option>
													<option value="teletalk">Teletalk</option>
												</select>
											</div>
										</div>
										<div class="control-group">
											<label class="control-label" for="sim_number">SIM Number</label>
											<div class="controls">
												<input name="sim_number" type="number" id="sim_number" placeholder="Enter SIM Number !" class="span8" >
											</div>
										</div>
										<div class="control-group">
											<label class="control-label" for="category">Category</label>
											<div class="controls">
												<select name="category" class="span8" required="">
													<option value="">Select Category </option>
													<option value="prepaid">Prepaid</option>
													<option value="postpaid">Postpaid</option>
													<option value="skitto">Skitto</option>
													<option value="pollio">Polli</option>
												</select>
											</div>
										</div>

										<div class="control-group">
											<label class="control-label" for="sim_condition">Condition</label>
											<div class="controls">
												<select name="sim_condition" class="span8" required="">
													<option value="">Select Condition </option>
													<option value="new">New</option>
													<option value="use">Use</option>
													<option value="intact">Intact</option>
												</select>
											</div>
										</div>

										<div class="control-group">
											<label class="control-label" for="buy_date">Buy Date</label>
											<div class="controls">
												<input name="buy_date" type="date" id="buy_date" placeholder="Enter Buy Date !" class="span8" required="">
											</div>
										</div>
										<div class="control-group">
											<label class="control-label" for="have_name">Have Name</label>
											<div class="controls">
												<input name="have_name" type="text" id="have_name" placeholder="Enter Have Name !" class="span8" required="">
											</div>
										</div>
										<div class="control-group">
											<label class="control-label" for="buy_price">Buy price</label>
											<div class="controls">
												<input name="buy_price" type="text" id="buy_price" placeholder="Enter Buy Price !" class="span8" required="">
											</div>
										</div>
										
										<div class="control-group">
											<div class="controls">
												<button type="submit" class="btn btn-primary">Add SIM</button>
											</div>
										</div> 
									</form>
							</div>

						</div>				
					</div><!--/.content-->
				</div><!--/.span9-->
			</div>
		</div><!--/.container-->
	</div><!--/.wrapper-->
