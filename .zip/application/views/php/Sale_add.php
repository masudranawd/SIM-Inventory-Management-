

					<div class="span9">
						<div class="content">
	
							<div class="module">
								<div class="module-head">
									<center><h3>Sale SIM Table</h3></center>
								</div>
								<div class="module-body table">

									<table cellpadding="0" cellspacing="0" border="0" class="datatable-1 table table-bordered table-striped	 display" width="100%">		
									<thead>
										<tr>
											<th>SL</th>
											<th>Name</th>
											<th>Number</th>
											<th>category</th>
											<th>Condition</th>
											<th>Buy Date</th>
											<th>Have Name</th>
											<th>Buy Price</th>
											<th>Action</th>
										</tr>
									</thead>
									<tbody>
									<?php
										$i = 0;
										foreach($simDataList as $simData ){
											$i++;
									?>
										<tr class="odd gradeX">
											<td><?php echo $i;?></td>
											<td><b><?php echo $simData->sim_name;?></b></td>
											<td><?php echo $simData->sim_number;?></td>
											<td><?php echo $simData->category;?></td>
											<td><?php echo $simData->sim_condition;?></td>
											<td><?php echo $simData->buy_date;?></td>
											<td><?php echo $simData->have_name;?></td>
											<td class="center"><?php echo $simData->buy_price;?>|-</td>
											<td class="center" style="width:12%;">
												<span>
													<a href="" class="btn btn-warning"  type="button" class="btn btn-info btn-lg" data-toggle="modal" data-target="#myModal<?php echo $simData->sim_id; ?>">BUY 
													</a>				
												</span>
											</td>
										</tr><!-- Modal -->
	<div class="modal fade" id="myModal<?php echo $simData->sim_id; ?>" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
	  <div class="modal-dialog" role="document">
	    <div class="modal-content">
		<form action="<?php echo base_url('index.php/AppsFunctions/AddToSale/'); ?>" method="post" class="form-horizontal">
	      <div class="modal-header">
 	      <div class="modal-header">
	        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
	        <h4 class="modal-title" id="myModalLabel"> <span style="color:teal;font-size:16px;"> Sale Now 
	        </span>SIM: <span style="color:orange;font-size:16px;"><?php echo $simData->sim_name;?></span> &nbsp;&nbsp; Num:  <span style="color:orange;font-size:16px;"><?php echo $simData->sim_number; ?></span>&nbsp;&nbsp;Price: <span style="color:orange;font-size:16px;"> <?php echo sprintf("%0.2f",$simData->buy_price); ?></span></h4>
	      </div>
	      <div class="modal-body">
	<!---form--->
	  <div class="control-group">
	  	<input type="hidden" name="sim_name" value="<?php echo $simData->sim_name;?>">
	  	<input type="hidden" name="sim_number" value="<?php echo $simData->sim_number;?>">
	  	<input type="hidden" name="category" value="<?php echo $simData->category;?>">
	  	<input type="hidden" name="sim_condition" value="<?php echo $simData->sim_condition;?>" >
	  	<input type="hidden" name="buy_date" value="<?php echo $simData->buy_date; ?>" >
	  	<input type="hidden" name="have_name" value="<?php echo $simData->have_name; ?>" >
	  	<input type="hidden" name="buy_price" value="<?php echo $simData->buy_price; ?>" >
	  	<input type="hidden" name="sim_id" value="<?php echo $simData->sim_id; ?>" >
	    <input name="seller_name" type="text" class="form-control" id="quantity" style="width:97%;" placeholder="Enter Seller Name !" required="">
	    <input name="sale_price" type="text" class="form-control" id="quantity" style="width:97%;" placeholder="Enter Sale Price !" required="">
	  </div>
	<!---------->
	      <div class="modal-footer">
	        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
	        <button type="submit" class="btn btn-primary">Confirm</button>
	      </div>
	      </div>
	 	</form>     
	    </div>
	  </div>
	</div>
									<?php		
										}//end foreach..  
									?>
									</tbody>
						</table>
								</div>
							</div><!--/.module-->

						<br />
							
						</div><!--/.content-->
					</div><!--/.span9-->
				</div>
			</div><!--/.container-->
		</div><!--/.wrapper-->