            <!--/.span3-->
				<div class="span9">
					<div class="content">
									<!------>
									<?php echo $this->session->flashdata('msg'); ?>
									<!------>
						<div class="module">
							<div class="module-head">
								<h2 style="border-bottom: 1px solid #28262C; ">
									
									<b style="color:black;"><?php echo $profileData->firstname.' '.$profileData->lastname; ?></b>
								 	<small style=" ">
								 		( Type &mdash; <?php echo $profileData->types;?> || User ID &mdash; <?php echo $profileData->user_id;?> ) 
								 	</small>
								 </h2>
							</div>
							<div class="module-body">
								<?php echo form_open_multipart('User/UpdateUser/');?>
									<div class="form-horizontal row-fluid">

										<div class="control-group">
										<?php if($profileData->image != NULL){ ?>
											<label class="control-label" for="firsname">Change Profile</label>
											<div class="controls">
												<img src="<?php echo base_url('images/user/'); ?><?php echo $profileData->image; ?>" alt="n/a" class="span8" style="height:300px; ">

												<input type="hidden" name="old_image" class="span8 form-control" value="<?php echo $profileData->image; ?>">
												<input type="file" name="image" class="span8 form-control">
											</div><br/>
										<?php  }else{ ?>
											<label class="control-label" for="firsname">Upload Profile</label>
											<div class="controls">
												<input type="file" name="image" class="span8 form-control" alt="n/a">
											</div>
										<?php  } ?>
										</div>										
										
										<input type="hidden" name="id" value="<?php echo $profileData->id;?>">

										<div class="control-group">
											<label class="control-label" for="firstname">First Name</label>
											<div class="controls">
												<input name="firstname" type="text" id="firstname" class="span8" value="<?php echo $profileData->firstname; ?>" >
											</div>
										</div>	

										<div class="control-group">
											<label class="control-label" for="lastname">Last Name</label>
											<div class="controls">
												<input name="lastname" type="text" id="lastname" class="span8" value="<?php echo $profileData->lastname; ?>" >
											</div>
										</div>	

										<div class="control-group">
											<label class="control-label" for="email">Email</label>
											<div class="controls">
												<input name="email" type="text" id="email" class="span8" value="<?php echo $profileData->email; ?>" >
											</div>
										</div>	

										<div class="control-group">
											<label class="control-label" for="phone">Phone</label>
											<div class="controls">
												<input name="phone" type="text" id="phone" class="span8" value="<?php echo $profileData->phone; ?>" >
											</div>
										</div>	

										<div class="control-group">
											<label class="control-label" for="address">Address</label>
											<div class="controls">
												<textarea name="address" type="text" id="address" class="span8"><?php echo $profileData->address; ?></textarea>
											</div>
										</div>

										<div class="control-group">
											<div class="controls">
												<button type="submit" class="btn btn-primary">Update</button>	
											</div>
										</div>										

									</div>
									</form>

							</div>
						</div>

						
						
					</div><!--/.content-->
				</div><!--/.span9-->
			</div>
		</div><!--/.container-->
	</div><!--/.wrapper-->
