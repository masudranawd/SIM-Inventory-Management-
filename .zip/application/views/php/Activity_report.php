﻿                    <!--/.span3-->
				<div class="span9">
					<div class="content">
									<!------>
									<?php echo $this->session->flashdata('msg'); ?>
									<!------>
						<div class="module">
							<div class="module-head">
								<h3> Activity Reports ! </h3>
							</div>
							<div class="module-body">
							<?php 
								if($ActivityData){
								foreach ($ActivityData as $aData) {
							?>
							<div class="col-md-12 col-sm-12 clearfix">
								<div class="" style="width:80%; float: left;">
									<?php echo $aData->activity_details; ?>	
								</div>
								<div class="" style="width:20%; float: left; line-height: 40px;">
									&nbsp; At &mdash; <?php echo $aData->created_at; ?> 
								</div>
							</div>
							<?php 
									}//end of foreach 
								}//end of if..
								else{
									echo '<div class="alert alert-danger">NO RECENT ACTIVITY !</div>';
								}
							?>

							</div>
						</div>

						
						
					</div><!--/.content-->
				</div><!--/.span9-->
			</div>
		</div><!--/.container-->
	</div><!--/.wrapper-->