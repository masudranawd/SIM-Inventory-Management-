<?php 
//include tcpdf/library 
//include 'tcpdf/tcpdf.php'; 

//make TCPDF Object
$pdf = new TCPDF('p','mm','A4'); 
$pdf->SetFont('times', '', 12);

//remove default header & footer. 
$pdf->setPrintHeader(false); 
$pdf->setPrintFooter(false); 

//add page
$pdf->AddPage(); 


//add content
//USING CELL
//1# $pdf->Cell(190,10,'This is A cell',1,1,'C');

//using html cell || writeHTMLCell($w, $h, $x, $y, $html='', $border=0, $ln=0, $fill=0, $reseth=true, $align='', $autopadding=true)

$var = '<table border="1" style="text-align:center; font-size:10px; ">';
$var .= '<tr style="">
			<th style=" width:10mm;"><b>SL</b></th>
			<th style=" width:25mm;"><b>SIM Name</b></th>
			<th style=" width:30mm;"><b>SIM number</b></th>
			<th style=" width:20mm;"><b>Date</b></th>
			<th style=" width:25mm;"><b>Category</b></th>
			<th style=" width:20mm;"><b>Condition</b></th>
			<th style=" width:30mm;"><b>Name</b></th>
			<th style=" width:30mm;text-align:center;"><b>buy price</b></th>
		</tr>'; //TABLE HEAD


$i=0;$totalb = 0; 	
	foreach($simDataList as $simData){
		$i++; 
		$totalb = $totalb+$simData->buy_price; 

		$var .= '<tr>
			<td style="">'.$i.'</td>
			<td style="">'.$simData->sim_name.'</td>
			<td style="">'.$simData->sim_number.'</td>
			<td style="">'.$simData->buy_date.'</td>
			<td style="">'.$simData->category.'</td>
			<td style="">'.$simData->sim_condition.'</td>
			<td style="">'.$simData->have_name.'</td>
			<td >'.sprintf('%0.2f',$simData->buy_price).'</td>
		</tr>';

}

$var .= '<tr>
<td colspan="7" style="text-align:right;"><b>Total =</b></td><td > <b>'.sprintf('%0.2f',$totalb).'</b></td>
</tr>'; 
$var .= '</table>';



//$pdf->Image('1', 100, 100, 10 , 0, 'png', '', '', false, 300, '', false, false, 0, 'LB', false, false);
$pdf->Image(base_url('images/').$optionsData->invoice_header,10,10,190,25);

//$pdf->writeHTMLCell(74,0,10,100,'<P>Header OF VOUCHAR<P>',1,1); //HEADER..

$pdf->writeHTMLCell(190,0,12,40,'<b>Type : Airtel SIM Stock List</b>',0,0); 


$pdf->writeHTMLCell(150,0,8,50,$var,0,0); 
//$pdf->writeHTMLCell(190,0,10,225,'<P>FOOTER OF VOUCHAR<P>',1,1); //FOOTER..

//$pdf->Image('1.png',10,261,74,15);

//output / result..
$pdf->Output(); 