﻿			<div class="span9">
					<div class="content">

						<div class="module">
							<div class="module-head">
								<h3> Sale List  </h3>
							</div>
<?php 
	if($pData->types == 'Owner' or $pData->types == 'admin'){
?>

						<div class="module">
							<div class="module-body table">
								<table cellpadding="0" cellspacing="0" border="0" class="datatable-1 table table-bordered table-striped	 display" width="100%">		
									<thead>
										<tr>
											<th>SL</th>
											<th>Name</th>
											<th>Number</th>
											<th>category</th>
											<th>Condition</th>
											<th>seller Name</th>
											<th>Buy Date</th>
											<th>Sale Date</th>
											<th>Buy Price</th>
											<th>Sale Price</th>
											<th>##</th>
										</tr>
									</thead>
									<tbody>
									<?php
										$i = 0;
										foreach($saleDataList as $saleData ){
											$i++;
									?>
										<tr class="odd gradeX">
											<td><?php echo $i;?></td>
											<td><b><?php echo $saleData->sim_name;?></b></td>
											<td><?php echo $saleData->sim_number;?></td>
											<td><?php echo $saleData->category;?></td>
											<td><?php echo $saleData->sim_condition;?></td>
											<td><?php echo $saleData->seller_name;?></td>
											<td><?php echo $saleData->buy_date;?></td>
											<td><?php echo $saleData->created_at;?></td>
											<td class="center"><?php echo $saleData->buy_price;?>|-</td>
											<td class="center"><?php echo $saleData->sale_price;?>|-</td>
											<td class="center" style="width:12%;">
												<span>
												<span><a href="" class="btn btn-warning"  type="button" class="btn btn-info btn-lg" data-toggle="modal" data-target="#myModal<?php echo $saleData->sale_id; ?>">Edit 
													</a>
												</span>
												</span>
											</td>
										</tr><!-- Modal -->
	<div class="modal fade" id="myModal<?php echo $saleData->sale_id; ?>" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
	  <div class="modal-dialog" role="document">
	    <div class="modal-content">
		<form action="<?php echo base_url('index.php/AppsFunctions/saleToUpdate/'); ?><?php echo $saleData->sale_id; ?>" method="post" class="form-horizontal">
 	      <div class="modal-header">
	        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
	        <h4 class="modal-title" id="myModalLabel"> <span style="color:teal;font-size:16px;"> Edit Now  Num:  <span style="color:orange;font-size:16px;"><?php echo $saleData->sim_number; ?></span> &nbsp;&nbsp;
	        </span>Seller: <span style="color:orange;font-size:16px;"><?php echo $saleData->seller_name;?></span>&nbsp;&nbsp;Price: <span style="color:orange;font-size:16px;"><?php echo $saleData->sale_price;?></span></h4>
	      </div>
	      <div class="modal-body">
	<!---form--->
	  <div class="control-group">
	  	<input type="hidden" name="sale_id" value="<?php echo $saleData->sale_id;?>">
	  	<input type="hidden" name="sim_name" value="<?php echo $saleData->sim_name;?>">
	  	<input type="hidden" name="sim_number" value="<?php echo $saleData->sim_number;?>">
	  	<input type="hidden" name="category" value="<?php echo $saleData->category;?>">
	  	<input type="hidden" name="sim_condition" value="<?php echo $saleData->sim_condition;?>" >
	  	<input type="hidden" name="buy_date" value="<?php echo $saleData->buy_date; ?>" >
	  	<input type="hidden" name="have_name" value="<?php echo $saleData->have_name; ?>" >
	  	<input type="hidden" name="buy_price" value="<?php echo $saleData->buy_price; ?>" >
	  	<input type="hidden" name="sim_id" value="<?php echo $saleData->sim_id; ?>" >

		<div class="control-group">
			<label class="control-label" for="sim_number">Seller Name</label>
			<div class="controls">
	   			 <input name="seller_name" type="text" class="form-control" id="quantity" style="width:97%;" value="<?php echo $saleData->seller_name;?>">
			</div>
		</div>

		<div class="control-group">
			<label class="control-label" for="sim_number">Sale Price</label>
			<div class="controls">
	    		<input name="sale_price" type="text" class="form-control" id="quantity" style="width:97%;" value="<?php echo $saleData->sale_price;?>" required="">
			</div>
		</div>

	  </div>
	<!---------->
	      <div class="modal-footer">
	        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
	        <button type="submit" class="btn btn-primary">Confirm</button>
	      </div>
	      </div>
	 	</form>     
	    </div>
	  </div>
	</div>
									<?php		
										}//end foreach..  
									?>
									</tbody>
						</table>
					</div>
				</div><!--/.module-->

<?php
}elseif($pData->types == 'Salesman' or $pData->types == 'Manager'){
?>

						<div class="module">
							<div class="module-body table">
								<table cellpadding="0" cellspacing="0" border="0" class="datatable-1 table table-bordered table-striped	 display" width="100%">		
									<thead>
										<tr>
											<th>SL</th>
											<th>Name</th>
											<th>Number</th>
											<th>category</th>
											<th>Condition</th>
											<th>seller Name</th>
											<th>Buy Date</th>
											<th>Sale Date</th>
											<th>Sale Price</th>
											<th>##</th>
										</tr>
									</thead>
									<tbody>
									<?php
										$i = 0;
										foreach($saleDataList as $saleData ){
											$i++;
									?>
										<tr class="odd gradeX">
											<td><?php echo $i;?></td>
											<td><b><?php echo $saleData->sim_name;?></b></td>
											<td><?php echo $saleData->sim_number;?></td>
											<td><?php echo $saleData->category;?></td>
											<td><?php echo $saleData->sim_condition;?></td>
											<td><?php echo $saleData->seller_name;?></td>
											<td><?php echo $saleData->buy_date;?></td>
											<td><?php echo $saleData->created_at;?></td>
											<td class="center"><?php echo $saleData->sale_price;?>|-</td>
											<td class="center" style="width:12%;">
												<span><a href="" class="btn btn-warning"  type="button" class="btn btn-info btn-lg" data-toggle="modal" data-target="#myModal<?php echo $saleData->sale_id; ?>">Edit 
													</a>
												</span>
											</td>
										</tr><!-- Modal -->
	<div class="modal fade" id="myModal<?php echo $saleData->sale_id; ?>" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
	  <div class="modal-dialog" role="document">
	    <div class="modal-content">
		<form action="<?php echo base_url('index.php/AppsFunctions/saleToUpdate/'); ?><?php echo $saleData->sale_id; ?>" method="post" class="form-horizontal">
 	      <div class="modal-header">
	        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
	        <h4 class="modal-title" id="myModalLabel"> <span style="color:teal;font-size:16px;"> Edit Now  Num:  <span style="color:orange;font-size:16px;"><?php echo $saleData->sim_number; ?></span> &nbsp;&nbsp;
	        </span>Seller: <span style="color:orange;font-size:16px;"><?php echo $saleData->seller_name;?></span>&nbsp;&nbsp;Price: <span style="color:orange;font-size:16px;"><?php echo $saleData->sale_price;?></span></h4>
	      </div>
	      <div class="modal-body">
	<!---form--->
	  <div class="control-group">
	  	<input type="hidden" name="sale_id" value="<?php echo $saleData->sale_id;?>">
	  	<input type="hidden" name="sim_name" value="<?php echo $saleData->sim_name;?>">
	  	<input type="hidden" name="sim_number" value="<?php echo $saleData->sim_number;?>">
	  	<input type="hidden" name="category" value="<?php echo $saleData->category;?>">
	  	<input type="hidden" name="sim_condition" value="<?php echo $saleData->sim_condition;?>" >
	  	<input type="hidden" name="buy_date" value="<?php echo $saleData->buy_date; ?>" >
	  	<input type="hidden" name="have_name" value="<?php echo $saleData->have_name; ?>" >
	  	<input type="hidden" name="buy_price" value="<?php echo $saleData->buy_price; ?>" >
	  	<input type="hidden" name="sim_id" value="<?php echo $saleData->sim_id; ?>" >

		<div class="control-group">
			<label class="control-label" for="sim_number">Seller Name</label>
			<div class="controls">
	   			 <input name="seller_name" type="text" class="form-control" id="quantity" style="width:97%;" value="<?php echo $saleData->seller_name;?>">
			</div>
		</div>

		<div class="control-group">
			<label class="control-label" for="sim_number">Sale Price</label>
			<div class="controls">
	    		<input name="sale_price" type="text" class="form-control" id="quantity" style="width:97%;" value="<?php echo $saleData->sale_price;?>" required="">
			</div>
		</div>

	  </div>
	<!---------->
	      <div class="modal-footer">
	        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
	        <button type="submit" class="btn btn-primary">Confirm</button>
	      </div>
	      </div>
	 	</form>     
	    </div>
	  </div>
	</div>
									<?php		
										}//end foreach..  
									?>
									</tbody>
						</table>
					</div>
				</div><!--/.module-->

<?php
	}
?>

				</div>

						
						
				</div><!--/.content-->
			</div><!--/.span9-->
		</div>
	</div><!--/.container-->
</div><!--/.wrapper-->

