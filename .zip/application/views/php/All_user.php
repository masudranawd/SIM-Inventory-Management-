<div class="span9">
	<div class="content">
									<!------>
									<?php echo $this->session->flashdata('msg'); ?>
									<!------>
		<div class="module">
			<div class="module-head">
				<h2> User List </h2>
			</div>
			
		<div class="module">
			<div class="module-body table">
				<table cellpadding="0" cellspacing="0" border="0" class="datatable-1 table table-bordered table-striped	 display" width="100%">
					<thead>
						<tr>
							<th style="width:10%;">Profile</th>
							<th >User Name</th>
							<th style="width:25%; ">Type</th>
							<th  style="width:12%;">Status</th>
							<th  style="width:30%;">Action</th>
						</tr>
					</thead>
					<?php
						foreach ($userDataList as $userData){
							if($userData->types != 'admin'){
					?>
					<tbody>
						<tr class="gradeX">
							<td style="text-align: center; ">
								<img src="<?php echo base_url(); ?>/images/user/<?php echo $userData->image;?>" style="height:30px;" alt="n/a" style="margin:0px; ">
							</td>
							<td <?php if($userData->status == 1){ echo 'style="background: lightgreen; "'; } ?> ><?php echo $userData->user_id; ?></td>
							<td>
								<?php
									if($userData->types == 'Owner'){
								?>
								<a href="#" class="btn btn-xs btn-default">Owner</a>
								<a href="<?php echo base_url('index.php/User/Type/m/'); ?><?php echo $userData->id; ?>" class="btn btn-xs btn-info">Manager</a>
								<a href="<?php echo base_url('index.php/User/Type/s/'); ?><?php echo $userData->id; ?>" class="btn btn-xs btn-info">Salesman</a>
								<?php 
									}elseif($userData->types == 'Manager'){
								?>
								<a href="<?php echo base_url('index.php/User/Type/o/'); ?><?php echo $userData->id; ?>" class="btn btn-xs btn-info">Owner</a>
								<a href="#" class="btn btn-xs btn-default">Manager</a>
								<a href="<?php echo base_url('index.php/User/Type/s/'); ?><?php echo $userData->id; ?>" class="btn btn-xs btn-info">Salesman</a>
								<?php 
									}elseif($userData->types == 'Salesman'){
								?>
								<a href="<?php echo base_url('index.php/User/Type/o/'); ?><?php echo $userData->id; ?>" class="btn btn-xs btn-info">Owner</a>
								<a href="<?php echo base_url('index.php/User/Type/m/'); ?><?php echo $userData->id; ?>" class="btn btn-xs btn-info">Manager</a>
								<a href="#" class="btn btn-xs btn-default">Salesman</a>
								<?php 
									}
								 ?>
							</td>
							<td class="center">
								<span>
							<?php 
								if($userData->permission==0){
							?>
								<a href="<?php echo base_url('index.php/User/UserpermissionActiveMethod/'); ?><?php echo $userData->id; ?>" class="btn btn-xs btn-primary">ON</a>
								<a class="btn btn-xs btn-default">OFF</a>
							<?php 
								}else{
							?>
								<a class="btn btn-xs btn-default">ON</a>
								<a href="<?php echo base_url('index.php/User/UserpermissionInActiveMethod/'); ?><?php echo $userData->id; ?>" class="btn btn-xs btn-primary">OFF</a>
							<?php 
								}
							?>													

								</span>
							</td>
							<td class="center">
								<span>
									<a class="btn btn-xs btn-info"  type="button" class="btn btn-primary btn-lg" href="<?php echo base_url('index.php/User/Profile/'); ?><?php echo $userData->id; ?>" >View</a>
										
									<a class="btn btn-xs btn-warning"  type="button" class="btn btn-primary btn-sm" data-toggle="modal" data-target="#myModal<?php echo $userData->id; ?>" >Change Password</a>									

									<?php 
										if($userData->image != null){
									?>
									<a href="<?php echo base_url('index.php/User/userRemoveByIdImg/');?><?php echo $userData->id; ?>/<?php echo $userData->image; ?>" class="btn btn-xs btn-danger">Remove</a>

									<?php 
										}else{
									?>

									<a href="<?php echo base_url('index.php/User/userRemoveById/');?><?php echo $userData->id; ?>" class="btn btn-xs btn-danger">Remove</a>
									<?php 
										}
									?>
								</span>
							</td>
						</tr>

<!-- Modal -->
<div class="modal fade" id="myModal<?php echo $userData->id; ?>" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
	<form action="<?php echo base_url('index.php/User/ChangePassword/'); ?>" method="post" class="form-horizontal">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
        <h3 class="modal-title" id="myModalLabel">Userdata Update # <?php echo $userData->user_id; ?></h3>
      </div>
      <div class="modal-body">
<!---form--->
  <div class="control-group">
  	<input type="hidden" name="id" value="<?php echo $userData->id; ?>" >
    <input name="password" type="password" class="form-control" id="user_id" style="width:97%;" value="<?php echo $userData->password; ?>" required="">
  </div>
<!---------->
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
        <button type="submit" class="btn btn-warning">Update Password !</button>
      </div>
 	</form>     
    </div>
  </div>
</div>

								<?php		
									}
									}//end foreach..  
								?>
							</tbody>
						</table>
					</div>
				</div><!--/.module-->

				</div>

						
						
				</div><!--/.content-->
			</div><!--/.span9-->
		</div>
	</div><!--/.container-->
</div><!--/.wrapper-->