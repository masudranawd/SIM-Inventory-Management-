				<div class="span9">
					<div class="content">

						<div class="module">
							<div class="module-head">
								<h3> Sim  List  </h3>
							</div>
						<div class="module">
							<div class="module-body table">
								<table cellpadding="0" cellspacing="0" border="0" class="datatable-1 table table-bordered table-striped	 display" width="100%">		
									<thead>
										<tr>
											<th>SL</th>
											<th>Name</th>
											<th>Number</th>
											<th>category</th>
											<th>Condition</th>
											<th>Buy Date</th>
											<th>Have Name</th>
											<th>Buy Price</th>
											<th>Action</th>
										</tr>
									</thead>
									<tbody>
									<?php
										$i = 0;
										foreach($allSimDataList as $simData ){
											$i++;
									?>
							<?php 
								if($simData->status==0){
							?>        
								<tr class="odd gradeX">
											<td><?php echo $i;?></td>
											<td><b><?php echo $simData->sim_name;?></b></td>
											<td><?php echo $simData->sim_number;?></td>
											<td><?php echo $simData->category;?></td>
											<td><?php echo $simData->sim_condition;?></td>
											<td><?php echo $simData->buy_date;?></td>
											<td><?php echo $simData->have_name;?></td>
											<td class="center"><?php echo $simData->buy_price;?>|-</td>
											<td class="center" style="width:12%;">
												<span><a href="<?php echo base_url('index.php/Apps/SimUpdate/');?><?php echo $simData->sim_id; ?>" class="btn btn-warning" class="btn btn-info btn-lg" >E</a>									
													<a href="<?php echo base_url('index.php/AppsFunctions/SimRemoveMethod/');?><?php echo $simData->sim_id;?>" class="btn btn-danger">D</a>
												</span>
											</td>
								</tr>

							<?php 
								}elseif($simData->status=='1'){
							?>
							<tr class="odd gradeX">
											<td><?php echo $i;?></td>
											<td><b><?php echo $simData->sim_name;?></b></td>
											<td><?php echo $simData->sim_number;?></td>
											<td><?php echo $simData->category;?></td>
											<td><?php echo $simData->sim_condition;?></td>
											<td><?php echo $simData->buy_date;?></td>
											<td><?php echo $simData->have_name;?></td>
											<td class="center"><?php echo $simData->buy_price;?>|-</td>
											<td class="center" style="width:12%;">
												<span style="color:green;font-weight: bold;">paid</span>
											</td>
										</tr>
							<?php }
							?>
										
									<?php		
										}//end foreach..  
									?>
									</tbody>
						</table>
					</div>
				</div><!--/.module-->

				</div>

						
						
				</div><!--/.content-->
			</div><!--/.span9-->
		</div>
	</div><!--/.container-->
</div><!--/.wrapper-->

