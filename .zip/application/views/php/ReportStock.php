﻿				<div class="span9">
					<div class="content">

						<div class="module">
							<div class="module-head">
								<h3> REPORTS :) Stock  </h3>
							</div>
							
							<div class="" style="margin: 30px 0px; ">
								<form class="form-inline clearfix" action="<?php echo base_url('index.php/Apps/ReportStock/'); ?>" method="post">
								  <div class="form-group" style="float:left;margin-left: 10px;">
								    <label for="exampleInputName2">From : </label>
								    <input type="date" name="fromdate" class="form-control" id="exampleInputName2">
								  </div>
								  <div class="form-group" style="float:left;margin-left: 10px;">
								    <label for="exampleInputEmail2">To : </label>
								    <input type="date" name="todate" class="form-control" id="exampleInputEmail2">
								  </div>

								  <div class="form-group" style="float:left;margin-left: 10px;">
								    <button name="searchbykey" class="btn btn-primary">Search</button>
								  </div>
								</form>		
							</div>

						<div class="module">
							<div class="module-body table">

<?php 
	if($ReportDataList){
?>
								<table cellpadding="0" cellspacing="0" border="0" class="table table-bordered table-striped	 display" style="width:98%; margin:0px auto; ">
									<thead>
										<tr>
											<th colspan="4">
												<h3 style="padding-bottom: 0px; margin-bottom: 0px; ">STOCK REPORT</h3>
											</th>
										</tr>
										<tr>
											<th>SL</th>
											<th>Product Name</th>
											<th>Date</th>
											<th>Quantity</th>
										</tr>
									</thead>
									<tbody>
										<?php
											$i=0;
											$total = 0; 
											foreach($ReportDataList as $salereportData){
												$i++;  
												$total = $total+$salereportData->stock_amount; 
										?>
										
										<tr class="odd gradeX">
											<td><?php echo $i; ?></td>
											<td>
												<?php 
													$pid = $salereportData->product_id;
													$table = 'tb_product';  
													$data = array('match_col'=>'product_id', 'match_by'=>$pid); 
													$product = $this->Apps_model->Get_data_by_id_model($table,$data); 
													
													if(isset($product->product_name)){ echo $product->product_name; }else{ echo 'Empty !'; }
												?>												
											</td>
											<td><?php  echo $salereportData->created_at;  ?></td>
											<td><?php echo $salereportData->stock_amount; ?></td>
										</tr>

										<?php		
											}//end of foreach
										?>
										<tr class="odd gradeX">
											<th colspan="3" style="text-align: right;">TOTAL</th>
											<th><?php echo $total; ?></th>
										</tr>
									</tbody>
								</table>	
								<br/>
								<center>
									<form target="_blank" method="post" action="<?php echo base_url('index.php/Apps/ReportStockPrint/'); ?>">
										<input type="hidden" name="fromdate" value="<?php echo $fromdate; ?>">
										<input type="hidden" name="todate" value="<?php echo $todate; ?>">
										<button class="btn btn-sm btn-primary" type="submit">PRINT</button>
									</form>		
								</center>															
<?php 
	}else{
?>
<div class="alert alert-warning">NO SEARCH KEWWORD !</div>
<?php 
	}
?>
						
							</div>
						</div><!--/.module-->



				</div>

						
						
				</div><!--/.content-->
			</div><!--/.span9-->
		</div>
	</div><!--/.container-->
</div><!--/.wrapper-->

