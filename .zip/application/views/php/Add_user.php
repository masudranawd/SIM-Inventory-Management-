                    <!--/.span3-->
				<div class="span9">
					<div class="content">
									<!------>
									<?php echo $this->session->flashdata('msg'); ?>
									<!------>

						<div class="module">
							<div class="module-head">
								<h3> User Add </h3>
							</div>
							<div class="module-body">

								<?php echo form_open_multipart('User/AddNewUser/'); ?>

									<div class="form-horizontal row-fluid">
										<div class="control-group">
											<label class="control-label" for="firsname">Login ID</label>
											<div class="controls">
												<input name="user_id" type="text" id="user_id" placeholder="Enter Login ID !" class="span8" required="">
											</div>
										</div>
										<div class="control-group">
											<label class="control-label" for="password">Password</label>
											<div class="controls">
												<input name="password" type="password" id="password" placeholder="Enter password !" class="span8" required="">
											</div> 
										</div>
										<div class="control-group">
											<label class="control-label" for="phone">Types</label>
											<div class="controls">
												<select class="span8" name="types">
													<option >Select types</option>
													<option value="Owner">Owner</option>
													<option value="Manager">Manager</option>
													<option value="Salesman">Salesman</option>
												</select>
											</div>
										</div>										

										<div class="control-group">
											<div class="controls">
												<button type="submit" class="btn btn-primary">Add User</button>	
											</div>
										</div>
									</div>
									</form>

							</div>
						</div>

						
						
					</div><!--/.content-->
				</div><!--/.span9-->
			</div>
		</div><!--/.container-->
	</div><!--/.wrapper-->
