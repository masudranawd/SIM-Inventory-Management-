       
        <div class="footer" style="text-align: center;height: 0.1px;">
            <div class="container">
                <b class="copyright">Developed By - <a href="http://dwinsteam.com/">DwinsTeam</a> | Powered By - <a href="http://aims365.com/index.php/Home/"> Aims365.</a>
            </div>
        </div>
        <script src="<?php echo base_url(); ?>scripts/jquery-1.9.1.min.js" type="text/javascript"></script>
        <script src="<?php echo base_url(); ?>scripts/jquery-ui-1.10.1.custom.min.js" type="text/javascript"></script>
        <script src="<?php echo base_url(); ?>bootstrap/js/bootstrap.min.js" type="text/javascript"></script>
        <script src="<?php echo base_url(); ?>scripts/flot/jquery.flot.js" type="text/javascript"></script>
        <script src="<?php echo base_url(); ?>scripts/flot/jquery.flot.resize.js" type="text/javascript"></script>
        <script src="<?php echo base_url(); ?>scripts/datatables/jquery.dataTables.js" type="text/javascript"></script>
        <script src="<?php echo base_url(); ?>scripts/common.js" type="text/javascript"></script>
      <script>
		$(document).ready(function() {
			$('.datatable-1').dataTable();
			$('.dataTables_paginate').addClass("btn-group datatable-pagination");
			$('.dataTables_paginate > a').wrapInner('<span />');
			$('.dataTables_paginate > a:first-child').append('<i class="icon-chevron-left shaded"></i>');
			$('.dataTables_paginate > a:last-child').append('<i class="icon-chevron-right shaded"></i>');
		} );
	</script>
    </body>
