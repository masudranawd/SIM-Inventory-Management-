﻿				<div class="span9">
					<div class="content">

						<div class="module">
							<div class="module-head">
								<h2> Airtel Stock List  </h2>
							</div>
																		
<?php 
	if($pData->types == 'Owner' or $pData->types == 'admin'){
?>

						<div class="module">
							<div class="module-body table">
								<table cellpadding="0" cellspacing="0" border="0" class="datatable-1 table table-bordered table-striped	 display" width="100%">		
									<thead>
										<tr>
											<th>SL</th>
											<th>Name</th>
											<th>Number</th>
											<th>category</th>
											<th>Condition</th>
											<th>Buy Date</th>
											<th>Have Name</th>
											<th>Buy Price</th>
											<th>Action</th>
										</tr>
									</thead>
									<tbody>
									<?php
										$i = 0;
										$total =0;
										foreach($simDataList as $simData ){
											
										if($simData->sim_name=='airtel'){
											$total = $total+$simData->buy_price;$i++;
									?>

										<tr class="odd gradeX">
											<td><?php echo $i;?></td>
											<td><b><?php echo $simData->sim_name;?></b></td>
											<td><?php echo $simData->sim_number;?></td>
											<td><?php echo $simData->category;?></td>
											<td><?php echo $simData->sim_condition;?></td>
											<td><?php echo $simData->buy_date;?></td>    
											<td><?php echo $simData->have_name;?></td>
											<td class="center"><?php echo $simData->buy_price;?>|-</td>
											<td class="center" style="width:12%;">
												<span><a href="<?php echo base_url('index.php/Apps/SimUpdate/');?><?php echo $simData->sim_id;?>" class="btn btn-warning" class="btn btn-info btn-lg" >E</a>								
													<a href="<?php echo base_url('index.php/AppsFunctions/SimRemoveMethod/');?><?php echo $simData->sim_id;?>" class="btn btn-danger">D</a>
												</span>
											</td>
										</tr>
									<?php		
											}
										}//end foreach..  
									?>
									</tbody>
						</table>
						<div style="text-align: center;font-weight: bold;font-size: 21px;color:#000;">Total:
					<?php echo sprintf('%0.2f',$total); ?></div>
								<br/>							
								<center>
									<form target="_blank" method="post" action="<?php echo base_url('index.php/Apps/ReportStockPrintAritel/'); ?>">
										<button class="btn btn-sm btn-primary" name="bykey"   type="submit" target="_blank">PRINT</button>
									</form>		
								</center>	
					</div>
				</div><!--/.module-->
<?php
}elseif($pData->types == 'Salesman' or $pData->types == 'Manager'){
?>

						<div class="module">
							<div class="module-body table">
								<table cellpadding="0" cellspacing="0" border="0" class="datatable-1 table table-bordered table-striped	 display" width="100%">		
									<thead>
										<tr>
											<th>SL</th>
											<th>Name</th>
											<th>Number</th>
											<th>category</th>
											<th>Condition</th>
											<th>Buy Date</th>
											<th>Have Name</th>
											<th>Action</th>
										</tr>
									</thead>
									<tbody>
									<?php
										$i = 0;
										$total =0;
										foreach($simDataList as $simData ){
											
										if($simData->sim_name=='airtel'){
											$total = $total+$simData->buy_price;
											$i++;
									?>

										<tr class="odd gradeX">
											<td><?php echo $i;?></td>
											<td><b><?php echo $simData->sim_name;?></b></td>
											<td><?php echo $simData->sim_number;?></td>
											<td><?php echo $simData->category;?></td>
											<td><?php echo $simData->sim_condition;?></td>
											<td><?php echo $simData->buy_date;?></td>    
											<td><?php echo $simData->have_name;?></td>
											<td class="center" style="width:12%;">
												<span><a href="<?php echo base_url('index.php/Apps/SimUpdate/');?><?php echo $simData->sim_id; ?>" class="btn btn-warning" class="btn btn-info btn-lg" >E</a>					
												</span>
											</td>
										</tr>
									<?php		
											}
										}//end foreach..  
									?>
									</tbody>
						</table>
						<div style="text-align: center;font-weight: bold;font-size: 21px;color:#000;"></div>
					</div>
				</div><!--/.module-->
<?php
	}
?>
				</div>

						
						
				</div><!--/.content-->
			</div><!--/.span9-->
		</div>
	</div><!--/.container-->
</div><!--/.wrapper-->

