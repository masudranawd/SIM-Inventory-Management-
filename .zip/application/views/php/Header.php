<!DOCTYPE html>
<html lang="en">
<head>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title><?php echo $optionsData->company_title; ?></title>
        <link type="text/css" href="<?php echo base_url(); ?>bootstrap/css/bootstrap.min.css" rel="stylesheet">
        <link type="text/css" href="<?php echo base_url(); ?>bootstrap/css/bootstrap-responsive.min.css" rel="stylesheet">
        <link type="text/css" href="<?php echo base_url(); ?>css/theme.css" rel="stylesheet">
        <link type="text/css" href="<?php echo base_url(); ?>images/icons/css/font-awesome.css" rel="stylesheet">
        <link type="text/css" href='<?php echo base_url(); ?>/scripts/myjs.js' rel='stylesheet'>

    </head>
    <body>
        <div class="navbar navbar-fixed-top">
            <div class="navbar-inner">
                <div class="container">
                    <a class="btn btn-navbar" data-toggle="collapse" data-target=".navbar-inverse-collapse">
                        <i class="icon-reorder shaded"></i>
                    </a>
<?php 
    if(empty($optionsData->company_logo)){
?>
                    <a class="brand" href="<?php echo base_url('index.php/Apps/Home/'); ?>" style="color:black;"><?php echo $optionsData->company_title; ?> </a>
<?php 
    }else{
?>
                    <a href="<?php echo base_url('index.php/Apps/Home/'); ?>"><img src="<?php echo base_url(); ?>/images/<?php echo $optionsData->company_logo; ?>" class="brand" alt="" style="width:150px;height: 45px;"></a>
<?php 
    }
?>
                    <div class="nav-collapse collapse navbar-inverse-collapse" style="margin-top:10px;">
                        <ul class="nav nav-icons">
                            <h2 style="margin-top: 10px;">
                                <b style="color:black;"><?php echo $pData->firstname.' '.$pData->lastname; ?></b>
                                <small style=" ">
                                    ( Type &mdash; <?php echo $pData->types;?> ) 
                                </small>
                            </h2>
                        </ul>
                        <ul class="nav pull-right">
<?php 
    if($pData->types == 'Owner' or $pData->types == 'admin'){
?>
                            <li>
                                <a href="<?php echo base_url('index.php/Apps/ActivityLog/'); ?>">Activity Log &nbsp;</a>
                            </li>
<?php }?>
                            <li class="nav-user dropdown"><a href="#" class="dropdown-toggle" data-toggle="dropdown">
                                <img src="<?php echo base_url(); ?>images/user/<?php echo $pData->image; ?>" class="nav-avatar" />
                                <b class="caret"></b></a>
                                <ul class="dropdown-menu">
                                    <li><a href="<?php echo base_url('index.php/User/Profile/'); ?><?php echo $this->session->id; ?>">Your Profile</a></li>
                                    <?php 
                                        if($this->session->types == 'admin' OR $this->session->types == 'Owner'){
                                    ?>
                                    <li><a href="<?php echo base_url('index.php/User/Adduser/'); ?>">Add User</a></li>
                                    <li><a href="<?php echo base_url('index.php/User/Alluser/'); ?>">All User</a></li>
                                    <?php 
                                        }
                                    ?>

                                    <li class="divider"></li>
                                    <li><a href="<?php echo base_url('index.php/User/Logout/'); ?>">Logout</a></li>
                                </ul>
                            </li>
                        </ul>
                    </div>
                    <!-- /.nav-collapse -->
                </div>
            </div>
            <!-- /navbar-inner -->
        </div>
        <!-- /navbar -->
<?php  
    if($pData->firstname == NULL OR $pData->lastname == NULL OR $pData->email == NULL OR $pData->phone == NULL OR $pData->address == NULL OR $pData->image == NULL){
?>
        <div style=" margin:0px auto; text-align: center; background: #F1F1F1; padding:30px 0px 0px 0px; color:red; font-weight: bold; ">
         <span>
             Your Profile is not full complete. To Complete Profile <a href="<?php echo base_url('index.php/User/Profile/'); ?><?php echo $this->session->id; ?>"class="btn btn-info">Update Profile !</a>

         </span>
        </div>
<?php 
    }
?>
