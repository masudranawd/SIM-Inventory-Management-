<?php 
//include tcpdf/library 
//include 'tcpdf/tcpdf.php'; 

//make TCPDF Object
$pdf = new TCPDF('p','mm','A4'); 
$pdf->SetFont('times', '', 12);

//remove default header & footer. 
$pdf->setPrintHeader(false); 
$pdf->setPrintFooter(false); 

//add page
$pdf->AddPage(); 


//add content
//USING CELL
//1# $pdf->Cell(190,10,'This is A cell',1,1,'C');

//using html cell || writeHTMLCell($w, $h, $x, $y, $html='', $border=0, $ln=0, $fill=0, $reseth=true, $align='', $autopadding=true)

$var = '<table border="1" style="text-align:center; font-size:10px; ">';
$var .= '<tr style="">
			<th style=" width:15mm;"><b>SL</b></th>
			<th style=" width:30mm;"><b>SIM Name</b></th>
			<th style=" width:40mm;"><b>SIM number</b></th>
			<th style=" width:40mm;"><b>Date</b></th>
			<th style=" width:30mm;text-align:right;"><b>buy price</b></th>
			<th style=" width:30mm;text-align:right;"><b>sale price</b></th>
		</tr>'; //TABLE HEAD


$i=0;$totalb = 0; 	$totals =0;
	foreach($saleDataList as $saleData){
		$i++; 
		$totalb = $totalb+$saleData->buy_price; 
		$totals = $totals+$saleData->sale_price;

		$var .= '<tr>
			<td style="">'.$i.'</td>
			<td style="">'.$saleData->sim_name.'</td>
			<td style="">'.$saleData->sim_number.'</td>
			<td style="">'.$saleData->created_at.'</td>
			<td style="text-align:right;">'.sprintf('%0.2f',$saleData->buy_price).'</td>
			<td style="text-align:right;">'.sprintf('%0.2f',$saleData->sale_price).'</td>
		</tr>';

}

$var .= '<tr>
<td colspan="4" style="text-align:right;"><b>Total =</b></td><td style="text-align:right;"> <b>'.sprintf('%0.2f',$totalb).'</b></td><td style="text-align:right;"> <b>'.sprintf('%0.2f',$totals).'</b></td>
</tr>'; 
$var .= '</table>';



//$pdf->Image('1', 100, 100, 10 , 0, 'png', '', '', false, 300, '', false, false, 0, 'LB', false, false);
$pdf->Image(base_url('images/').$optionsData->invoice_header,10,10,190,25);

//$pdf->writeHTMLCell(74,0,10,100,'<P>Header OF VOUCHAR<P>',1,1); //HEADER..

$pdf->writeHTMLCell(190,0,12,40,'<b>From : '.$fromdate.'</b>',0,0); 
$pdf->writeHTMLCell(190,0,12,45,'<b>To &nbsp; &nbsp; : '.$todate.'</b>',0,0); 
$pdf->writeHTMLCell(190,0,12,50,'<b>Type : BL Sim</b>',0,0); 


$pdf->writeHTMLCell(190,0,12,60,$var,0,0); 
//$pdf->writeHTMLCell(190,0,10,225,'<P>FOOTER OF VOUCHAR<P>',1,1); //FOOTER..

//$pdf->Image('1.png',10,261,74,15);

//output / result..
$pdf->Output(); 