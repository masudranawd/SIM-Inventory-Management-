<?php 
//include tcpdf/library 
//include 'tcpdf/tcpdf.php'; 

//make TCPDF Object
$pdf = new TCPDF('p','mm','A4'); 
$pdf->SetFont('times', '', 12);

//remove default header & footer. 
$pdf->setPrintHeader(false); 
$pdf->setPrintFooter(false); 

//add page
$pdf->AddPage(); 


//add content
//USING CELL
//1# $pdf->Cell(190,10,'This is A cell',1,1,'C');

//using html cell || writeHTMLCell($w, $h, $x, $y, $html='', $border=0, $ln=0, $fill=0, $reseth=true, $align='', $autopadding=true)

$var = '<table border="1" style="text-align:center; font-size:10px; ">';
$var .= '<tr style="">
			<th style=" width:20mm;"><b>SL</b></th>
			<th style=" width:80mm;"><b>Product Name</b></th>
			<th style=" width:50mm;"><b>Date</b></th>
			<th style="text-align:center; width:34mm;"><b>Quantity</b></th>
		</tr>'; //TABLE HEAD







$i = 0; $total = 0; 
foreach ($ReportDataList as $ReportData) {

$pid = $ReportData->product_id;
$table = 'tb_product';  
$data = array('match_col'=>'product_id', 'match_by'=>$pid); 
$product = $this->Apps_model->Get_data_by_id_model($table,$data); 												 
if(isset($product->product_name)){
	$productName = $product->product_name;  
}else{
	$productName = "Empty !"; 
}

	$i++; 
	$total = $total + $ReportData->stock_amount; 

		$var .= '<tr>
			<td style="">'.$i.'</td>
			<td style="">'.$productName.'</td>
			<td style="">'.$ReportData->created_at.'</td>
			<td style="text-align:right;">'.$ReportData->stock_amount.'</td>
		</tr>';

}

$var .= '<tr><td colspan="3" style="text-align:right;"><b>Total =</b></td><td style="text-align:right;"> <b>'.$total.'</b></td></tr>'; 
$var .= '</table>';



//$pdf->Image('1', 100, 100, 10 , 0, 'png', '', '', false, 300, '', false, false, 0, 'LB', false, false);
$pdf->Image(base_url('images/').$optionsData->invoice_header,10,10,190,25);

//$pdf->writeHTMLCell(74,0,10,100,'<P>Header OF VOUCHAR<P>',1,1); //HEADER..

$pdf->writeHTMLCell(190,0,12,40,'<b>From : '.$fromdate.'</b>',0,0); 
$pdf->writeHTMLCell(190,0,12,45,'<b>To &nbsp; &nbsp; : '.$todate.'</b>',0,0); 

$pdf->writeHTMLCell(190,0,12,60,$var,0,0); 
//$pdf->writeHTMLCell(190,0,10,225,'<P>FOOTER OF VOUCHAR<P>',1,1); //FOOTER..

//$pdf->Image('1.png',10,261,74,15);

//output / result..
$pdf->Output(); 