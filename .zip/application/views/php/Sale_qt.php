

					<div class="span9">
						<div class="content">

	<?php  
		if(empty($invoiceData->id)){
			$invoice_id = 'Qt-000001';
		}else{
			$invoice_id = 'Qt-'.sprintf("%06d",$invoiceData->id+1);
		}
	?>


	<?php 
		if($orderDataList){
	?>
								<div class="btn-box-row row-fluid" style="padding:5px 0px; background: white;  margin-bottom:20px; ">


									<div class="btn-box big span8">
	<!-------->									
										<h3 class="module-head" style="text-align: left; margin-top:-25px; ">ORDER LIST</h3>

										<table class="table row-fluid">
										  <thead>
											<tr>
											  <th style="width:">SL</th>
											  <th style="width:">Product</th>
											  <th style="width:20%; text-align: right;">Price x Qty</th>
											  <th style="width:20%; text-align: right;">Total</th>
											  <th style="width:20%; text-align: right;">Action</th>
											</tr>
										  </thead>
										  <tbody>

											<?php 
												$i = 0; 
												$total = ''; 
												$order_details = '';
												$payment = '';
												$customer_payment = ''; 
												foreach ($orderDataList as $orderData) {
													$i++; 
													
													$order_details .= 'row'.'col'.$orderData->product_name.'ecol'.'col'.sprintf("%0.2f",$orderData->price).' X '.$orderData->quantity.$orderData->unit.'ecol'.'col'.sprintf("%0.2f",$orderData->product_total).'ecol'.'erow'.'<br/>'; 

													$total = (float)$total+ (float)$orderData->product_total; 

											?>

											<tr>
											  <td><?php echo $i;//$orderData->order_id; ?></td>
											  <td style="width:35%;"><?php echo $orderData->product_name; ?></td>
											  <td style="width:20%; text-align: right;"><?php echo $orderData->price; ?> X <?php echo $orderData->quantity; ?> .Ps</td>
											  <td style="width:20%; text-align: right;"><?php echo  sprintf("%0.2f",$orderData->product_total); ?> |-</td>
											  <td style="text-align: right;">
												<span>
													<a class="btn btn-mini btn-warning"  type="button" class="btn btn-primary btn-lg" data-toggle="modal" data-target="#myModal<?php echo $orderData->order_id;?>">E</a>	
													<a href="<?php echo base_url('index.php/AppsFunctions/QtRemoveMethod/');?><?php echo $orderData->order_id;?>/<?php echo $orderData->product_id; ?>/<?php echo $orderData->quantity; ?>" class="btn btn-danger">D</a>
												</span>
											  </td>
											</tr>

	<!-- Modal -->
	<div class="modal fade" id="myModal<?php echo $orderData->order_id; ?>" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
	  <div class="modal-dialog" role="document">
	    <div class="modal-content">
		<form action="<?php echo base_url('index.php/AppsFunctions/QtUpdateMethod/'); ?>" method="post" class="form-horizontal">
	      <div class="modal-header">
	        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
	        <h3 class="modal-title" id="myModalLabel" style="text-align: left; ">Update # <span style="color:DodgerBlue;"><?php echo $orderData->product_name; ?></span></h3>
	      </div>
	      <div class="modal-body">
	<!---form--->
	  <div class="control-group" style="text-align: left; ">
	  	<input type="hidden" name="order_id" value="<?php echo $orderData->order_id; ?>" >
	    
	    <input type="hidden" name="product_id" value="<?php echo $orderData->product_id; ?>">
	    <input name="prev_quantity" type="hidden" value="<?php echo $orderData->quantity; ?>">
	    Quantity: 
	    <input name="pres_quantity" type="text" class="form-control" id="quantity" style="width:97%;" value="<?php echo $orderData->quantity; ?>">
	    Price: 
	    <input name="price" type="text" value="<?php echo $orderData->price; ?>" style="width:97%;">
	  </div>
	<!---------->
	      </div>
	      <div class="modal-footer">
	        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
	        <button type="submit" class="btn btn-primary">Update Order !</button>
	      </div>
	 	</form>     
	    </div>
	  </div>
	</div>

	<?php 
		}//END OF FOREACH..
	?>


											<tr>
											  <th colspan="3">
											  	<?php echo $i; ?> Items in order list :)
											  </th>
											  <th colspan="" style="text-align: right;">Total = </th>
											  <th style="">
											  	<input type="text" name="" class="span12" value="<?php echo sprintf("%0.2f",$total); ?>" style="text-align:right; " readonly>
											  </th>
											</tr>			

										  </tbody>
										</table>
	<!-------->
									</div>
									<div class="btn-box big span4">
	<!------->	
										<h3 class="module-head" style="text-align: left; margin-top:-25px; ">Quotation: </h3>
										<form action="<?php echo base_url('index.php/Apps/PdfQuotation/'); ?>" method="post" class="form-horizontal" target="_blank">
										

											<div class="control-group">
												<input name="qt_date" type="date" id="customer_name" class="span7" style="width:97%;">
											</div>

											<div class="control-group">
												<input name="customer_name" type="text" id="customer_name" class="span7" style="width:97%;" placeholder="Customer / Company Name !">
											</div>
											<div class="control-group">
												<textarea name="company_address" class="span7" style="width:97%;" placeholder="Company Address !"></textarea>
											</div>
											<div class="control-group">
												<textarea name="qt_body" class="span7" style="width:97%;" placeholder="Quotation Body !" rows="5"></textarea>
											</div>

	

											<div class="control-group" style="text-align: left;">
												<button type="submit" class="btn btn-primary" style="">Confirm Quotation </button>
											</div>	

										</form>
										<!------->
									</div>									
								</div>
	<?php 
		}else{
			echo '<div class="alert alert-warning" >No Order In Queue </div>'; 
		}
	?>	
	
							<div class="module">
								<div class="module-head">
									<h3>Product Table</h3>
								</div>
								<div class="module-body table">

									<table cellpadding="0" cellspacing="0" border="0" class="table table-bordered datatable-1 table table-bordered table-striped display" width="98%">
										<thead>
											<tr>
												<th>SL</th>
												<th>Product</th>
												<th>Company</th>
												<th>Sell Price</th>
												<th>Stock</th>
												<th>Action</th>
											</tr>
										</thead>

										<tbody>
										<?php
											$i = 0;
											foreach($productDataList as $productData){
												$i++;
										?>
											<tr class="">
												<td><?php echo sprintf('%04u', $i); ?></td>
												<td><b><?php echo $productData->product_name; ?></b></td>
												<td><?php echo $productData->company; ?></td>
												<td><?php echo sprintf('%0.2f',$productData->sell_price); ?></td>
												<td class="center"><?php echo $productData->quantity; ?> (<?php echo $productData->unit; ?>)</td>
												<td class="center" style="width:12%;">
													<span>
														<a class="btn btn-mini btn-primary"  type="button" class="btn btn-info btn-lg" data-toggle="modal" data-target="#myModal<?php echo $productData->product_id; ?>" >+ ORDER NOW</a>						
													</span>
												</td>
											</tr>


	<!-- Modal -->
	<div class="modal fade" id="myModal<?php echo $productData->product_id; ?>" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
	  <div class="modal-dialog" role="document">
	    <div class="modal-content">
		<form action="<?php echo base_url('index.php/AppsFunctions/AddToQt/'); ?>" method="post" class="form-horizontal">
	      <div class="modal-header">
	        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
	        <h3 class="modal-title" id="myModalLabel"><?php echo $productData->product_name; ?> <small><?php echo sprintf("%0.2f",$productData->buy_price); ?>/<?php echo $productData->unit; ?></small></h3>
	      </div>
	      <div class="modal-body">
	<!---form--->
	  <div class="control-group">
	  	<input type="hidden" name="invoice_id" value="<?php echo $invoice_id;  ?>" >
	  	<input type="hidden" name="created_by_id" value="<?php echo $this->session->id;  ?>" >

	  	<input type="hidden" name="product_name" value="<?php echo $productData->product_name; ?>" >

	  	<input type="hidden" name="unit" value="<?php echo $productData->unit; ?>" >
	  	<input type="hidden" name="product_id" value="<?php echo $productData->product_id; ?>" >

	    Quantity <input name="quantity" type="text" class="form-control" id="quantity" style="width:97%;" placeholder="Enter Quantity !" required="">

	    Sale Price: <input name="price" type="text" class="form-control" id="price" style="width:97%;" required="" value="<?php echo sprintf('%0.2f',$productData->sell_price); ?>">

	  </div>
	<!---------->
	      </div>
	      <div class="modal-footer">
	        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
	        <button type="submit" class="btn btn-primary">Add To Quotation !</button>
	      </div>
	 	</form>     
	    </div>
	  </div>
	</div>

								<?php	
									}//end foreach..  
								?>
								</tbody>									
									</table>
								</div>
							</div><!--/.module-->

						<br />
							
						</div><!--/.content-->
					</div><!--/.span9-->
				</div>
			</div><!--/.container-->
		</div><!--/.wrapper-->