
        
        <div class="wrapper">
            <div class="container">
                <div class="row">
                    <div class="span3">
                        <div class="sidebar">

<?php 
	if($pData->types == 'Owner' or $pData->types == 'admin'){
?>
                            <ul class="widget widget-menu unstyled">
                                <li class="active">
									<a href="<?php echo base_url(); ?>">
									   <i class="menu-icon icon-dashboard"></i>Dashboard
									</a>
								</li>
                            </ul>
                            <ul class="widget widget-menu unstyled">
                                <li class="">
									<a href="<?php echo base_url('index.php/Apps/Options/'); ?>">
									   <i class="menu-icon icon-cog"></i>Company Options 
									</a>
								</li>
                            </ul>
                            <ul class="widget widget-menu unstyled">
                                <li class="active text-center">
									<a  style ="color:#fff;font-weight:bold;font-size:14px;">
									   	SIM Option 
									</a>
								</li>
                                <li> 
									<a href="<?php echo base_url('index.php/Apps/SimAdd/'); ?>">
										<i class="menu-icon icon-inbox"></i> Add SIM 
									</a> 
								</li>
                                <li>
									<a href="<?php echo base_url('index.php/Apps/AllSimList/'); ?>">
										<i class="menu-icon icon-tasks"></i> All SIM List  <b class="label green pull-right"><?php if(isset($Totalsim)){ echo $Totalsim; }else{ echo '0'; } ?></b>
									</a>
								</li>
                            </ul>
                            <!--/.widget-nav-->
                            <ul class="widget widget-menu unstyled">
                                <li class="active text-center">
									<a  style ="color:#fff;font-weight:bold;font-size:14px;">
									   	Stock Option 
									</a>
								</li>
                                <li> 
									<a href="<?php echo base_url('index.php/Apps/GpStock/'); ?>">
										<i class="menu-icon icon-inbox"></i>Grameenphone <b class="label green pull-right"><?php if(isset($TotalGp)){ echo $TotalGp; }else{ echo '0'; } ?></b>
									</a> 
								</li>
                                <li> 
									<a href="<?php echo base_url('index.php/Apps/BlStock/'); ?>">
										<i class="menu-icon icon-inbox"></i>Banglalink <b class="label green pull-right"><?php if(isset($TotalBl)){ echo $TotalBl; }else{ echo '0'; } ?></b>
									</a> 
								</li>
                                <li> 
									<a href="<?php echo base_url('index.php/Apps/RobiStock/'); ?>">
										<i class="menu-icon icon-inbox"></i>Robi<b class="label green pull-right"><?php if(isset($TotalRobi)){ echo $TotalRobi; }else{ echo '0'; } ?></b>
									</a> 
								</li>
                                <li> 
									<a href="<?php echo base_url('index.php/Apps/AirtelStock/'); ?>">
										<i class="menu-icon icon-inbox"></i>Airtel<b class="label green pull-right"><?php if(isset($TotalAirtel)){ echo $TotalAirtel; }else{ echo '0'; } ?></b>
									</a> 
								</li>
                                <li> 
									<a href="<?php echo base_url('index.php/Apps/TeletalkStock/'); ?>">
										<i class="menu-icon icon-inbox"></i>Teletalk<b class="label green pull-right"><?php if(isset($TotalTeletalk)){ echo $TotalTeletalk; }else{ echo '0'; } ?></b>
									</a> 
								</li>
                            </ul>
                            <!--/.widget-nav-->
                            <ul class="widget widget-menu unstyled">
                                <li class="active text-center">
									<a  style ="color:#fff;font-weight:bold;font-size:14px;">
									   	Sale Option 
									</a>
								</li>
                                <li> 
									<a href="<?php echo base_url('index.php/Apps/SaleAdd/'); ?>">
										<i class="menu-icon icon-inbox"></i> Add Sale 
									</a> 
									</li>
                                <li>
									<a href="<?php echo base_url('index.php/Apps/SaleList/'); ?>">
										<i class="menu-icon icon-tasks"></i> Sale List <b class="label green pull-right"><?php if(isset($Totalsale)){ echo $Totalsale; }else{ echo '0'; } ?></b>
									</a>
								</li>
                            </ul>  
                            <ul class="widget widget-menu unstyled">
                                <li class="active text-center">
									<a  style ="color:#fff;font-weight:bold;font-size:14px;">
									   	Report Options  
									</a>
								</li>
                                <li> 
									<a href="<?php echo base_url('index.php/Apps/ReportSales/'); ?>">
										<i class="menu-icon icon-inbox"></i> Sale Report
									</a> 
									</li>
                            </ul>                                                                              
<?php 
	}elseif($pData->types == 'Manager'){
?>
                            <ul class="widget widget-menu unstyled">
                                <li class="active text-center">
									<a  style ="color:#fff;font-weight:bold;font-size:14px;">
									   	SIM Option 
									</a>
								</li>
                                <li> 
									<a href="<?php echo base_url('index.php/Apps/SimAdd/'); ?>">
										<i class="menu-icon icon-inbox"></i> Add SIM 
									</a> 
								</li>
                                <li>
									<a href="<?php echo base_url('index.php/Apps/AllSimList/'); ?>">
										<i class="menu-icon icon-tasks"></i> All SIM List  <b class="label green pull-right"><?php if(isset($Totalsim)){ echo $Totalsim; }else{ echo '0'; } ?></b>
									</a>
								</li>
                            </ul>
                            <!--/.widget-nav-->
                            <ul class="widget widget-menu unstyled">
                                <li class="active text-center">
									<a  style ="color:#fff;font-weight:bold;font-size:14px;">
									   	Stock Option 
									</a>
								</li>
                                <li> 
									<a href="<?php echo base_url('index.php/Apps/GpStock/'); ?>">
										<i class="menu-icon icon-inbox"></i>Grameenphone <b class="label green pull-right"><?php if(isset($TotalGp)){ echo $TotalGp; }else{ echo '0'; } ?></b>
									</a> 
								</li>
                                <li> 
									<a href="<?php echo base_url('index.php/Apps/BlStock/'); ?>">
										<i class="menu-icon icon-inbox"></i>Banglalink <b class="label green pull-right"><?php if(isset($TotalBl)){ echo $TotalBl; }else{ echo '0'; } ?></b>
									</a> 
								</li>
                                <li> 
									<a href="<?php echo base_url('index.php/Apps/RobiStock/'); ?>">
										<i class="menu-icon icon-inbox"></i>Robi<b class="label green pull-right"><?php if(isset($TotalRobi)){ echo $TotalRobi; }else{ echo '0'; } ?></b>
									</a> 
								</li>
                                <li> 
									<a href="<?php echo base_url('index.php/Apps/AirtelStock/'); ?>">
										<i class="menu-icon icon-inbox"></i>Airtel<b class="label green pull-right"><?php if(isset($TotalAirtel)){ echo $TotalAirtel; }else{ echo '0'; } ?></b>
									</a> 
								</li>
                                <li> 
									<a href="<?php echo base_url('index.php/Apps/TeletalkStock/'); ?>">
										<i class="menu-icon icon-inbox"></i>Teletalk<b class="label green pull-right"><?php if(isset($TotalTeletalk)){ echo $TotalTeletalk; }else{ echo '0'; } ?></b>
									</a> 
								</li>
                            </ul>
                            <!--/.widget-nav-->
                            <ul class="widget widget-menu unstyled">
                                <li class="active text-center">
									<a  style ="color:#fff;font-weight:bold;font-size:14px;">
									   	Sale Option 
									</a>
								</li>
                                <li> 
									<a href="<?php echo base_url('index.php/Apps/SaleAdd/'); ?>">
										<i class="menu-icon icon-inbox"></i> Add Sale 
									</a> 
									</li>
                                <li>
									<a href="<?php echo base_url('index.php/Apps/SaleList/'); ?>">
										<i class="menu-icon icon-tasks"></i> Sale List <b class="label green pull-right"><?php if(isset($Totalsale)){ echo $Totalsale; }else{ echo '0'; } ?></b>
									</a>
								</li>
                            </ul>      
<?php 
	}elseif($pData->types == 'Salesman'){
?>
                            <!--/.widget-nav-->
                            <ul class="widget widget-menu unstyled">
                                <li class="active text-center">
									<a  style ="color:#fff;font-weight:bold;font-size:14px;">
									   	Stock Option 
									</a>
								</li>
                                <li> 
									<a href="<?php echo base_url('index.php/Apps/GpStock/'); ?>">
										<i class="menu-icon icon-inbox"></i>Grameenphone <b class="label green pull-right"><?php if(isset($TotalGp)){ echo $TotalGp; }else{ echo '0'; } ?></b>
									</a> 
								</li>
                                <li> 
									<a href="<?php echo base_url('index.php/Apps/BlStock/'); ?>">
										<i class="menu-icon icon-inbox"></i>Banglalink <b class="label green pull-right"><?php if(isset($TotalBl)){ echo $TotalBl; }else{ echo '0'; } ?></b>
									</a> 
								</li>
                                <li> 
									<a href="<?php echo base_url('index.php/Apps/RobiStock/'); ?>">
										<i class="menu-icon icon-inbox"></i>Robi<b class="label green pull-right"><?php if(isset($TotalRobi)){ echo $TotalRobi; }else{ echo '0'; } ?></b>
									</a> 
								</li>
                                <li> 
									<a href="<?php echo base_url('index.php/Apps/AirtelStock/'); ?>">
										<i class="menu-icon icon-inbox"></i>Airtel<b class="label green pull-right"><?php if(isset($TotalAirtel)){ echo $TotalAirtel; }else{ echo '0'; } ?></b>
									</a> 
								</li>
                                <li> 
									<a href="<?php echo base_url('index.php/Apps/TeletalkStock/'); ?>">
										<i class="menu-icon icon-inbox"></i>Teletalk<b class="label green pull-right"><?php if(isset($TotalTeletalk)){ echo $TotalTeletalk; }else{ echo '0'; } ?></b>
									</a> 
								</li>
                            </ul>
                            <!--/.widget-nav-->
                            <ul class="widget widget-menu unstyled">
                                <li class="active text-center">
									<a  style ="color:#fff;font-weight:bold;font-size:14px;">
									   	Sale Option 
									</a>
								</li>
                                <li> 
									<a href="<?php echo base_url('index.php/Apps/SaleAdd/'); ?>">
										<i class="menu-icon icon-inbox"></i> Add Sale 
									</a> 
									</li>
                                <li>
									<a href="<?php echo base_url('index.php/Apps/SaleList/'); ?>">
										<i class="menu-icon icon-tasks"></i> Sale List <b class="label green pull-right"><?php if(isset($Totalsale)){ echo $Totalsale; }else{ echo '0'; } ?></b>
									</a>
								</li>
                            </ul>  

<?php 
	}
?>

                            

                            <!--/.widget-nav-->
							
                        </div>
                        <!--/.sidebar-->
                    </div>
                    <!--/.span3-->

