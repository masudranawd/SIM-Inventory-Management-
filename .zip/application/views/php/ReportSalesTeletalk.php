﻿				<div class="span9">
					<div class="content">

						<div class="module">
							<div class="module-head" style="text-align: center;">
								<h3 style="text-align: left;"> REPORTS :) Sales Teletalk </h3>
									<h2>
									<a href="<?php echo base_url('index.php/Apps/ReportSales/'); ?>">ALl</a> 
									<a href="<?php echo base_url('index.php/Apps/ReportSalesGp/'); ?>">Gp</a> 
									<a href="<?php echo base_url('index.php/Apps/ReportSalesBl/'); ?>">BL</a> 
									<a href="<?php echo base_url('index.php/Apps/ReportSalesAirtel/'); ?>">Airtel</a> 
									<a href="<?php echo base_url('index.php/Apps/ReportSalesRobi/'); ?>">Robi</a> 
									<a href="<?php echo base_url('index.php/Apps/ReportSalesTeletalk/'); ?>"  style="background: teal;border-radius: 20px;padding:11px;color:#fff;">Teletalk</a> 
								</h2>
							</div>
							
							<div class="" style="padding: 20px ;margin:0px auto;width:80%; ">
								<form class="form-inline clearfix" action="<?php echo base_url('index.php/Apps/ReportSales/'); ?>" method="post">
								
								<div class="form-group" style="float:left;margin-left: 5px;">
								    <label for="exampleInputEmail2">Form :</label>
									 <input type="date" name="fromdate" class="form-control" id="exampleInputName2">
								  </div>
								
								  <div class="form-group" style="float:left;margin-left: 5px;">
								    <label for="exampleInputEmail2">To : </label>
								    <input type="date" name="todate" class="form-control" id="exampleInputEmail2">
								  </div>

								  <div class="form-group" style="float:left;margin-left: 5px;">
								    <button name="bykey" class="btn btn-primary">Search</button>
								  </div>
								</form>		
							</div>

						<div class="module">
							<div class="module-body table">
 

<?php 
	if($saleDataList){
?>
								<table cellpadding="0" cellspacing="0" border="0" class="table table-bordered table-striped	 display" style="width:98%; margin:0px auto; ">
									<thead>
										<tr>
											<th colspan="6" style="text-align:center;">
												<small style=" margin-top:15px; color:black; font-weight: bold; " class="pull-left" >
													Type: Teletalk  
												</small>
													<small style=" margin-top:15px; color:black; font-weight: bold; text-align: right;" class="pull-right" >
													From:  <?php echo $fromdate; ?> &mdash;  
													 To: <?php echo $todate; ?>
												</small>
											</th>
										</tr>
										<tr>
											<th>SL</th>
											<th>SIM Name</th>
											<th>SIM Number</th>
											<th>Sale Date</th>
											<th>Total Buy</th>
											<th>Total Sale</th>
										</tr>
									</thead>
									<tbody>
										<?php
											$i=0;
											$total = 0; 
											$totals =0;
											foreach($saleDataList as $saleData){
											if($saleData->sim_name =='teletalk'){
												$total = $total+$saleData->buy_price; 
												$totals = $totals+$saleData->sale_price;
												$i++; 
										?>
										<tr class="odd gradeX">
											<td><?php echo $i; ?></td>
											<td><?php echo $saleData->sim_name; ?></td>
											<td><?php  echo $saleData->sim_number;  ?></td>
											<td><?php  echo $saleData->created_at;  ?></td>
											<td><?php echo sprintf('%0.2f',$saleData->buy_price); ?></td>
											<td><?php echo sprintf('%0.2f',$saleData->sale_price); ?></td>
										</tr>

										<?php	}	
											}//end of foreach
										?>
										<tr class="odd gradeX">
											<th colspan="4" style="text-align: right;">TOTAL</th>
											<th><?php echo sprintf('%0.2f',$total); ?></th>
											<th><?php echo sprintf('%0.2f',$totals); ?></th>
										</tr>
									</tbody>
								</table></div>
								<br/>							
								<center>
									<form target="_blank" method="post" action="<?php echo base_url('index.php/Apps/ReportSalesPrintTeletalk/'); ?>">
										<input type="hidden" name="fromdate" value="<?php echo $fromdate; ?>">
										<input type="hidden" name="todate" value="<?php echo $todate; ?>">
										<button class="btn btn-sm btn-primary" name="bykey"   type="submit" target="_blank">PRINT</button>
									</form>		
								</center>									
<?php 
	}else{
?>
<div class="alert alert-warning">NO SEARCH KEWWORD !</div>
<?php 
	}
?>
						
							
						</div>
					</div><!--/.module-->
				</div>
				</div><!--/.content-->
			</div><!--/.span9-->
		</div>
	</div><!--/.container-->
</div><!--/.wrapper-->

<script>
  function printDiv(divName){
    var printContents = document.getElementById(divName).innerHTML;
    var originalContents = document.body.innerHTML;
    document.body.innerHTML = printContents;
    window.print();
    document.body.innerHTML = originalContents;
  }
</script>
<script>
function close_window() {
  if (confirm("Close Window?")) {
    close();
  }
}
</script>