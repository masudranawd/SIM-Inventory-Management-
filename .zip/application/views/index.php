<?php
defined('BASEPATH') OR exit('No direct script access allowed');

/*
Project Name: DT_Pharmacy
Project Type: Pharmacy/Store Management System. 
Author : DwinsTeam 
Author URI: http://dwinsteam.com/
Media Partner: AIMS365 (marketing), AR Irtaza (Ownership), Development By(DwinsTeam Members). 
Last Update: 28 November 2019 
Version: 1.0
*/
?>