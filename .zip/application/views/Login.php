<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
    <title>Pos Pharmacy</title>

    <!-- Bootstrap --><link type="text/css" href="<?php echo base_url(); ?>bootstrap/css/bootstrap.min.css" rel="stylesheet">
        <link type="text/css" href="<?php echo base_url(); ?>bootstrap/css/bootstrap-responsive.min.css" rel="stylesheet">
    <style>


		body{
			background:#fff;
		}
	</style>
  </head>
  <body>

				<div class="span6" style="margin:0px auto; "></div>
				<div class="span3" style="margin:180px auto; ">
					<div class="content">

						<div class="module">
							<div class="module-body">
									<form action="<?php echo base_url('index.php/User/Login_From/');?>" method="post" class="form row-fluid">
										<div class="control-group">
											<label class="control-label" for="user_id" style="font-weight: bold;">User ID</label>
											<div class="controls">
												<input name="user_id" type="text" id="user_id" placeholder="Enter User ID !" class="span12">
											</div>
										</div>
										<div class="control-group">
											<label class="control-label" for="password" style="font-weight: bold;">Password</label>
											<div class="controls">
												<input name="password" type="password" id="password" placeholder="Enter Password !" class="span12">
											</div>
										</div>
										<div class="control-group">
											<div class="controls">
												<button type="submit" class="btn btn-primary">Login</button> 	
												&nbsp; <?php echo $this->session->flashdata('msg'); ?>
											</div>
										</div>
									</form>

							</div>
						</div>

						
						
					</div><!--/.content-->
				</div><!--/.span9-->



    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
    <!-- Include all compiled plugins (below), or include individual files as needed -->
    <script src="js/bootstrap.min.js"></script>
  </body>
</html>