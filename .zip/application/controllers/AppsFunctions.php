<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class AppsFunctions extends CI_Controller {

	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * 		http://example.com/index.php/welcome
	 *	- or -
	 * 		http://example.com/index.php/welcome/index
	 *	- or -
	 * Since this controller is set as the default controller in
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * @see https://codeigniter.com/user_guide/general/urls.html
	 */
	public function __construct(){
		parent::__construct(); 
		/*----------------------------------*/
		$this->load->model("Apps_model");
		/*----------------------------------*/
	}

//ADD SIM ****************************************************

public function SimAddMethod () {
$data = array(); 
		/*---------------------------------------------------------*/
		$data['sim_name'] = $this->input->post('sim_name'); 
		$data['sim_number'] = $this->input->post('sim_number'); 
		$data['category'] = $this->input->post('category'); 
		$data['sim_condition'] = $this->input->post('sim_condition'); 
		$data['buy_date'] = $this->input->post('buy_date'); 
		$data['have_name'] = $this->input->post('have_name'); 
		$data['buy_price'] = $this->input->post('buy_price'); 
		/*---------------------------------------------------------*/

		$activityTable = 'tb_activity';
		$activityData = array();

		$sim_number = $data['sim_number']; 

		if(empty($sim_number) ){
			$sdata = array();
			$sdata['msg'] = '<span style="color:red;">Login Failed !</span>'; 
			$this->session->set_flashdata($sdata);
			redirect('Apps/SimAdd/',$sdata); 
		}else{
			$sdata = array();
			$check = $this->Apps_model->CheckData($data);
			 if($check == false){
				$data = array(); 

				$data['sim_name'] = $this->input->post('sim_name'); 
				$data['sim_number'] = $this->input->post('sim_number');
				$data['category'] = $this->input->post('category'); 
				$data['sim_condition'] = $this->input->post('sim_condition'); 
				$data['buy_date'] = $this->input->post('buy_date'); 
				$data['have_name'] = $this->input->post('have_name'); 
				$data['buy_price'] = $this->input->post('buy_price'); 

				$this->Apps_model->insert_data_to_db($data);//set as session... 

				$sdata = array();
				$sdata['msg'] = '<div class="alert alert-success"><button type="button" class="close" data-dismiss="alert">×</button><strong>Save Successfully !</strong> Save Another Data  :)</div>';

			$activityData['activity_details'] = '<div class="alert alert-success">Success :) 1 SIM Add By &mdash; '.$this->session->firstname.' '.$this->session->lastname.' <span style="font-size:12px;">('.$this->session->user_id.')</span> </div>';

				$this->session->set_flashdata($sdata);

			$this->Apps_model->Add_data_model($activityTable,$activityData); //ACTIVITY UPDATED...
				redirect('Apps/SimAdd/',$sdata); 
			}else{
			$sdata = array();
			$sdata['msg'] = '<div class="alert alert-error"><button type="button" class="close" data-dismiss="alert">×</button><strong>The Number already taken, try another Number Entry!</strong>  :)</div>';

			$this->session->set_flashdata($sdata);
				redirect('Apps/SimAdd/',$sdata); 
			}
		}

}

/****************************************************************************
*Sim / 1UPDATE Function method.. 
*/	
	public function SimUpdateMethod(){
		/*----------------------------------------------------------*/
		$table = 'tb_sim';
		/*----------------------------------------------------------*/
		$data = array();
		$data['sim_id'] = $this->input->post('sim_id');
		$data['sim_name'] = $this->input->post('sim_name');
		$data['sim_number'] = $this->input->post('sim_number');
		$data['category'] = $this->input->post('category');
		$data['sim_condition'] = $this->input->post('sim_condition');
		$data['buy_date'] = $this->input->post('buy_date');
		$data['have_name'] = $this->input->post('have_name');
		$data['buy_price'] = $this->input->post('buy_price');
		$sdata = array();
		/*----------------------------------------------------------*/
		$activityTable = 'tb_activity';
		$activityData = array();
		/*----------------------------------------------------------*/
			$this->Apps_model->sim_update_model($table,$data); 			/*---------------------------------------------------------*/
			$sdata['msg'] = '<div class="alert alert-success"><button type="button" class="close" data-dismiss="alert">×</button><strong>Successfully Updated !</strong> :)</div>';
			$activityData['activity_details'] = '<div class="alert alert-warning">Success :) Update SIM By &mdash; '.$this->session->firstname.' '.$this->session->lastname.' <span style="font-size:12px;">('.$this->session->user_id.')</span> </div>';
			/*---------------------------------------------------------*/		$this->Apps_model->Add_data_model($activityTable,$activityData); //ACTIVITY UPDATED...
		$this->session->set_flashdata($sdata);
		redirect('Apps/',$data); 
	}
/****************************************************************************
*PRODUCT REMOVE CI METHOD... 
*/	
	public function SimRemoveMethod($id){
		/*----------------------------------------------------------*/
		$table = 'tb_sim';
		/*----------------------------------------------------------*/
		$data = array();
		$data['match_by'] = $id;
		$data['match_col'] = 'sim_id';

		/*----------------------------------------------------------*/
		$activityTable = 'tb_activity';
		$activityData = array();
		$activityData['activity_details'] = '<div class="alert alert-danger">Removed :) SIM removed By &mdash; '.$this->session->firstname.' '.$this->session->lastname.' <span style="font-size:12px;">('.$this->session->user_id.')</span> </div>';
		/*----------------------------------------------------------*/

		$this->Apps_model->Remove_data_by_id_model($table,$data); 
		/*---------------------------------------------------------*/
		$sdata = array(); 
		$sdata['msg'] = '<div class="alert alert-danger"><button type="button" class="close" data-dismiss="alert">×</button><strong>Successfully Deleted !</strong> :)</div>';
		$this->session->set_flashdata($sdata);
		/*---------------------------------------------------------*/
		$this->Apps_model->Add_data_model($activityTable,$activityData); //ACTIVITY UPDATED...
		redirect('Apps/AllSimList/',$sdata); 
	}	

/****************************************************************************
*option company logo update CI METHOD... 
*/	

	public function logoupdate(){
		$optdata = array();

		/*--ACTIVITY STATUS UPDATE----------------------------------*/
		$activityTable = 'tb_activity';
		$activityData = array();
		$activityData['activity_details'] = '<div class="alert alert-success">Success :) Logo Updated By &mdash; '.$this->session->firstname.' '.$this->session->lastname.' <span style="font-size:12px;">('.$this->session->user_id.')</span> </div>';
		$this->Apps_model->Add_data_model($activityTable,$activityData); //ACTIVITY UPDATED...
		/*----------------------------------------------------------*/
		$optdata['options_id']  = $this->input->post('options_id');
		$old_logo				= $this->input->post('old_logo');
		/*-----------------------------------------------*/
		$change_logo = $_FILES["company_logo"]['name'];

		if(!empty($change_logo)){
		unlink('images/'.$old_logo); 
		$new_name                   	= 'Logo_'.time().$change_logo; 
		$config['file_name']        	= $new_name;
		$config['upload_path']          = './images/';
	    $config['allowed_types']        = 'gif|jpg|png|ico|jpeg';
		$this->load->library('upload', $config);
	    $optdata['company_logo'] = $new_name;

	    if (! $this->upload->do_upload('company_logo')){
	    $error = array('error' => $this->upload->display_errors());
	    $this->load->view('upload_form', $error);
	    }else{	
	    array('upload_data' => $this->upload->data());
	     }
		}
		$this->Apps_model->companylogoupdate($optdata); 	
		redirect('Apps/Options/'); 		
	}
/****************************************************************************
*Change Invoice Header update CI METHOD... 
*/	

	public function ChangeInvoiceHeader(){
		$optdata = array();

		/*--ACTIVITY STATUS UPDATE----------------------------------*/
		$activityTable = 'tb_activity';
		$activityData = array();
		$activityData['activity_details'] = '<div class="alert alert-warning">Success :) Invoice Header Updated By &mdash; '.$this->session->firstname.' '.$this->session->lastname.' <span style="font-size:12px;">('.$this->session->user_id.')</span> </div>';
		$this->Apps_model->Add_data_model($activityTable,$activityData); //ACTIVITY UPDATED...
		/*----------------------------------------------------------*/

		$optdata['options_id'] = $this->input->post('options_id');
		$old_invoice_header				= $this->input->post('old_invoice_header');
		/*-----------------------------------------------*/
		$change_invoice_header = $_FILES["invoice_header"]['name'];

		if(!empty($change_invoice_header)){
		unlink('images/'.$old_invoice_header); 
		$new_name                   	= 'Inv_header_'.time().$change_invoice_header; 
		$config['file_name']        	= $new_name;
		$config['upload_path']          = './images/';
	    $config['allowed_types']        = 'gif|jpg|png';
		$this->load->library('upload', $config);
	    $optdata['invoice_header'] = $new_name;

	    if (! $this->upload->do_upload('invoice_header')){
	    $error = array('error' => $this->upload->display_errors());
	    $this->load->view('upload_form', $error);
	    }else{	
	    array('upload_data' => $this->upload->data());
	     }
		}
		$this->Apps_model->InvoiceHeaderUpdate($optdata); 	
		redirect('Apps/Options/'); 		
	}

/****************************************************************************
*Change Invoice Header update CI METHOD... 
*/	

	public function ChangeInvoiceSeal(){
		$optdata = array();
		
		/*--ACTIVITY STATUS UPDATE----------------------------------*/
		$activityTable = 'tb_activity';
		$activityData = array();
		$activityData['activity_details'] = '<div class="alert alert-warning">Success :) Invoice Seal Updated By &mdash; '.$this->session->firstname.' '.$this->session->lastname.' <span style="font-size:12px;">('.$this->session->user_id.')</span> </div>';
		$this->Apps_model->Add_data_model($activityTable,$activityData); //ACTIVITY UPDATED...
		/*----------------------------------------------------------*/

		$optdata['options_id'] = $this->input->post('options_id');
		$old_invoice_seal				= $this->input->post('old_invoice_seal');
		/*-----------------------------------------------*/
		$change_invoice_seal = $_FILES["invoice_seal"]['name'];

		if(!empty($change_invoice_seal)){
		unlink('images/'.$old_invoice_seal); 
		$new_name                   	= 'Inv_seal_'.time().$change_invoice_seal; 
		$config['file_name']        	= $new_name;
		$config['upload_path']          = './images/';
	    $config['allowed_types']        = 'gif|jpg|png';
		$this->load->library('upload', $config);
	    $optdata['invoice_seal'] = $new_name;

	    if (! $this->upload->do_upload('invoice_seal')){
	    $error = array('error' => $this->upload->display_errors());
	    $this->load->view('upload_form', $error);
	    }else{	
	    array('upload_data' => $this->upload->data());
	     }
		}
		$this->Apps_model->InvoiceSealUpdate($optdata); 	
		redirect('Apps/Options/'); 		
	}
	
/****************************************************************************
*Change Invoice Paid Seal update CI METHOD... 
*/	

	public function ChangeInvoicePaidSeal(){
		$optdata = array();

		/*--ACTIVITY STATUS UPDATE----------------------------------*/
		$activityTable = 'tb_activity';
		$activityData = array();
		$activityData['activity_details'] = '<div class="alert alert-success">Success :) InvoicePaid Seal Updated By &mdash; '.$this->session->firstname.' '.$this->session->lastname.' <span style="font-size:12px;">('.$this->session->user_id.')</span> </div>';
		$this->Apps_model->Add_data_model($activityTable,$activityData); //ACTIVITY UPDATED...
		/*----------------------------------------------------------*/

		$optdata['options_id'] = $this->input->post('options_id');
		$old_invoice_paid_seal				= $this->input->post('old_invoice_paid_seal');
		/*-----------------------------------------------*/
		$change_invoice_paid_seal = $_FILES["invoice_paid_seal"]['name'];

		if(!empty($change_invoice_paid_seal)){
		unlink('images/'.$old_invoice_paid_seal); 
		$new_name                   	= 'Inv_Paid_'.time().$change_invoice_paid_seal; 
		$config['file_name']        	= $new_name;
		$config['upload_path']          = './images/';
	    $config['allowed_types']        = 'gif|jpg|png';
		$this->load->library('upload', $config);
	    $optdata['invoice_paid_seal'] = $new_name;

	    if (! $this->upload->do_upload('invoice_paid_seal')){
	    $error = array('error' => $this->upload->display_errors());
	    $this->load->view('upload_form', $error);
	    }else{	
	    array('upload_data' => $this->upload->data());
	     }
		}
		$this->Apps_model->ChangeInvoicePaidUpdate($optdata); 	
		redirect('Apps/Options/'); 		
	}

/****************************************************************************
*Options site update CI METHOD... 
*/	

	public function OptionsUpdateMethod(){
		$optdata = array();
		
		/*--ACTIVITY STATUS UPDATE----------------------------------*/
		$activityTable = 'tb_activity';
		$activityData = array();
		$activityData['activity_details'] = '<div class="alert alert-success"> Success :) Site Info Updated By &mdash; '.$this->session->firstname.' '.$this->session->lastname.' <span style="font-size:12px;">('.$this->session->user_id.')</span> </div>';
		$this->Apps_model->Add_data_model($activityTable,$activityData); //ACTIVITY UPDATED...
		/*----------------------------------------------------------*/

		$optdata['options_id'] = $this->input->post('options_id');
		$optdata['company_title'] = $this->input->post('company_title');
		$optdata['company_slogan'] = $this->input->post('company_slogan');
		$optdata['company_mobile'] = $this->input->post('company_mobile');
		$optdata['company_address'] = $this->input->post('company_address');

		if(empty($optdata['options_id'])){		
			$sdata['msg'] = '<div class="alert alert-warning"><button type="button" class="close" data-dismiss="alert">×</button><strong>Faild To Update !</strong> Please Try Again:)</div>';
		}else{
			$sdata['msg'] = '<div class="alert alert-success"><button type="button" class="close" data-dismiss="alert">×</button><strong>Successfully Updated !</strong> :)</div>';
		}
		$this->session->set_flashdata($sdata);
		$this->Apps_model->Options_site_model_update($optdata); //ACTIVITY UPDATED...
		redirect('Apps/Options/'); 
	}


//ACTIVE CATEGORY***********************************************************************
	public function OptionsStatusActiveMethod($id){  		
		/*--ACTIVITY STATUS UPDATE----------------------------------*/
		$activityTable = 'tb_activity';
		$activityData = array();
		$activityData['activity_details'] = '<div class="alert alert-warning">Updated :) Site Option Status Off By &mdash; '.$this->session->firstname.' '.$this->session->lastname.' <span style="font-size:12px;">('.$this->session->user_id.')</span> </div>';
		$this->Apps_model->Add_data_model($activityTable,$activityData); //ACTIVITY UPDATED...
		
		$table = 'tb_options';
		/*----------------------------------------------------------*/
		$data = array();
		$data['match_col'] = 'options_id';
		$data['match_by'] = $id; 
		$data['site_status'] = 1;
		$this->Apps_model->Update_site_status_model($table,$data);
		redirect('Apps/Options/');
	}

//IN-ACVICE SIM ******************************************************
	public function OptionsStatusInActiveMethod($id){ 
		
		/*--ACTIVITY STATUS UPDATE----------------------------------*/
		$activityTable = 'tb_activity';
		$activityData = array();
		$activityData['activity_details'] = '<div class="alert alert-warning">Updated :) Site Option Status Off By &mdash; '.$this->session->firstname.' '.$this->session->lastname.' <span style="font-size:12px;">('.$this->session->user_id.')</span> </div>';
		$this->Apps_model->Add_data_model($activityTable,$activityData); //ACTIVITY UPDATED...
		/*----------------------------------------------------------*/
		$table = 'tb_options';
		/*----------------------------------------------------------*/
		$data = array();
		$data['match_col'] = 'options_id';
		$data['match_by'] = $id; 
		$data['site_status'] = 0;
		$this->Apps_model->Update_site_status_model($table,$data);
		redirect('Apps/Options/');
	}

//ORDER OPTIONS....
	public function AddToSale(){
		/*--ACTIVITY STATUS UPDATE----------------------------------*/
		$activityTable = 'tb_activity';
		$activityData = array();
		$activityData['activity_details'] = '<div class="alert alert-success">Success :) SIM Sale By &mdash; '.$this->session->firstname.' '.$this->session->lastname.' <span style="font-size:12px;">('.$this->session->user_id.')</span> </div>';
		$this->Apps_model->Add_data_model($activityTable,$activityData); //ACTIVITY UPDATED...
		/*----------------------------------------------------------*/
		$table = 'tb_sale';
		/*----------------------------------------------------------*/
		$data = array(
			'sim_id' => $this->input->post('sim_id'), 
			'sim_name' => $this->input->post('sim_name'), 
			'sim_number' => $this->input->post('sim_number'),
			'category' => $this->input->post('category'), 
			'sim_condition' => $this->input->post('sim_condition'), 
			'buy_date' => $this->input->post('buy_date'), 
			'have_name' => $this->input->post('have_name'), 
			'buy_price' => $this->input->post('buy_price'), 
			'seller_name' => $this->input->post('seller_name'), 
			'sale_price' => $this->input->post('sale_price'), 
		);


		if(!empty($data['sale_price']) OR empty($data['seller_name'] OR empty($data['sale_date']))){
			$this->Apps_model->Add_data_model($table,$data); //DATA SAVE METHOD CALLING... 		

			$rtable = 'tb_sim'; 
			$rdata = array(
			'match_col' => 'sim_id',
			'match_by' => $data['sim_id'],
			'status'	=> 1
		); 
		$this->Apps_model->Update_status_model($rtable,$rdata);	
		}
		redirect('Apps/SaleAdd/');		
	}

/****************************************************************************
*Sim / UPDATE Function method.. 
*/
	 public function saleToUpdate(){
            $data = array();
            $table ='tb_sale';
            $data['sale_id'] = $this->input->post('sale_id');
            $data['sim_id'] = $this->input->post('sim_id');
            $data['sim_name'] = $this->input->post('sim_name');
            $data['sim_number'] = $this->input->post('sim_number');
            $data['category'] = $this->input->post('category');
            $data['sim_condition'] = $this->input->post('sim_condition');
            $data['buy_date'] = $this->input->post('buy_date');
            $data['have_name'] = $this->input->post('have_name');
            $data['buy_price'] = $this->input->post('buy_price');
            $data['seller_name'] = $this->input->post('seller_name');
            $data['sale_price'] = $this->input->post('sale_price');
                
                $this->Apps_model->sale_by_update_model_to($table,$data);
		redirect('Apps/SaleList/',$data); 
        }
        
}
