<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Apps extends CI_Controller {

	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * 		http://example.com/index.php/welcome
	 *	- or -
	 * 		http://example.com/index.php/welcome/index
	 *	- or -
	 * Since this controller is set as the default controller in
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * @see https://codeigniter.com/user_guide/general/urls.html
	 */
	public function __construct(){
		parent::__construct(); 
		/*----------------------------------*/
		$this->load->model("Apps_model");
		$this->load->model("User_model");
		$this->load->library('Pdf');
		/*----------------------------------*/
		
		$login_user = $this->session->userdata('id'); 
		if(isset($login_user)){
			$login_user; 
		}else{
			redirect('User/'); 
		} 
		
	}

	public function index(){
		$this->Home();
	}	

/****************************************************************************
*DASHBOARD / HOME UI/UX METHOD... 
*/
	public function Home(){
		$data = array(); 
		$optData = array();
		/*----------------------------------------------------------*/		
		$data['TotalUser'] = $this->Apps_model->CountAll('tb_user'); //USERS
		$data['onlineUser'] = $this->Apps_model->CountAllOnline('tb_user'); //ONLINE USERS 
		$data['blockedUser'] = $this->Apps_model->CountAllApprove('tb_user'); //ONLINE USERS 

		$table = 'tb_sim';
		$data['simDataList'] = $this->Apps_model->Get_data_model($table,$data);
		$data['Totalsim'] = $this->Apps_model->CountAll('tb_sim'); //NUMBER OF INVOICE.. 
		$data['Totalsale'] = $this->Apps_model->CountAll('tb_sale'); //NUMBER OF INVOICE.. 
		
		$data['TotalGp'] = $this->Apps_model->gdContALl('tb_sim'); //NUMBER OF Gp.. 
		$data['TotalBl'] = $this->Apps_model->blContALl('tb_sim'); //NUMBER OF Bl.. 
		$data['TotalRobi'] = $this->Apps_model->robiContALl('tb_sim'); //NUMBER OF Robi.. 
		$data['TotalAirtel'] = $this->Apps_model->airtelContALl('tb_sim'); //NUMBER OF Airtel.. 
		$data['TotalTeletalk'] = $this->Apps_model->teletalkContALl('tb_sim'); //NUMBER OF teletalk.. 
		
		/*----------------------------------------------------------*/
		$optTable = 'tb_options'; 
		$optData = array(
			'match_col' => 'options_id',
			'match_by' => 1
		); 	
		$data['optionsData'] = $this->Apps_model->Get_data_by_id_model($optTable,$optData);
		/*----------------------------------------------------------*/
		$data['pData'] = $this->User_model->GetUserById(array('uid'=>$this->session->id)); 
		/*----------------------------------------------------------*/
		$data['header'] = $this->load->view('php/Header.php',$data); 
		$data['sidebar'] = $this->load->view('php/Sidebar.php',$data); 
		$data['content'] = $this->load->view('php/Home.php',$data); 
		$data['footer'] = $this->load->view('php/Footer.php',$data); 
		/*---------------------------------------------------------*/
		$this->load->view('index',$data); 
	}
	
/****************************************************************************
*OPTIONS UI/UX METHOD...
*/
	public function Options(){
		$data = array(); 
		$optData = array();
		$table = 'tb_sim';
		$data['Totalsim'] = $this->Apps_model->CountAll('tb_sim'); //NUMBER OF INVOICE.. 

		$data['Totalsale'] = $this->Apps_model->CountAll('tb_sale'); //NUMBER OF INVOICE.

		$data['TotalGp'] = $this->Apps_model->gdContALl('tb_sim'); //NUMBER OF Gp.. 
		$data['TotalBl'] = $this->Apps_model->blContALl('tb_sim'); //NUMBER OF Bl.. 
		$data['TotalRobi'] = $this->Apps_model->robiContALl('tb_sim'); //NUMBER OF Robi.. 
		$data['TotalAirtel'] = $this->Apps_model->airtelContALl('tb_sim'); //NUMBER OF Airtel.. 
		$data['TotalTeletalk'] = $this->Apps_model->teletalkContALl('tb_sim'); //NUMBER OF teletalk.. 
		
		/*----------------------------------------------------------*/		
		$optTable = 'tb_options'; 
		$optData = array(
			'match_col' => 'options_id',
			'match_by' => 1
		); 	
		$data['optionsData'] = $this->Apps_model->Get_data_by_id_model($optTable,$optData);
		/*----------------------------------------------------------*/
		$data['pData'] = $this->User_model->GetUserById(array('uid'=>$this->session->id));
		/*----------------------------------------------------------*/
		$data['header'] = $this->load->view('php/Header.php',$data); 
		$data['sidebar'] = $this->load->view('php/Sidebar.php',$data); 
		$data['content'] = $this->load->view('php/Options.php',$data); 
		$data['footer'] = $this->load->view('php/Footer.php',$data); 
		/*---------------------------------------------------------*/
		$this->load->view('index',$data); 
	}	
	
/****************************************************************************
*SIM / ADD UI/UX METHOD... 
*/
	public function SimAdd(){
		$data = array();
		$table = 'tb_sim';
		$data['Totalsim'] = $this->Apps_model->CountAll('tb_sim'); //NUMBER OF INVOICE.. 

		$data['Totalsale'] = $this->Apps_model->CountAll('tb_sale'); //NUMBER OF INVOICE.
		$data['TotalGp'] = $this->Apps_model->gdContALl('tb_sim'); //NUMBER OF Gp.. 
		$data['TotalBl'] = $this->Apps_model->blContALl('tb_sim'); //NUMBER OF Bl.. 
		$data['TotalRobi'] = $this->Apps_model->robiContALl('tb_sim'); //NUMBER OF Robi.. 
		$data['TotalAirtel'] = $this->Apps_model->airtelContALl('tb_sim'); //NUMBER OF Airtel.. 
		$data['TotalTeletalk'] = $this->Apps_model->teletalkContALl('tb_sim'); //NUMBER OF teletalk.. 
	
		/*----------------------------------------------------------*/		
		$optTable = 'tb_options'; 
		$optData = array(
			'match_col' => 'options_id',
			'match_by' => 1
		); 	
		$data['optionsData'] = $this->Apps_model->Get_data_by_id_model($optTable,$optData);
		/*----------------------------------------------------------*/
		$data['pData'] = $this->User_model->GetUserById(array('uid'=>$this->session->id));
		/*----------------------------------------------------------*/
		$data['header'] = $this->load->view('php/Header.php',$data);
		$data['sidebar'] = $this->load->view('php/Sidebar.php',$data);
		$data['content'] = $this->load->view('php/Sim_add.php',$data);
		$data['footer'] = $this->load->view('php/Footer.php',$data);
		/*----------------------------------------------------------*/
	}		
/****************************************************************************
*SIM / LIST UI/UX METHOD... 
*/
	public function AllSimList(){
		$data = array();
		$table = 'tb_sim';
		$data['Totalsim'] = $this->Apps_model->CountAll('tb_sim'); //NUMBER OF INVOICE..  
		$data['Totalsale'] = $this->Apps_model->CountAll('tb_sale'); //NUMBER OF INVOICE.

		$data['TotalGp'] = $this->Apps_model->gdContALl('tb_sim'); //NUMBER OF Gp.. 
		$data['TotalBl'] = $this->Apps_model->blContALl('tb_sim'); //NUMBER OF Bl.. 
		$data['TotalRobi'] = $this->Apps_model->robiContALl('tb_sim'); //NUMBER OF Robi.. 
		$data['TotalAirtel'] = $this->Apps_model->airtelContALl('tb_sim'); //NUMBER OF Airtel.. 
		$data['TotalTeletalk'] = $this->Apps_model->teletalkContALl('tb_sim'); //NUMBER OF teletalk.. 
		
		/*----------------------------------------------------------*/		
		$optTable = 'tb_options'; 
		$optData = array(
			'match_col' => 'options_id',
			'match_by' => 1
		);
		$data['optionsData'] = $this->Apps_model->Get_data_by_id_model($optTable,$optData);
		/*----------------------------------------------------------*/
		
		$table = 'tb_sim';
		$data['allSimDataList'] = $this->Apps_model->Get_data_model($table,$data);
		/*----------------------------------------------------------*/
		$data['pData'] = $this->User_model->GetUserById(array('uid'=>$this->session->id));
		/*----------------------------------------------------------*/
		$data['header'] = $this->load->view('php/Header.php',$data);
		$data['Sidebar'] = $this->load->view('php/Sidebar.php',$data);
		$data['content'] = $this->load->view('php/Sim_list.php',$data);
		$data['footer'] = $this->load->view('php/Footer.php',$data);
		/*----------------------------------------------------------*/
		$this->load->view('index',$data);
	}		/****************************************************************************
*SIM / UPDATE UI/UX METHOD... 
*/
	public function SimUpdate($id){
		$data = array();
		$table = 'tb_sim';
		$data['productDataList'] = $this->Apps_model->Get_data_model($table,$data);
		$data['Totalsim'] = $this->Apps_model->CountAll('tb_sim'); //NUMBER OF INVOICE.. 
		$data['Totalsale'] = $this->Apps_model->CountAll('tb_sale'); //NUMBER OF INVOICE.

		$data['TotalGp'] = $this->Apps_model->gdContALl('tb_sim'); //NUMBER OF Gp.. 
		$data['TotalBl'] = $this->Apps_model->blContALl('tb_sim'); //NUMBER OF Bl.. 
		$data['TotalRobi'] = $this->Apps_model->robiContALl('tb_sim'); //NUMBER OF Robi.. 
		$data['TotalAirtel'] = $this->Apps_model->airtelContALl('tb_sim'); //NUMBER OF Airtel.. 
		$data['TotalTeletalk'] = $this->Apps_model->teletalkContALl('tb_sim'); //NUMBER OF teletalk.. 
		 
		/*----------------------------------------------------------*/		
		$optTable = 'tb_options'; 
		$optData = array(
			'match_col' => 'options_id',
			'match_by' => 1
		); 	
		$data['optionsData'] = $this->Apps_model->Get_data_by_id_model($optTable,$optData);
		/*----------------------------------------------------------*/
		$table = 'tb_sim';
		$data['match_col'] = 'sim_id';
		$data['match_by'] = $id; 
		$data['simData'] = $this->Apps_model->Get_data_by_id_model($table,$data);

		/*----------------------------------------------------------*/
		$data['pData'] = $this->User_model->GetUserById(array('uid'=>$this->session->id)); 		
		/*----------------------------------------------------------*/
		$data['header'] = $this->load->view('php/Header.php',$data);
		$data['Sidebar'] = $this->load->view('php/Sidebar.php',$data);
		$data['content'] = $this->load->view('php/sim_update.php',$data);
		$data['footer'] = $this->load->view('php/Footer.php',$data);
		/*----------------------------------------------------------*/
		$this->load->view('index',$data);
	}	
	
/****************************************************************************
*SIM / LIST UI/UX METHOD... 
*/
	public function GpStock(){
		$data = array();
		$table = 'tb_sim';
		$data['Totalsim'] = $this->Apps_model->CountAll('tb_sim'); //NUMBER OF INVOICE.. 
		$data['Totalsale'] = $this->Apps_model->CountAll('tb_sale'); //NUMBER OF INVOICE.

		$data['TotalGp'] = $this->Apps_model->gdContALl('tb_sim'); //NUMBER OF Gp.. 
		$data['TotalBl'] = $this->Apps_model->blContALl('tb_sim'); //NUMBER OF Bl.. 
		$data['TotalRobi'] = $this->Apps_model->robiContALl('tb_sim'); //NUMBER OF Robi.. 
		$data['TotalAirtel'] = $this->Apps_model->airtelContALl('tb_sim'); //NUMBER OF Airtel.. 
		$data['TotalTeletalk'] = $this->Apps_model->teletalkContALl('tb_sim'); //NUMBER OF teletalk.. 

		/*----------------------------------------------------------*/		
		$optTable = 'tb_options'; 
		$optData = array(
			'match_col' => 'options_id',
			'match_by' => 1
		); 	
		$data['optionsData'] = $this->Apps_model->Get_data_by_id_model($optTable,$optData);
		/*----------------------------------------------------------*/
		
		$table = 'tb_sim';
		$data['simDataList'] = $this->Apps_model->Get_data_stock_model($table,$data);
		/*----------------------------------------------------------*/
		$data['pData'] = $this->User_model->GetUserById(array('uid'=>$this->session->id));
		/*----------------------------------------------------------*/
		$data['header'] = $this->load->view('php/Header.php',$data);
		$data['Sidebar'] = $this->load->view('php/Sidebar.php',$data);
		$data['content'] = $this->load->view('php/Gp_stock.php',$data);
		$data['footer'] = $this->load->view('php/Footer.php',$data);
		/*----------------------------------------------------------*/
		$this->load->view('index',$data);
	}

/****************************************************************************
*SIM / LIST UI/UX METHOD... 
*/
	public function BlStock(){
		$data = array();
		$table = 'tb_sim';
		$data['Totalsim'] = $this->Apps_model->CountAll('tb_sim'); //NUMBER OF INVOICE.. 

		$data['Totalsale'] = $this->Apps_model->CountAll('tb_sale'); //NUMBER OF INVOICE.
		$data['TotalGp'] = $this->Apps_model->gdContALl('tb_sim'); //NUMBER OF Gp.. 
		$data['TotalBl'] = $this->Apps_model->blContALl('tb_sim'); //NUMBER OF Bl.. 
		$data['TotalRobi'] = $this->Apps_model->robiContALl('tb_sim'); //NUMBER OF Robi.. 
		$data['TotalAirtel'] = $this->Apps_model->airtelContALl('tb_sim'); //NUMBER OF Airtel.. 
		$data['TotalTeletalk'] = $this->Apps_model->teletalkContALl('tb_sim'); //NUMBER OF teletalk.. 

		/*----------------------------------------------------------*/		
		$optTable = 'tb_options'; 
		$optData = array(
			'match_col' => 'options_id',
			'match_by' => 1
		); 	
		$data['optionsData'] = $this->Apps_model->Get_data_by_id_model($optTable,$optData);
		/*----------------------------------------------------------*/
		$table = 'tb_sim';
		$data['simDataList'] = $this->Apps_model->Get_data_stock_model($table,$data);
		/*----------------------------------------------------------*/
		$data['pData'] = $this->User_model->GetUserById(array('uid'=>$this->session->id));
		/*----------------------------------------------------------*/
		$data['header'] = $this->load->view('php/Header.php',$data);
		$data['Sidebar'] = $this->load->view('php/Sidebar.php',$data);
		$data['content'] = $this->load->view('php/Bl_stock.php',$data);
		$data['footer'] = $this->load->view('php/Footer.php',$data);
		/*----------------------------------------------------------*/
		$this->load->view('index',$data);
	}

/****************************************************************************
*SIM / BL stock UI/UX METHOD... 
*/
	public function RobiStock(){
		$data = array();
		$table = 'tb_sim';
		$data['Totalsim'] = $this->Apps_model->CountAll('tb_sim'); //NUMBER OF INVOICE.. 
		$data['Totalsale'] = $this->Apps_model->CountAll('tb_sale'); //NUMBER OF INVOICE.

		$data['TotalGp'] = $this->Apps_model->gdContALl('tb_sim'); //NUMBER OF Gp.. 
		$data['TotalBl'] = $this->Apps_model->blContALl('tb_sim'); //NUMBER OF Bl.. 
		$data['TotalRobi'] = $this->Apps_model->robiContALl('tb_sim'); //NUMBER OF Robi.. 
		$data['TotalAirtel'] = $this->Apps_model->airtelContALl('tb_sim'); //NUMBER OF Airtel.. 
		$data['TotalTeletalk'] = $this->Apps_model->teletalkContALl('tb_sim'); //NUMBER OF teletalk.. 

		/*----------------------------------------------------------*/		
		$optTable = 'tb_options'; 
		$optData = array(
			'match_col' => 'options_id',
			'match_by' => 1
		); 	
		$data['optionsData'] = $this->Apps_model->Get_data_by_id_model($optTable,$optData);
		/*----------------------------------------------------------*/
		
		$table = 'tb_sim';
		$data['simDataList'] = $this->Apps_model->Get_data_stock_model($table,$data);
		/*----------------------------------------------------------*/
		$data['pData'] = $this->User_model->GetUserById(array('uid'=>$this->session->id));
		/*----------------------------------------------------------*/
		$data['header'] = $this->load->view('php/Header.php',$data);
		$data['Sidebar'] = $this->load->view('php/Sidebar.php',$data);
		$data['content'] = $this->load->view('php/Robi_stock.php',$data);
		$data['footer'] = $this->load->view('php/Footer.php',$data);
		/*----------------------------------------------------------*/
		$this->load->view('index',$data);
	}
/****************************************************************************
*SIM / LIST UI/UX METHOD... 
*/
	public function AirtelStock(){
		$data = array();
		$table = 'tb_sim';
		$data['Totalsim'] = $this->Apps_model->CountAll('tb_sim'); //NUMBER OF INVOICE.. 
		$data['Totalsale'] = $this->Apps_model->CountAll('tb_sale'); //NUMBER OF INVOICE.

		$data['TotalGp'] = $this->Apps_model->gdContALl('tb_sim'); //NUMBER OF Gp.. 
		$data['TotalBl'] = $this->Apps_model->blContALl('tb_sim'); //NUMBER OF Bl.. 
		$data['TotalRobi'] = $this->Apps_model->robiContALl('tb_sim'); //NUMBER OF Robi.. 
		$data['TotalAirtel'] = $this->Apps_model->airtelContALl('tb_sim'); //NUMBER OF Airtel.. 
		$data['TotalTeletalk'] = $this->Apps_model->teletalkContALl('tb_sim'); //NUMBER OF teletalk.. 

		/*----------------------------------------------------------*/		
		$optTable = 'tb_options'; 
		$optData = array(
			'match_col' => 'options_id',
			'match_by' => 1
		); 	
		$data['optionsData'] = $this->Apps_model->Get_data_by_id_model($optTable,$optData);
		/*----------------------------------------------------------*/
		
		$table = 'tb_sim';
		$data['simDataList'] = $this->Apps_model->Get_data_stock_model($table,$data);
		/*----------------------------------------------------------*/
		$data['pData'] = $this->User_model->GetUserById(array('uid'=>$this->session->id));
		/*----------------------------------------------------------*/
		$data['header'] = $this->load->view('php/Header.php',$data);
		$data['Sidebar'] = $this->load->view('php/Sidebar.php',$data);
		$data['content'] = $this->load->view('php/Airtel_stock.php',$data);
		$data['footer'] = $this->load->view('php/Footer.php',$data);
		/*----------------------------------------------------------*/
		$this->load->view('index',$data);
	}
/****************************************************************************
*SIM / LIST UI/UX METHOD... 
*/
	public function TeletalkStock(){
		$data = array();
		$table = 'tb_sim';
		$data['Totalsim'] = $this->Apps_model->CountAll('tb_sim'); //NUMBER OF INVOICE..
		$data['Totalsale'] = $this->Apps_model->CountAll('tb_sale'); //NUMBER OF INVOICE. 

		$data['TotalGp'] = $this->Apps_model->gdContALl('tb_sim'); //NUMBER OF Gp.. 
		$data['TotalBl'] = $this->Apps_model->blContALl('tb_sim'); //NUMBER OF Bl.. 
		$data['TotalRobi'] = $this->Apps_model->robiContALl('tb_sim'); //NUMBER OF Robi.. 
		$data['TotalAirtel'] = $this->Apps_model->airtelContALl('tb_sim'); //NUMBER OF Airtel.. 
		$data['TotalTeletalk'] = $this->Apps_model->teletalkContALl('tb_sim'); //NUMBER OF teletalk.. 

		/*----------------------------------------------------------*/		
		$optTable = 'tb_options'; 
		$optData = array(
			'match_col' => 'options_id',
			'match_by' => 1
		); 	
		$data['optionsData'] = $this->Apps_model->Get_data_by_id_model($optTable,$optData);
		/*----------------------------------------------------------*/
		
		$table = 'tb_sim';
		$data['simDataList'] = $this->Apps_model->Get_data_stock_model($table,$data);
		/*----------------------------------------------------------*/
		$data['pData'] = $this->User_model->GetUserById(array('uid'=>$this->session->id));
		/*----------------------------------------------------------*/
		$data['header'] = $this->load->view('php/Header.php',$data);
		$data['Sidebar'] = $this->load->view('php/Sidebar.php',$data);
		$data['content'] = $this->load->view('php/Teletalk_stock.php',$data);
		$data['footer'] = $this->load->view('php/Footer.php',$data);
		/*----------------------------------------------------------*/
		$this->load->view('index',$data);
	}

//SALE ADD FUNCTION...
	public function SaleAdd(){
		$data = array();
		$table = 'tb_sim';
		$data['simDataList'] = $this->Apps_model->Get_data_stock_model($table,$data); 
	
		$data['Totalsim'] = $this->Apps_model->CountAll('tb_sim'); //NUMBER OF INVOICE.. 
		$data['Totalsale'] = $this->Apps_model->CountAll('tb_sale'); //NUMBER OF INVOICE..  
		
		$data['TotalGp'] = $this->Apps_model->gdContALl('tb_sim'); //NUMBER OF Gp.. 
		$data['TotalBl'] = $this->Apps_model->blContALl('tb_sim'); //NUMBER OF Bl.. 
		$data['TotalRobi'] = $this->Apps_model->robiContALl('tb_sim'); //NUMBER OF Robi..   
		$data['TotalAirtel'] = $this->Apps_model->airtelContALl('tb_sim'); //NUMBER OF Airtel.. 
		$data['TotalTeletalk'] = $this->Apps_model->teletalkContALl('tb_sim'); //NUMBER OF teletalk.. 
		/*----------------------------------------------------------*/		
		$optTable = 'tb_options'; 
		$optData = array(
			'match_col' => 'options_id',
			'match_by' => 1
		); 	
		$data['optionsData'] = $this->Apps_model->Get_data_by_id_model($optTable,$optData);
		/*----------------------------------------------------------*/
		$table = 'tb_sim';
		$data['productDataList'] = $this->Apps_model->Get_data_model($table,$data);
		/*----------------------------------------------------------*/
		/*----------------------------------------------------------*/
		$data['pData'] = $this->User_model->GetUserById(array('uid'=>$this->session->id));
		/*----------------------------------------------------------*/
		$data['header'] = $this->load->view('php/Header.php',$data); 
		$data['sidebar'] = $this->load->view('php/Sidebar.php',$data); 
		$data['content'] = $this->load->view('php/Sale_add.php',$data); 
		$data['footer'] = $this->load->view('php/Footer.php',$data); 
		/*---------------------------------------------------------*/
		$this->load->view('index',$data); 
	}
/****************************************************************************
*SALE OPTIONS...
*/
//SALE > INVOICE LIST FUNCTION...
		public function SaleList(){
		$data = array();
		$table = 'tb_sim';
		$data['Totalsim'] = $this->Apps_model->CountAll('tb_sim'); //NUMBER OF INVOICE.. 
		
		$data['Totalsale'] = $this->Apps_model->CountAll('tb_sale'); //NUMBER OF INVOICE..  

		$data['TotalGp'] = $this->Apps_model->gdContALl('tb_sim'); //NUMBER OF Gp.. 
		$data['TotalBl'] = $this->Apps_model->blContALl('tb_sim'); //NUMBER OF Bl.. 
		$data['TotalRobi'] = $this->Apps_model->robiContALl('tb_sim'); //NUMBER OF Robi.. 
		$data['TotalAirtel'] = $this->Apps_model->airtelContALl('tb_sim'); //NUMBER OF Airtel.. 
		$data['TotalTeletalk'] = $this->Apps_model->teletalkContALl('tb_sim'); //NUMBER OF teletalk.. 
		/*----------------------------------------------------------*/		
		$optTable = 'tb_options'; 
		$optData = array(
			'match_col' => 'options_id',
			'match_by' => 1
		); 	 
		$data['optionsData'] = $this->Apps_model->Get_data_by_id_model($optTable,$optData);
		/*----------------------------------------------------------*/
		$table = 'tb_sale';
		$data['saleDataList'] = $this->Apps_model->Get_data_model($table,$data);
		/*----------------------------------------------------------*/
		$data['pData'] = $this->User_model->GetUserById(array('uid'=>$this->session->id));
		/*----------------------------------------------------------*/
		$data['header'] = $this->load->view('php/Header.php',$data); 
		$data['sidebar'] = $this->load->view('php/Sidebar.php',$data); 
		$data['content'] = $this->load->view('php/Sale_list.php',$data); 
		$data['footer'] = $this->load->view('php/Footer.php',$data); 
		/*---------------------------------------------------------*/
		$this->load->view('index',$data); 
	}	
/****************************************************************************
//SALE > REPORT FUNCTION...
*/
	public function ReportStock(){
		$data = array();
		$table = 'tb_sim';
		$data['Totalsale'] = $this->Apps_model->CountAll('tb_sale'); //NUMBER OF INVOICE.. 
		$data['Totalsim'] = $this->Apps_model->CountAll('tb_sim'); //NUMBER OF INVOICE.. 
		/*----------------------------------------------------------*/		
		$optTable = 'tb_options'; 
		$optData = array( 'match_col' => 'options_id', 'match_by' => 1 ); 	 
		$data['optionsData'] = $this->Apps_model->Get_data_by_id_model($optTable,$optData);
		/*----------------------------------------------------------*/		
		$data['fromdate'] = $this->input->post('fromdate'); 
		$data['todate'] = $this->input->post('todate'); 
		$data['type'] = 'tb_stock'; 				
		$table = 'tb_stock';
		$data['ReportDataList'] = $this->Apps_model->Get_data_by_search_key_model($table,$data);
		/*----------------------------------------------------------*/
		$data['pData'] = $this->User_model->GetUserById(array('uid'=>$this->session->id));
		/*----------------------------------------------------------*/
		$data['header'] = $this->load->view('php/Header.php',$data); 
		$data['sidebar'] = $this->load->view('php/Sidebar.php',$data); 
		$data['content'] = $this->load->view('php/ReportStock.php',$data); 
		$data['footer'] = $this->load->view('php/Footer.php',$data); 
		/*---------------------------------------------------------*/
		$this->load->view('index',$data); 
	}
/****************************************************************************
*ACTIVITY / LOG UI/UX METHOD... 
*/
	public function ActivityLog(){
		$data = array();
		$table = 'tb_sim';
		$data['productDataList'] = $this->Apps_model->Get_data_model($table,$data);
		$data['Totalsim'] = $this->Apps_model->CountAll('tb_sim'); //NUMBER OF INVOICE.. 
		/*----------------------------------------------------------*/		
		$optTable = 'tb_options'; 
		$optData = array(
			'match_col' => 'options_id',
			'match_by' => 1
		); 	
		$data['optionsData'] = $this->Apps_model->Get_data_by_id_model($optTable,$optData);
		/*----------------------------------------------------------*/
		$table = 'tb_activity';
		$data['ActivityData'] = $this->Apps_model->Get_data_model($table,$data);
		/*----------------------------------------------------------*/
		$data['pData'] = $this->User_model->GetUserById(array('uid'=>$this->session->id));
		/*----------------------------------------------------------*/
		$data['header'] = $this->load->view('php/Header.php',$data);
		$data['sidebar'] = $this->load->view('php/Sidebar.php',$data);
		$data['content'] = $this->load->view('php/Activity_report',$data);
		$data['footer'] = $this->load->view('php/Footer.php',$data);
		/*----------------------------------------------------------*/
		$this->load->view('index',$data);
	}
/*Report option*/

/****************************************************************************
//SALE > REPORT FUNCTION...
*/
	public function ReportSales(){
		$data = array(); 
		$table = 'tb_sim';

		$data['Totalsim'] = $this->Apps_model->CountAll('tb_sim'); //NUMBER OF INVOICE.. 
		
		$data['Totalsale'] = $this->Apps_model->CountAll('tb_sale'); //NUMBER OF INVOICE..  

		$data['TotalGp'] = $this->Apps_model->gdContALl('tb_sim'); //NUMBER OF Gp.. 
		$data['TotalBl'] = $this->Apps_model->blContALl('tb_sim'); //NUMBER OF Bl.. 
		$data['TotalRobi'] = $this->Apps_model->robiContALl('tb_sim'); //NUMBER OF Robi.. 
		$data['TotalAirtel'] = $this->Apps_model->airtelContALl('tb_sim'); //NUMBER OF Airtel.. 
		$data['TotalTeletalk'] = $this->Apps_model->teletalkContALl('tb_sim'); //NUMBER OF teletalk.. 
		/*----------------------------------------------------------*/		
		$optTable = 'tb_options'; 
		$optData = array( 'match_col' => 'options_id', 'match_by' => 1 ); 	 
		$data['optionsData'] = $this->Apps_model->Get_data_by_id_model($optTable,$optData);
		/*----------------------------------------------------------*/		
		$data['fromdate'] = $this->input->post('fromdate'); 
		$data['todate'] = $this->input->post('todate'); 				
		
		$data['type'] = 'gp'; 
		$table = 'tb_sale';			
		$data['saleDataList'] = $this->Apps_model->Get_data_by_search_key_model($table,$data);
		
		/*----------------------------------------------------------*/
		$data['pData'] = $this->User_model->GetUserById(array('uid'=>$this->session->id));
		/*----------------------------------------------------------*/
		$data['header'] = $this->load->view('php/Header.php',$data); 
		$data['sidebar'] = $this->load->view('php/Sidebar.php',$data); 
		$data['content'] = $this->load->view('php/ReportSales.php',$data); 
		$data['footer'] = $this->load->view('php/Footer.php',$data); 
		/*---------------------------------------------------------*/
		$this->load->view('index',$data); 
	}
	
	public function ReportSalesGp(){
		$data = array(); 

		$data['Totalsim'] = $this->Apps_model->CountAll('tb_sim'); //NUMBER OF INVOICE.. 
		
		$data['Totalsale'] = $this->Apps_model->CountAll('tb_sale'); //NUMBER OF INVOICE..  

		$data['TotalGp'] = $this->Apps_model->gdContALl('tb_sim'); //NUMBER OF Gp.. 
		$data['TotalBl'] = $this->Apps_model->blContALl('tb_sim'); //NUMBER OF Bl.. 
		$data['TotalRobi'] = $this->Apps_model->robiContALl('tb_sim'); //NUMBER OF Robi.. 
		$data['TotalAirtel'] = $this->Apps_model->airtelContALl('tb_sim'); //NUMBER OF Airtel.. 
		$data['TotalTeletalk'] = $this->Apps_model->teletalkContALl('tb_sim'); //NUMBER OF teletalk.. 
		/*----------------------------------------------------------*/		
		$optTable = 'tb_options'; 
		$optData = array( 'match_col' => 'options_id', 'match_by' => 1 ); 	 
		$data['optionsData'] = $this->Apps_model->Get_data_by_id_model($optTable,$optData);
		/*----------------------------------------------------------*/		
		$data['fromdate'] = $this->input->post('fromdate'); 
		$data['todate'] = $this->input->post('todate'); 				
		
		$data['type'] = 'gp'; 
		$table = 'tb_sale';			
		$data['saleDataList'] = $this->Apps_model->Get_data_by_search_key_model($table,$data);
		
		/*----------------------------------------------------------*/
		$data['pData'] = $this->User_model->GetUserById(array('uid'=>$this->session->id));
		/*----------------------------------------------------------*/
		$data['header'] = $this->load->view('php/Header.php',$data); 
		$data['sidebar'] = $this->load->view('php/Sidebar.php',$data); 
		$data['content'] = $this->load->view('php/ReportSalesGp.php',$data); 
		$data['footer'] = $this->load->view('php/Footer.php',$data); 
		/*---------------------------------------------------------*/
		$this->load->view('index',$data); 
	}
	
	public function ReportSalesBl(){
		$data = array(); 

		$data['Totalsim'] = $this->Apps_model->CountAll('tb_sim'); //NUMBER OF INVOICE.. 
		
		$data['Totalsale'] = $this->Apps_model->CountAll('tb_sale'); //NUMBER OF INVOICE..  

		$data['TotalGp'] = $this->Apps_model->gdContALl('tb_sim'); //NUMBER OF Gp.. 
		$data['TotalBl'] = $this->Apps_model->blContALl('tb_sim'); //NUMBER OF Bl.. 
		$data['TotalRobi'] = $this->Apps_model->robiContALl('tb_sim'); //NUMBER OF Robi.. 
		$data['TotalAirtel'] = $this->Apps_model->airtelContALl('tb_sim'); //NUMBER OF Airtel.. 
		$data['TotalTeletalk'] = $this->Apps_model->teletalkContALl('tb_sim'); //NUMBER OF teletalk.. 
		/*----------------------------------------------------------*/		
		$optTable = 'tb_options'; 
		$optData = array( 'match_col' => 'options_id', 'match_by' => 1 ); 	 
		$data['optionsData'] = $this->Apps_model->Get_data_by_id_model($optTable,$optData);
		/*----------------------------------------------------------*/		
		$data['fromdate'] = $this->input->post('fromdate'); 
		$data['todate'] = $this->input->post('todate'); 				
		
		$data['type'] = 'gp'; 
		$table = 'tb_sale';			
		$data['saleDataList'] = $this->Apps_model->Get_data_by_search_key_model($table,$data);
		
		/*----------------------------------------------------------*/
		$data['pData'] = $this->User_model->GetUserById(array('uid'=>$this->session->id));
		/*----------------------------------------------------------*/
		$data['header'] = $this->load->view('php/Header.php',$data); 
		$data['sidebar'] = $this->load->view('php/Sidebar.php',$data); 
		$data['content'] = $this->load->view('php/ReportSalesBl.php',$data); 
		$data['footer'] = $this->load->view('php/Footer.php',$data); 
		/*---------------------------------------------------------*/
		$this->load->view('index',$data); 
	}
	
	public function ReportSalesAirtel(){
		$data = array(); 
		$data['Totalsim'] = $this->Apps_model->CountAll('tb_sim'); //NUMBER OF INVOICE.. 
		
		$data['Totalsale'] = $this->Apps_model->CountAll('tb_sale'); //NUMBER OF INVOICE..  

		$data['TotalGp'] = $this->Apps_model->gdContALl('tb_sim'); //NUMBER OF Gp.. 
		$data['TotalBl'] = $this->Apps_model->blContALl('tb_sim'); //NUMBER OF Bl.. 
		$data['TotalRobi'] = $this->Apps_model->robiContALl('tb_sim'); //NUMBER OF Robi.. 
		$data['TotalAirtel'] = $this->Apps_model->airtelContALl('tb_sim'); //NUMBER OF Airtel.. 
		$data['TotalTeletalk'] = $this->Apps_model->teletalkContALl('tb_sim'); //NUMBER OF teletalk.. 
		/*----------------------------------------------------------*/		
		$optTable = 'tb_options'; 
		$optData = array( 'match_col' => 'options_id', 'match_by' => 1 ); 	 
		$data['optionsData'] = $this->Apps_model->Get_data_by_id_model($optTable,$optData);
		/*----------------------------------------------------------*/		
		$data['fromdate'] = $this->input->post('fromdate'); 
		$data['todate'] = $this->input->post('todate'); 				
		
		$data['type'] = 'gp'; 
		$table = 'tb_sale';			
		$data['saleDataList'] = $this->Apps_model->Get_data_by_search_key_model($table,$data);
		
		/*----------------------------------------------------------*/
		$data['pData'] = $this->User_model->GetUserById(array('uid'=>$this->session->id));
		/*----------------------------------------------------------*/
		$data['header'] = $this->load->view('php/Header.php',$data); 
		$data['sidebar'] = $this->load->view('php/Sidebar.php',$data); 
		$data['content'] = $this->load->view('php/ReportSalesAirtel.php',$data); 
		$data['footer'] = $this->load->view('php/Footer.php',$data); 
		/*---------------------------------------------------------*/
		$this->load->view('index',$data); 
	}
	
	public function ReportSalesRobi(){
		$data = array(); 

		$data['Totalsim'] = $this->Apps_model->CountAll('tb_sim'); //NUMBER OF INVOICE.. 
		
		$data['Totalsale'] = $this->Apps_model->CountAll('tb_sale'); //NUMBER OF INVOICE..  

		$data['TotalGp'] = $this->Apps_model->gdContALl('tb_sim'); //NUMBER OF Gp.. 
		$data['TotalBl'] = $this->Apps_model->blContALl('tb_sim'); //NUMBER OF Bl.. 
		$data['TotalRobi'] = $this->Apps_model->robiContALl('tb_sim'); //NUMBER OF Robi.. 
		$data['TotalAirtel'] = $this->Apps_model->airtelContALl('tb_sim'); //NUMBER OF Airtel.. 
		$data['TotalTeletalk'] = $this->Apps_model->teletalkContALl('tb_sim'); //NUMBER OF teletalk.. 
		/*----------------------------------------------------------*/		
		$optTable = 'tb_options'; 
		$optData = array( 'match_col' => 'options_id', 'match_by' => 1 ); 	 
		$data['optionsData'] = $this->Apps_model->Get_data_by_id_model($optTable,$optData);
		/*----------------------------------------------------------*/		
		$data['fromdate'] = $this->input->post('fromdate'); 
		$data['todate'] = $this->input->post('todate'); 				
		
		$data['type'] = 'gp'; 
		$table = 'tb_sale';			
		$data['saleDataList'] = $this->Apps_model->Get_data_by_search_key_model($table,$data);
		
		/*----------------------------------------------------------*/
		$data['pData'] = $this->User_model->GetUserById(array('uid'=>$this->session->id));
		/*----------------------------------------------------------*/
		$data['header'] = $this->load->view('php/Header.php',$data); 
		$data['sidebar'] = $this->load->view('php/Sidebar.php',$data); 
		$data['content'] = $this->load->view('php/ReportSalesRobi.php',$data); 
		$data['footer'] = $this->load->view('php/Footer.php',$data); 
		/*---------------------------------------------------------*/
		$this->load->view('index',$data); 
	}
	
	public function ReportSalesTeletalk(){
		$data = array(); 

		$data['Totalsim'] = $this->Apps_model->CountAll('tb_sim'); //NUMBER OF INVOICE.. 
		
		$data['Totalsale'] = $this->Apps_model->CountAll('tb_sale'); //NUMBER OF INVOICE..  

		$data['TotalGp'] = $this->Apps_model->gdContALl('tb_sim'); //NUMBER OF Gp.. 
		$data['TotalBl'] = $this->Apps_model->blContALl('tb_sim'); //NUMBER OF Bl.. 
		$data['TotalRobi'] = $this->Apps_model->robiContALl('tb_sim'); //NUMBER OF Robi.. 
		$data['TotalAirtel'] = $this->Apps_model->airtelContALl('tb_sim'); //NUMBER OF Airtel.. 
		$data['TotalTeletalk'] = $this->Apps_model->teletalkContALl('tb_sim'); //NUMBER OF teletalk.. 
		/*----------------------------------------------------------*/		
		$optTable = 'tb_options'; 
		$optData = array( 'match_col' => 'options_id', 'match_by' => 1 ); 	 
		$data['optionsData'] = $this->Apps_model->Get_data_by_id_model($optTable,$optData);
		/*----------------------------------------------------------*/		
		$data['fromdate'] = $this->input->post('fromdate'); 
		$data['todate'] = $this->input->post('todate'); 				
		
		$data['type'] = 'gp'; 
		$table = 'tb_sale';			
		$data['saleDataList'] = $this->Apps_model->Get_data_by_search_key_model($table,$data);
		
		/*----------------------------------------------------------*/
		$data['pData'] = $this->User_model->GetUserById(array('uid'=>$this->session->id));
		/*----------------------------------------------------------*/
		$data['header'] = $this->load->view('php/Header.php',$data); 
		$data['sidebar'] = $this->load->view('php/Sidebar.php',$data); 
		$data['content'] = $this->load->view('php/ReportSalesTeletalk.php',$data); 
		$data['footer'] = $this->load->view('php/Footer.php',$data); 
		/*---------------------------------------------------------*/
		$this->load->view('index',$data); 
	}

	/*report sale end*/
	public function ReportSalesPrint(){
		$data = array(); 

		$data['Totalsim'] = $this->Apps_model->CountAll('tb_sim'); //NUMBER OF INVOICE.. 
		
		$data['Totalsale'] = $this->Apps_model->CountAll('tb_sale'); //NUMBER OF INVOICE..  

		$data['TotalGp'] = $this->Apps_model->gdContALl('tb_sim'); //NUMBER OF Gp.. 
		$data['TotalBl'] = $this->Apps_model->blContALl('tb_sim'); //NUMBER OF Bl.. 
		$data['TotalRobi'] = $this->Apps_model->robiContALl('tb_sim'); //NUMBER OF Robi.. 
		$data['TotalAirtel'] = $this->Apps_model->airtelContALl('tb_sim'); //NUMBER OF Airtel.. 
		$data['TotalTeletalk'] = $this->Apps_model->teletalkContALl('tb_sim'); //NUMBER OF teletalk.. 
		/*----------------------------------------------------------*/		
		$optTable = 'tb_options'; 
		$optData = array( 'match_col' => 'options_id', 'match_by' => 1 ); 	 
		$data['optionsData'] = $this->Apps_model->Get_data_by_id_model($optTable,$optData);
		/*----------------------------------------------------------*/	
		$data['fromdate'] = $this->input->post('fromdate'); 
		$data['todate'] = $this->input->post('todate'); 		
		
		$data['type'] = 'gp'; 
		$table = 'tb_sale';			
		$data['saleDataList'] = $this->Apps_model->Get_data_by_search_key_model($table,$data);
		
		/*----------------------------------------------------------*/
		$data['pData'] = $this->User_model->GetUserById(array('uid'=>$this->session->id));
		/*----------------------------------------------------------*/
		$this->load->view('php/ReportSalesPdf.php',$data); 
	}
	public function ReportSalesPrintGp(){
		$data = array(); 

		$data['Totalsim'] = $this->Apps_model->CountAll('tb_sim'); //NUMBER OF INVOICE.. 
		
		$data['Totalsale'] = $this->Apps_model->CountAll('tb_sale'); //NUMBER OF INVOICE..  

		$data['TotalGp'] = $this->Apps_model->gdContALl('tb_sim'); //NUMBER OF Gp.. 
		$data['TotalBl'] = $this->Apps_model->blContALl('tb_sim'); //NUMBER OF Bl.. 
		$data['TotalRobi'] = $this->Apps_model->robiContALl('tb_sim'); //NUMBER OF Robi.. 
		$data['TotalAirtel'] = $this->Apps_model->airtelContALl('tb_sim'); //NUMBER OF Airtel.. 
		$data['TotalTeletalk'] = $this->Apps_model->teletalkContALl('tb_sim'); //NUMBER OF teletalk.. 
		/*----------------------------------------------------------*/		
		$optTable = 'tb_options'; 
		$optData = array( 'match_col' => 'options_id', 'match_by' => 1 ); 	 
		$data['optionsData'] = $this->Apps_model->Get_data_by_id_model($optTable,$optData);
		/*----------------------------------------------------------*/	
		$data['fromdate'] = $this->input->post('fromdate'); 
		$data['todate'] = $this->input->post('todate'); 		
		
		$data['type'] = 'gp'; 
		$table = 'tb_sale';			
		$data['saleDataList'] = $this->Apps_model->Get_data_by_search_key_Gp_model($table,$data);
		
		/*----------------------------------------------------------*/
		$data['pData'] = $this->User_model->GetUserById(array('uid'=>$this->session->id));
		/*----------------------------------------------------------*/
		$this->load->view('php/ReportSalesPdfGp.php',$data); 
	}
	public function ReportSalesPrintBl(){
		$data = array(); 

		$data['Totalsim'] = $this->Apps_model->CountAll('tb_sim'); //NUMBER OF INVOICE.. 
		
		$data['Totalsale'] = $this->Apps_model->CountAll('tb_sale'); //NUMBER OF INVOICE..  

		$data['TotalGp'] = $this->Apps_model->gdContALl('tb_sim'); //NUMBER OF Gp.. 
		$data['TotalBl'] = $this->Apps_model->blContALl('tb_sim'); //NUMBER OF Bl.. 
		$data['TotalRobi'] = $this->Apps_model->robiContALl('tb_sim'); //NUMBER OF Robi.. 
		$data['TotalAirtel'] = $this->Apps_model->airtelContALl('tb_sim'); //NUMBER OF Airtel.. 
		$data['TotalTeletalk'] = $this->Apps_model->teletalkContALl('tb_sim'); //NUMBER OF teletalk.. 
		/*----------------------------------------------------------*/		
		$optTable = 'tb_options'; 
		$optData = array( 'match_col' => 'options_id', 'match_by' => 1 ); 	 
		$data['optionsData'] = $this->Apps_model->Get_data_by_id_model($optTable,$optData);
		/*----------------------------------------------------------*/	
		$data['fromdate'] = $this->input->post('fromdate'); 
		$data['todate'] = $this->input->post('todate'); 		
		
		$data['type'] = 'gp'; 
		$table = 'tb_sale';			
		$data['saleDataList'] = $this->Apps_model->Get_data_by_search_key_Bl_model($table,$data);
		
		/*----------------------------------------------------------*/
		$data['pData'] = $this->User_model->GetUserById(array('uid'=>$this->session->id));
		/*----------------------------------------------------------*/
		$this->load->view('php/ReportSalesPdfBl.php',$data); 
	}
	public function ReportSalesPrintAirtel(){
		$data = array(); 

		$data['Totalsim'] = $this->Apps_model->CountAll('tb_sim'); //NUMBER OF INVOICE.. 
		
		$data['Totalsale'] = $this->Apps_model->CountAll('tb_sale'); //NUMBER OF INVOICE..  

		$data['TotalGp'] = $this->Apps_model->gdContALl('tb_sim'); //NUMBER OF Gp.. 
		$data['TotalBl'] = $this->Apps_model->blContALl('tb_sim'); //NUMBER OF Bl.. 
		$data['TotalRobi'] = $this->Apps_model->robiContALl('tb_sim'); //NUMBER OF Robi.. 
		$data['TotalAirtel'] = $this->Apps_model->airtelContALl('tb_sim'); //NUMBER OF Airtel.. 
		$data['TotalTeletalk'] = $this->Apps_model->teletalkContALl('tb_sim'); //NUMBER OF teletalk.. 
		/*----------------------------------------------------------*/		
		$optTable = 'tb_options'; 
		$optData = array( 'match_col' => 'options_id', 'match_by' => 1 ); 	 
		$data['optionsData'] = $this->Apps_model->Get_data_by_id_model($optTable,$optData);
		/*----------------------------------------------------------*/	
		$data['fromdate'] = $this->input->post('fromdate'); 
		$data['todate'] = $this->input->post('todate'); 		
		
		$data['type'] = 'gp'; 
		$table = 'tb_sale';			
		$data['saleDataList'] = $this->Apps_model->Get_data_by_search_key_Airtel_model($table,$data);
		
		/*----------------------------------------------------------*/
		$data['pData'] = $this->User_model->GetUserById(array('uid'=>$this->session->id));
		/*----------------------------------------------------------*/
		$this->load->view('php/ReportSalesPdfAirtel.php',$data); 
	}
	public function ReportSalesPrintRobi(){
		$data = array(); 

		$data['Totalsim'] = $this->Apps_model->CountAll('tb_sim'); //NUMBER OF INVOICE.. 
		
		$data['Totalsale'] = $this->Apps_model->CountAll('tb_sale'); //NUMBER OF INVOICE..  

		$data['TotalGp'] = $this->Apps_model->gdContALl('tb_sim'); //NUMBER OF Gp.. 
		$data['TotalBl'] = $this->Apps_model->blContALl('tb_sim'); //NUMBER OF Bl.. 
		$data['TotalRobi'] = $this->Apps_model->robiContALl('tb_sim'); //NUMBER OF Robi.. 
		$data['TotalAirtel'] = $this->Apps_model->airtelContALl('tb_sim'); //NUMBER OF Airtel.. 
		$data['TotalTeletalk'] = $this->Apps_model->teletalkContALl('tb_sim'); //NUMBER OF teletalk.. 
		/*----------------------------------------------------------*/		
		$optTable = 'tb_options'; 
		$optData = array( 'match_col' => 'options_id', 'match_by' => 1 ); 	 
		$data['optionsData'] = $this->Apps_model->Get_data_by_id_model($optTable,$optData);
		/*----------------------------------------------------------*/	
		$data['fromdate'] = $this->input->post('fromdate'); 
		$data['todate'] = $this->input->post('todate'); 		
		
		$data['type'] = 'gp'; 
		$table = 'tb_sale';			
		$data['saleDataList'] = $this->Apps_model->Get_data_by_search_key_Robi_model($table,$data);
		
		/*----------------------------------------------------------*/
		$data['pData'] = $this->User_model->GetUserById(array('uid'=>$this->session->id));
		/*----------------------------------------------------------*/
		$this->load->view('php/ReportSalesPdfRobi.php',$data); 
	}
	public function ReportSalesPrintTeletalk(){
		$data = array(); 

		$data['Totalsim'] = $this->Apps_model->CountAll('tb_sim'); //NUMBER OF INVOICE.. 
		
		$data['Totalsale'] = $this->Apps_model->CountAll('tb_sale'); //NUMBER OF INVOICE..  

		$data['TotalGp'] = $this->Apps_model->gdContALl('tb_sim'); //NUMBER OF Gp.. 
		$data['TotalBl'] = $this->Apps_model->blContALl('tb_sim'); //NUMBER OF Bl.. 
		$data['TotalRobi'] = $this->Apps_model->robiContALl('tb_sim'); //NUMBER OF Robi.. 
		$data['TotalAirtel'] = $this->Apps_model->airtelContALl('tb_sim'); //NUMBER OF Airtel.. 
		$data['TotalTeletalk'] = $this->Apps_model->teletalkContALl('tb_sim'); //NUMBER OF teletalk.. 
		/*----------------------------------------------------------*/		
		$optTable = 'tb_options'; 
		$optData = array( 'match_col' => 'options_id', 'match_by' => 1 ); 	 
		$data['optionsData'] = $this->Apps_model->Get_data_by_id_model($optTable,$optData);
		/*----------------------------------------------------------*/	
		$data['fromdate'] = $this->input->post('fromdate'); 
		$data['todate'] = $this->input->post('todate'); 		
		
		$data['type'] = 'gp'; 
		$table = 'tb_sale';			
		$data['saleDataList'] = $this->Apps_model->Get_data_by_search_key_Teletalk_model($table,$data);
		
		/*----------------------------------------------------------*/
		$data['pData'] = $this->User_model->GetUserById(array('uid'=>$this->session->id));
		/*----------------------------------------------------------*/
		$this->load->view('php/ReportSalesPdfTeletalk.php',$data); 
	}

/*stock pdf list*/	
	public function ReportStockPrintAritel(){
		$data = array(); 

		$data['Totalsim'] = $this->Apps_model->CountAll('tb_sim'); //NUMBER OF INVOICE.. 
		
		$data['Totalsale'] = $this->Apps_model->CountAll('tb_sale'); //NUMBER OF INVOICE..  

		$data['TotalGp'] = $this->Apps_model->gdContALl('tb_sim'); //NUMBER OF Gp.. 
		$data['TotalBl'] = $this->Apps_model->blContALl('tb_sim'); //NUMBER OF Bl.. 
		$data['TotalRobi'] = $this->Apps_model->robiContALl('tb_sim'); //NUMBER OF Robi.. 
		$data['TotalAirtel'] = $this->Apps_model->airtelContALl('tb_sim'); //NUMBER OF Airtel.. 
		$data['TotalTeletalk'] = $this->Apps_model->teletalkContALl('tb_sim'); //NUMBER OF teletalk.. 
		/*----------------------------------------------------------*/		
		$optTable = 'tb_options'; 
		$optData = array( 'match_col' => 'options_id', 'match_by' => 1 ); 	 
		$data['optionsData'] = $this->Apps_model->Get_data_by_id_model($optTable,$optData);
		
		$table = 'tb_sim';			
		$data['simDataList'] = $this->Apps_model->Get_data_stock_search_key_aritel_model($table,$data);
		
		/*----------------------------------------------------------*/
		$data['pData'] = $this->User_model->GetUserById(array('uid'=>$this->session->id));
		/*----------------------------------------------------------*/
		$this->load->view('php/ReportStockPdfAirtel.php',$data); 
	}
	public function ReportStockPrintBl(){
		$data = array(); 

		$data['Totalsim'] = $this->Apps_model->CountAll('tb_sim'); //NUMBER OF INVOICE.. 
		
		$data['Totalsale'] = $this->Apps_model->CountAll('tb_sale'); //NUMBER OF INVOICE..  

		$data['TotalGp'] = $this->Apps_model->gdContALl('tb_sim'); //NUMBER OF Gp.. 
		$data['TotalBl'] = $this->Apps_model->blContALl('tb_sim'); //NUMBER OF Bl.. 
		$data['TotalRobi'] = $this->Apps_model->robiContALl('tb_sim'); //NUMBER OF Robi.. 
		$data['TotalAirtel'] = $this->Apps_model->airtelContALl('tb_sim'); //NUMBER OF Airtel.. 
		$data['TotalTeletalk'] = $this->Apps_model->teletalkContALl('tb_sim'); //NUMBER OF teletalk.. 
		/*----------------------------------------------------------*/		
		$optTable = 'tb_options'; 
		$optData = array( 'match_col' => 'options_id', 'match_by' => 1 ); 	 
		$data['optionsData'] = $this->Apps_model->Get_data_by_id_model($optTable,$optData);
		/*----------------------------------------------------------*/	
	
		$table = 'tb_sim';			
		$data['simDataList'] = $this->Apps_model->Get_data_stock_search_key_Bl_model($table,$data);
		
		/*----------------------------------------------------------*/
		$data['pData'] = $this->User_model->GetUserById(array('uid'=>$this->session->id));
		/*----------------------------------------------------------*/
		$this->load->view('php/ReportStockPdfBl.php',$data); 
	}
	public function ReportStockPrintGp(){
		$data = array(); 

		$data['Totalsim'] = $this->Apps_model->CountAll('tb_sim'); //NUMBER OF INVOICE.. 
		
		$data['Totalsale'] = $this->Apps_model->CountAll('tb_sale'); //NUMBER OF INVOICE..  

		$data['TotalGp'] = $this->Apps_model->gdContALl('tb_sim'); //NUMBER OF Gp.. 
		$data['TotalBl'] = $this->Apps_model->blContALl('tb_sim'); //NUMBER OF Bl.. 
		$data['TotalRobi'] = $this->Apps_model->robiContALl('tb_sim'); //NUMBER OF Robi.. 
		$data['TotalAirtel'] = $this->Apps_model->airtelContALl('tb_sim'); //NUMBER OF Airtel.. 
		$data['TotalTeletalk'] = $this->Apps_model->teletalkContALl('tb_sim'); //NUMBER OF teletalk.. 
		/*----------------------------------------------------------*/		
		$optTable = 'tb_options'; 
		$optData = array( 'match_col' => 'options_id', 'match_by' => 1 ); 	 
		$data['optionsData'] = $this->Apps_model->Get_data_by_id_model($optTable,$optData);
		/*----------------------------------------------------------*/	

		$table = 'tb_sim';			
		$data['simDataList'] = $this->Apps_model->Get_data_stock_search_key_Gp_model($table,$data);
		
		/*----------------------------------------------------------*/
		$data['pData'] = $this->User_model->GetUserById(array('uid'=>$this->session->id));
		/*----------------------------------------------------------*/
		$this->load->view('php/ReportStockPdfGp.php',$data); 
	}
	public function ReportStockPrintRobi(){
		$data = array();

		$data['Totalsim'] = $this->Apps_model->CountAll('tb_sim'); //NUMBER OF INVOICE.. 
		
		$data['Totalsale'] = $this->Apps_model->CountAll('tb_sale'); //NUMBER OF INVOICE..  

		$data['TotalGp'] = $this->Apps_model->gdContALl('tb_sim'); //NUMBER OF Gp.. 
		$data['TotalBl'] = $this->Apps_model->blContALl('tb_sim'); //NUMBER OF Bl.. 
		$data['TotalRobi'] = $this->Apps_model->robiContALl('tb_sim'); //NUMBER OF Robi.. 
		$data['TotalAirtel'] = $this->Apps_model->airtelContALl('tb_sim'); //NUMBER OF Airtel.. 
		$data['TotalTeletalk'] = $this->Apps_model->teletalkContALl('tb_sim'); //NUMBER OF teletalk.. 
		/*----------------------------------------------------------*/		
		$optTable = 'tb_options'; 
		$optData = array( 'match_col' => 'options_id', 'match_by' => 1 ); 	 
		$data['optionsData'] = $this->Apps_model->Get_data_by_id_model($optTable,$optData);
		/*----------------------------------------------------------*/	
		$table = 'tb_sim';			
		$data['simDataList'] = $this->Apps_model->Get_data_stock_search_key_Robi_model($table,$data);
		
		/*----------------------------------------------------------*/
		$data['pData'] = $this->User_model->GetUserById(array('uid'=>$this->session->id));
		/*----------------------------------------------------------*/
		$this->load->view('php/ReportStockPdfRobi.php',$data); 
	}
	public function ReportStockPrintTeletalk(){
		$data = array(); 

		$data['Totalsim'] = $this->Apps_model->CountAll('tb_sim'); //NUMBER OF INVOICE.. 
		
		$data['Totalsale'] = $this->Apps_model->CountAll('tb_sale'); //NUMBER OF INVOICE..  

		$data['TotalGp'] = $this->Apps_model->gdContALl('tb_sim'); //NUMBER OF Gp.. 
		$data['TotalBl'] = $this->Apps_model->blContALl('tb_sim'); //NUMBER OF Bl.. 
		$data['TotalRobi'] = $this->Apps_model->robiContALl('tb_sim'); //NUMBER OF Robi.. 
		$data['TotalAirtel'] = $this->Apps_model->airtelContALl('tb_sim'); //NUMBER OF Airtel.. 
		$data['TotalTeletalk'] = $this->Apps_model->teletalkContALl('tb_sim'); //NUMBER OF teletalk.. 
		/*----------------------------------------------------------*/		
		$optTable = 'tb_options'; 
		$optData = array( 'match_col' => 'options_id', 'match_by' => 1 ); 	 
		$data['optionsData'] = $this->Apps_model->Get_data_by_id_model($optTable,$optData);
		/*----------------------------------------------------------*/	
		
		$table = 'tb_sim';			
		$data['simDataList'] = $this->Apps_model->Get_data_stock_search_key_Teletalk_model($table,$data);
		
		/*----------------------------------------------------------*/
		$data['pData'] = $this->User_model->GetUserById(array('uid'=>$this->session->id));
		/*----------------------------------------------------------*/
		$this->load->view('php/ReportStockPdfTeletalk.php',$data); 
	}
	/*end report print*/
}
