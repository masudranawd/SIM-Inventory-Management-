<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class User extends CI_Controller {

	public function __construct(){
		parent::__construct(); 
/*-----------------------------------------------------*/
		$this->load->model('User_model');
		$this->load->model('Apps_model'); 
/*-----------------------------------------------------*/
		 
	} 

	public function index()
	{
		if(isset($this->session->user_id)){ redirect('Apps/'); 	}else{ $this->Login(); 	}//login check ..
	}	


	public function Login(){
		$data = array();
		$data['active_menu'] = 'logout';  
		/*----------------------------------------------------------*/
		$data['content'] = $this->load->view('Login.php',$data); 
		/*---------------------------------------------------------*/
		$this->load->view('index',$data); 
	}	



	public function Login_From(){
		$data = array(); 
		/*---------------------------------------------------------*/
		$data['user_id'] = $this->input->post('user_id'); 
		$data['password'] = $this->input->post('password'); 
		/*---------------------------------------------------------*/

		$user_id = $data['user_id']; 
		$password = $data['password'];

		if(empty($user_id) OR empty($password)){
			$sdata = array();
			$sdata['msg'] = '<span style="color:red;">Login Failed !</span>'; 
			$this->session->set_flashdata($sdata);
			redirect('User',$sdata); 
		}else{
			$sdata = array();
			$check = $this->User_model->userLogin($data);
			if($check){
				$this->User_model->User_status_on($check->id); 
				$sdata = array(); 
				$sdata['id'] = $check->id; 
				$sdata['user_id'] = $check->user_id;  
				$sdata['email'] = $check->email; 
				$sdata['firstname'] = $check->firstname; 
				$sdata['lastname'] = $check->lastname; 
				$sdata['types'] = $check->types;
				$sdata['phone'] = $check->phone; 
				$sdata['address'] = $check->address; 
				$sdata['image'] = $check->image; 
				$sdata['userlogin'] = TRUE; 
				$this->session->set_userdata($sdata);//set as session... 
				/**/
				redirect('Apps',$sdata);
			}else{
				$sdata = array();
				$sdata['msg'] = '<span style="color:red;">Invalid !</span>'; 
				$this->session->set_flashdata($sdata);
				redirect('User',$sdata); 
			}
		}
	}//login method end..
//Logout... 
	public function Logout(){
		$id = $this->session->id;
		$this->User_model->User_status_off($id); 
		//$this->session->unset_userdata($user_id);
		//$this->session->unset_userdata($email); 
		//$this->session->unset_userdata($password);
		$this->session->unset_userdata('userlogin',FALSE);

		$this->session->sess_destroy(); 
		redirect('User',$data); 
	}

/****************************************************************************
*Add user /  UI/UX METHOD... 
*/
	public function Adduser(){
		$data = array();
		$optData = array();
		/*----------------------------------------------------------*/		
		$optTable = 'tb_options';
		$optData['match_col'] = 'options_id';
		$optData['match_by']  = 1; 
		$data['optionsData']  = $this->Apps_model->Get_data_by_id_model($optTable,$optData);//OPTION DATA COLLECTING...
		/*----------------------------------------------------------*/
		$userTable = 'tb_user';
		$data['usereData'] = $this->Apps_model->Get_single_limited_data_model($userTable,$data);//INVOICE 
		/*----------------------------------------------------------*/
		$data['pData'] = $this->User_model->GetUserById(array('uid'=>$this->session->id));
		/*----------------------------------------------------------*/
		$data['header']  = $this->load->view('php/Header.php',$data);
		$data['sidebar'] = $this->load->view('php/Sidebar.php',$data);
		$data['content'] = $this->load->view('php/Add_user',$data);
		$data['footer'] = $this->load->view('php/Footer.php',$data);
		/*----------------------------------------------------------*/
		$this->load->view('index',$data);
	}

/****************************************************************************
*All User List/  UI/UX METHOD... 
*/
	public function Alluser(){
		$data = array();
		$optData = array();
		/*----------------------------------------------------------*/		
		$optTable = 'tb_options';
		$optData['match_col'] = 'options_id';
		$optData['match_by']  = 1; 
		$data['optionsData']  = $this->Apps_model->Get_data_by_id_model($optTable,$optData);//OPTION DATA COLLECTING...
		/*----------------------------------------------------------*/
		$userTable = 'tb_user';
		$data['userDataList'] = $this->Apps_model->Get_data_model($userTable,$data);
		/*----------------------------------------------------------*/
		$data['pData'] = $this->User_model->GetUserById(array('uid'=>$this->session->id));
		/*----------------------------------------------------------*/
		$data['header']  = $this->load->view('php/Header.php',$data);
		$data['sidebar'] = $this->load->view('php/Sidebar.php',$data);
		$data['content'] = $this->load->view('php/All_user',$data);
		$data['footer'] = $this->load->view('php/Footer.php',$data);
		/*----------------------------------------------------------*/
		$this->load->view('index',$data);
	}
/*=======================================================================================
| Add New user Method ------
*/

	public function AddNewUser(){
		$sdata=array();
		$data = array();
		$data['user_id'] = $this->input->post('user_id');
		$data['types'] = $this->input->post('types');
		$data['password'] = $this->input->post('password');
		
		/*==================================================================================*/
		
		if(empty($data['user_id']) OR empty($data['types']) OR empty($data['password'])){
			$sdata['msg'] = '<div class="alert alert-danger"><button type="button" class="close" data-dismiss="alert">×</button><strong>Faild To Update !</strong> Please Try Again:)</div>';
		}else{
			$sdata['msg'] = '<div class="alert alert-success"><button type="button" class="close" data-dismiss="alert">×</button><strong>Successfully Added !</strong> :)</div>';

			$data['password'] = md5($data['password']);		
           	$this->User_model->Add_user($data);   
        }

        /*--ACTIVITY STATUS UPDATE----------------------------------*/
		$activityTable = 'tb_activity';
		$activityData = array();
		$activityData['activity_details'] = '<div class="alert alert-success">Success :) Add New User By &mdash; '.$this->session->firstname.' '.$this->session->lastname.' <span style="font-size:12px;">('.$this->session->user_id.')</span> </div>';
		$this->Apps_model->Add_data_model($activityTable,$activityData); //ACTIVITY UPDATED...


        $this->session->set_flashdata($sdata);          
        redirect('User/Adduser/',$sdata);  
     }   

/* ===================================================================================
| User data Delete method 
*/
	public function userRemoveById($id){

		/*--ACTIVITY STATUS UPDATE----------------------------------*/
		$activityTable = 'tb_activity';
		$activityData = array();
		$activityData['activity_details'] = '<div class="alert alert-warning">Success :) User Remove By &mdash; '.$this->session->firstname.' '.$this->session->lastname.' <span style="font-size:12px;">('.$this->session->user_id.')</span> </div>';
		$this->Apps_model->Add_data_model($activityTable,$activityData); //ACTIVITY UPDATED...


		$this->User_model->Remove_user($id);
		redirect('User/Alluser/');  
	}
	public function userRemoveByIdImg($id,$profile){
		unlink('images/user/'.$profile); 
		$this->User_model->Remove_user($id);
		redirect('User/Alluser/');  
	}
/* ===================================================================================
| User data ACTIVE SYSTEM method 
*/
	public function UserpermissionActiveMethod($id){  		
		$table = 'tb_user';
		/*----------------------------------------------------------*/
		$data = array();
		$data['match_col'] = 'id';
		$data['match_by'] = $id; 
		$data['permission'] = 1;
		$this->User_model->Update_premission_model($table,$data);
		redirect('User/Alluser/');  
	}

/* ===================================================================================
| User data INACTIVE SYSTEM method 
*/
	public function UserpermissioninActiveMethod($id){ 
		$table = 'tb_user';
		/*----------------------------------------------------------*/
		$data = array();
		$data['match_col'] = 'id';
		$data['match_by'] = $id; 
		$data['permission'] = 0;
		$this->User_model->Update_premission_model($table,$data);
		redirect('User/Alluser/');  
	}

	public function Profile($id){
		$data = array();
		$optData = array();
		/*----------------------------------------------------------*/		
		$optTable = 'tb_options';
		$optData['match_col'] = 'options_id';
		$optData['match_by']  = 1; 
		$data['optionsData']  = $this->Apps_model->Get_data_by_id_model($optTable,$optData);//OPTION DATA COLLECTING...
		/*----------------------------------------------------------*/
		$data['uid'] = $id; 
		$data['profileData'] = $this->User_model->GetUserById($data); 
		/*----------------------------------------------------------*/
		$data['pData'] = $this->User_model->GetUserById(array('uid'=>$this->session->id));
		/*----------------------------------------------------------*/
		$data['header']  = $this->load->view('php/Header.php',$data);
		$data['sidebar'] = $this->load->view('php/Sidebar.php',$data);
		$data['content'] = $this->load->view('php/Profile.php',$data);
		$data['footer'] = $this->load->view('php/Footer.php',$data);
		/*----------------------------------------------------------*/
		$this->load->view('index',$data);		
	}

	public function Type($types,$id){
		$data = array(); 
		$data['id'] = $id; 
		$types = $types; 
		if($types == 'o'){
			$data['types'] = 'Owner';
		}elseif($types =='m'){
			$data['types'] = 'Manager';
		}elseif($types == 's'){
			$data['types'] = 'Salesman';
		}
		$this->User_model->RoleUpdateById($data); 
		redirect('User/Alluser/'); 
	}

	public function UpdateUser(){
		$img_old = $this->input->post('old_image'); 
		$img_new = $_FILES['image']['name']; 

		$data =array(
			'id' => $this->input->post('id'),
			'firstname' => $this->input->post('firstname'),
			'lastname' => $this->input->post('lastname'),
			'email' => $this->input->post('email'),
			'phone' => $this->input->post('phone'), 
			'address' => $this->input->post('address'),
			
		); 
		if(!empty($img_new)){
			$data['image']  = $data['firstname'].$data['lastname'].'_'.time().'_'.$img_new;
			
			if(!empty($img_old)){ unlink('./images/user/'.$img_old); }

			$config['file_name']        	= $data['image'];
			$config['upload_path']          = './images/user/';
	    	$config['allowed_types']        = 'gif|jpg|png';
			$this->load->library('upload', $config);

	    	if (! $this->upload->do_upload('image')){
	    		$error = array('error' => $this->upload->display_errors());
	    		$this->load->view('upload_form', $error);
	    	}else{	
	    		array('upload_data' => $this->upload->data());
	     	}			
		}

		/*--ACTIVITY STATUS UPDATE----------------------------------*/
		$activityTable = 'tb_activity';
		$activityData = array();
		$activityData['activity_details'] = '<div class="alert alert-warning">Success :) Update User By &mdash; '.$this->session->firstname.' '.$this->session->lastname.' <span style="font-size:12px;">('.$this->session->user_id.')</span> </div>';
		$this->Apps_model->Add_data_model($activityTable,$activityData); //ACTIVITY UPDATED...


		$this->User_model->UserUpdateData($data);
		redirect('User/Profile/'.$data['id']); 
	}

	public function ChangePassword(){


		/*--ACTIVITY STATUS UPDATE----------------------------------*/
		$activityTable = 'tb_activity';
		$activityData = array();
		$activityData['activity_details'] = '<div class="alert alert-warning">Success :) Update Password By &mdash; '.$this->session->firstname.' '.$this->session->lastname.' <span style="font-size:12px;">('.$this->session->user_id.')</span> </div>';
		$this->Apps_model->Add_data_model($activityTable,$activityData); //ACTIVITY UPDATED...

		
		$data = array();
		$data['id'] = $this->input->post('id');
		$data['password'] =md5($this->input->post('password'));

		if(empty($data['id'])){
       		 redirect('User/Alluser/');  
		}else{
		 $this->User_model->ChangeUerPassword($data);        
        	redirect('User/Alluser/'); 
		}
	}


}