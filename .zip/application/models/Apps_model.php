<?php
	class Apps_model extends CI_Model{

/****************************************************************************
*SAVE / DATA METHOD... 
*/	function CheckData($data)  
      {  
           $this->db->where('sim_number', $data['sim_number']);  
           $query = $this->db->get("tb_sim"); 
           if($query->num_rows() > 0)  
           {  
                return true;  
           }  
           else  
           {  
                return false;  
           }  
      }

/*sim add by checking */
		public function insert_data_to_db($data) {
		    return $this->db->insert('tb_sim', $data);
		}

/*add method*/
		public function Add_data_model($table,$data){
			$this->db->insert($table,$data);
		}
		
		public function Add_data_model_recall($table,$data){
			$this->db->insert($table,$data);
			 return $this->db->insert_id();
		}		

/****************************************************************************/		
		public function Get_single_limited_data_model($Table){
			$this->db->select("*");
			$this->db->from($Table);
			$this->db->limit(1);
			$this->db->order_by('id',"DESC");
			$result = $this->db->get();
			$result = $result->row();			
			return $result; 
		}
/****************************************************************************
*COUNT Sim Stock ALL 
*/		
		public function gdContALl($table){
			$this->db->select();
			$this->db->from($table);
			$this->db->where('sim_name','gp');
			$this->db->where('status',0);
			$result = $this->db->get();
			$result = $result->num_rows();
			return $result;
		}

		public function blContALl($table){
			$this->db->select();
			$this->db->from($table);
			$this->db->where('sim_name','bl');
			$this->db->where('status',0);
			$result = $this->db->get();
			$result = $result->num_rows();
			return $result;
		}

		public function robiContALl($table){
			$this->db->select();
			$this->db->from($table);
			$this->db->where('sim_name','robi');
			$this->db->where('status',0);
			$result = $this->db->get();
			$result = $result->num_rows();
			return $result;
		}

		public function airtelContALl($table){
			$this->db->select();
			$this->db->from($table);
			$this->db->where('sim_name','airtel');
			$this->db->where('status',0);
			$result = $this->db->get();
			$result = $result->num_rows();
			return $result;
		}

		public function teletalkContALl($table){
			$this->db->select();
			$this->db->from($table);
			$this->db->where('sim_name','teletalk');
			$this->db->where('status',0);
			$result = $this->db->get();
			$result = $result->num_rows();
			return $result;
		}
	/****************************************************************************
*COUNT ALL 
*/		
		public function CountAll($table){
			$this->db->select(); 
			$this->db->from($table);
			$result = $this->db->get(); 
			$result = $result->num_rows();
			return $result; 
		}


		public function CountAllOnline($table){
			$this->db->select(); 
			$this->db->from($table);
			$this->db->where('status',1); 
			$result = $this->db->get(); 
			$result = $result->num_rows();
			return $result; 
		}
		public function CountAllApprove($table){
			$this->db->select(); 
			$this->db->from($table);
			$this->db->where('permission',0); 
			$result = $this->db->get(); 
			$result = $result->num_rows();
			return $result; 
		}

		public function CountQuantity($table){
			$this->db->count_all_results('quantity');
			$this->db->from($table);
			$result = $this->db->get(); 
			$result = $result->num_rows(); 
			return $result; 
		}


/****************************************************************************
*GET / DATA METHOD... 
*/
		public function Get_data_model($table){
			$this->db->select('*');
			$this->db->from($table);
			
			if($table=='tb_activity'){
				$this->db->order_by('activity_id','DESC');
			}
			if($table=='tb_sim'){
				$this->db->order_by('sim_id','DESC');
			}
			if($table == 'tb_order'){
				$this->db->where('created_by_id',$this->session->id);
			}
			
			$result = $this->db->get();
			$result = $result->result();
			return $result;
		}

		public function Get_data_stock_model($table){
			$this->db->select('*');
			$this->db->from($table);
			$this->db->where('status',0);
			$result = $this->db->get();
			$result = $result->result();
			return $result;
		}		
/****************************************************************************
*GET / DATA METHOD... 
*/
		public function Get_data_by_id_model($table,$data){
			$this->db->select('*');
			$this->db->from($table);
			$this->db->where($data['match_col'],$data['match_by']);
			$result = $this->db->get();
			$result = $result->row();
			return $result;
		}

/****************************************************************************
*SERCH MODEL METHOD..
*/		
		public function Get_data_by_search_key_model($table,$data){
			$this->db->select('*'); 
			$this->db->from($table); 
			
			if(!empty($data['fromdate'])){
				$this->db->where('created_at >=', $data['fromdate']);
				$this->db->where('created_at <=', $data['todate']);
			}			

			$result = $this->db->get();
			$result = $result->result();
			return $result;			
		}
/*report print */
		public function Get_data_by_search_key_Gp_model($table,$data){
			$this->db->select('*'); 
			$this->db->from($table); 
			
			if(!empty($data['fromdate'])){
				$this->db->where('created_at >=', $data['fromdate']);
				$this->db->where('created_at <=', $data['todate']);
			}			
			$this->db->where('sim_name','gp');
			$result = $this->db->get();
			$result = $result->result();
			return $result;			
		}
		public function Get_data_by_search_key_Bl_model($table,$data){
			$this->db->select('*'); 
			$this->db->from($table); 
			
			if(!empty($data['fromdate'])){
				$this->db->where('created_at >=', $data['fromdate']);
				$this->db->where('created_at <=', $data['todate']);
			}			
			$this->db->where('sim_name','bl');
			$result = $this->db->get();
			$result = $result->result();
			return $result;			
		}
		public function Get_data_by_search_key_Airtel_model($table,$data){
			$this->db->select('*'); 
			$this->db->from($table); 
			
			if(!empty($data['fromdate'])){
				$this->db->where('created_at >=', $data['fromdate']);
				$this->db->where('created_at <=', $data['todate']);
			}			
			$this->db->where('sim_name','airtel');
			$result = $this->db->get();
			$result = $result->result();
			return $result;			
		}
		public function Get_data_by_search_key_Robi_model($table,$data){
			$this->db->select('*'); 
			$this->db->from($table); 
			
			if(!empty($data['fromdate'])){
				$this->db->where('created_at >=', $data['fromdate']);
				$this->db->where('created_at <=', $data['todate']);
			}			
			$this->db->where('sim_name','robi');
			$result = $this->db->get();
			$result = $result->result();
			return $result;			
		}
		public function Get_data_by_search_key_Teletalk_model($table,$data){
			$this->db->select('*'); 
			$this->db->from($table); 
			
			if(!empty($data['fromdate'])){
				$this->db->where('created_at >=', $data['fromdate']);
				$this->db->where('created_at <=', $data['todate']);
			}			
			$this->db->where('sim_name','teletalk');
			$result = $this->db->get();
			$result = $result->result();
			return $result;			
		}

/*Report stock model*/
		public function Get_data_stock_search_key_aritel_model($table,$data){
			$this->db->select('*'); 
			$this->db->from($table); 			
			$this->db->where('sim_name','airtel');
			$this->db->where('status',0);
			$result = $this->db->get();
			$result = $result->result();
			return $result;			
		}
		public function Get_data_stock_search_key_Bl_model($table,$data){
			$this->db->select('*'); 
			$this->db->from($table); 
			$this->db->where('sim_name','Bl');
			$this->db->where('status',0);
			$result = $this->db->get();
			$result = $result->result();
			return $result;			
		}
		public function Get_data_stock_search_key_Gp_model($table,$data){
			$this->db->select('*'); 
			$this->db->from($table); 
			$this->db->where('sim_name','Gp');
			$this->db->where('status',0);
			$result = $this->db->get();
			$result = $result->result();
			return $result;			
		}
		public function Get_data_stock_search_key_Robi_model($table,$data){
			$this->db->select('*'); 
			$this->db->from($table); 
			$this->db->where('sim_name','robi');
			$this->db->where('status',0);
			$result = $this->db->get();
			$result = $result->result();
			return $result;			
		}
		public function Get_data_stock_search_key_Teletalk_model($table,$data){
			$this->db->select('*'); 
			$this->db->from($table); 
			
			if(!empty($data['fromdate'])){
				$this->db->where('created_at >=', $data['fromdate']);
				$this->db->where('created_at <=', $data['todate']);
			}			
			$this->db->where('sim_name','teletalk');
			$this->db->where('status',0);
			$result = $this->db->get();
			$result = $result->result();
			return $result;			
		}
/****************************************************************************
*UPDATE / PRODUCT METHOD... 
*/		
		public function sim_update_model($table,$data){
			$this->db->set('sim_name',$data['sim_name']);	
			$this->db->set('sim_number',$data['sim_number']);
			$this->db->set('category',$data['category']);
			$this->db->set('sim_condition',$data['sim_condition']);
			$this->db->set('buy_date',$data['buy_date']);
			$this->db->set('buy_price',$data['buy_price']);
			$this->db->set('have_name',$data['have_name']);
			$this->db->where('sim_id',$data['sim_id']);
			$this->db->update($table);
		}		

		public function sale_by_update_model_to($table,$data){	
		    $this->db->set('sim_name',$data['sim_name']);	
			$this->db->set('sim_number',$data['sim_number']);
			$this->db->set('category',$data['category']);
			$this->db->set('sim_condition',$data['sim_condition']);
			$this->db->set('buy_date',$data['buy_date']);
			$this->db->set('buy_price',$data['buy_price']);
			$this->db->set('have_name',$data['have_name']);
			$this->db->set('seller_name',$data['seller_name']);
			$this->db->set('sale_price',$data['sale_price']);
			$this->db->where('sim_id',$data['sim_id']);
			$this->db->update($table);
		}		
/****************************************************************************
*STATUS ACTIVE/INACTIVE MODEL METHOD... 
*/	
		public function Update_status_model($table,$data){
			$this->db->set('status',$data['status']);
			$this->db->where($data['match_col'],$data['match_by']);
			$this->db->update($table);
		}
/****************************************************************************
*REMOVE / GENERIC METHOD... 
*/	
		public function Remove_data_by_id_model($table,$data){
			$this->db->where($data['match_col'],$data['match_by']);
			$this->db->delete($table);
		}		




		
/****************************************************************************
*UPDATE Company Logo/ Options METHOD... 
*/		
		public function companylogoupdate($optdata){
			$this->db->set('options_id',$optdata['options_id']);
			if(isset($optdata['company_logo'])){$this->db->set('company_logo',$optdata['company_logo']);}
			$this->db->where('options_id',$optdata['options_id']); 
			$this->db->update('tb_options'); 
		}
			
/****************************************************************************
*UPDATE Invoice Header / Options METHOD... 
*/		
		public function InvoiceHeaderUpdate($optdata){
			$this->db->set('options_id',$optdata['options_id']);
			if(isset($optdata['invoice_header'])){$this->db->set('invoice_header',$optdata['invoice_header']);}
			$this->db->where('options_id',$optdata['options_id']); 
			$this->db->update('tb_options'); 
		}
			

/****************************************************************************
*UPDATE Invoice Header / Options METHOD... 
*/		
		public function InvoiceSealUpdate($optdata){
			$this->db->set('options_id',$optdata['options_id']);
			if(isset($optdata['invoice_seal'])){$this->db->set('invoice_seal',$optdata['invoice_seal']);}
			$this->db->where('options_id',$optdata['options_id']); 
			$this->db->update('tb_options'); 
		}
			
/****************************************************************************
*UPDATE Change Invoice Paid / Options METHOD... 
*/		
		public function ChangeInvoicePaidUpdate($optdata){
			$this->db->set('options_id',$optdata['options_id']);
			if(isset($optdata['invoice_paid_seal'])){$this->db->set('invoice_paid_seal',$optdata['invoice_paid_seal']);}
			$this->db->where('options_id',$optdata['options_id']); 
			$this->db->update('tb_options'); 
		}
/****************************************************************************
*UPDATE option Paid / Options METHOD... 
*/	
		public function Options_site_model_update($optdata){
			$this->db->set('company_title',$optdata['company_title']);
			$this->db->set('company_slogan',$optdata['company_slogan']);
			$this->db->set('company_mobile',$optdata['company_mobile']);
			$this->db->set('company_address',$optdata['company_address']);
			$this->db->update('tb_options');
		}		
/****************************************************************************
*status option update on off / Options METHOD... 
*/		
		public function Update_site_status_model($table,$data){
			$this->db->set('site_status',$data['site_status']);
			$this->db->where($data['match_col'],$data['match_by']);
			$this->db->update($table);
		}	



}//end of model class.... 
?>